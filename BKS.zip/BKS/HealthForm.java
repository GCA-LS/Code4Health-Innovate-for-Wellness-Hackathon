package corzey;

public class HealthForm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		

	}

}
public class HealthForm {
	private String name;
	private int age;
	private String condition;
	private double temperature;
	
	public void fillform() {
		Scanner scanner = new
 Scanner(System.in);
		
		System.out.print("enter your name");
		name=scanner.nextLine();
		
		System.out.print("enter your age");
		age=scanner.nextInt();
		 scanner.nextLine();   //consume new line
		 
		System.out.print("enter your health condition (e.g.,cancer): ");
		 condition=scanner.nextLine();
		
		System.out.print("enter your gender");
		 gender=scanner.nextLIne();
		 
		System.out.print("enter your location");
		 location=scanner.nextDouble();
		 
		                  scanner.close();
		                  
	}
	  public void displayForm()  {
		  System.out.print("\n--- Health Info ---");
		  System.out.print("Name: " + name);
		  System.out.print("Age: " + age);
		  System.out.print("Condition: " + condition); 
		  System.out.print("Gender: " + gender);
		  System.out.print("Location: " + location);
		  
		  
	  }
	  public void submitForm () {
		  try {
			  FileWriter writer = new 
FileWriter("submitted_health_form.txt");
			  writer.write("Name: " + name + "\n");
			  writer.write("Age: " + age + "\n");
			  writer.write("Condition: " + condition + "\n");
			  writer.write("Gender: " + gender + "\n");
			  writer.write("Location: " + location + "\n");
			  writer.close();
			  System.out.println("\nForm submitted successfully and saved to 'submitted_health_form.txt'");
		  } catch (IOException e) {
			  System.out.println("An error occured while submitting the form.");
			  e.printStackTrace();
		 
	  }
}
      public void showMenu() {
    	  Scanner scanner = new
Scanner(System.in);
    	  int choice;
    	  
    	  do {
    		  System.out.println("\n--- Main Menu ---");
    		  System.out.println("1. Reminders");
    		  System.out.println("2. Daily Exercises");
    		  System.out.println("3. Motivational Quotes");
    		  System.out.println("4. Health Advice");
    		  System.out.println("5. Exit");
    		  System.out.println("Choose an option (1-5): ");
    		  choice = scanner.nextInt();
    		  scanner.nextLine(); //consume newline
    		  
    		  switch (choice) {
    		  case 1:
    			  Intent intent = new Intent(context, AlarmReceiver.class);
    			  PendingIntent pendingIntent = PendingIntent.getBroadcast(context, 0, intent, PendingIntent.FLAG_IMMUTABLE);
    			  AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
    			  
    			  Calendar calendar = Calendar .getInstance();
    			  calendar.add(Calendar.SECOND, 15); //for testing set alarm after 15 seconds
    			  
    			  alarmManager.setExact(AlarmManager.RTC_WAKEUP, calendar.getTimeInMillis(), pendingIntent);
    			  System.out.println("Reminder set to ring in 15 seconds.");
    			  break;
    		  case 2:
    			  System.out.println("Monday: Take a brisk walk for 15 mins.\n"
    			  		+ "Tuesday: Stretch and do some yoga for 10mins then you should go on a walk for 15-20mins.\n"
    			  		+ "Wednesday:Take a brisk walk for 30mins and do some balance exercises for 10mins"
    			  		+ "Thursday: Do some strength training for 15mins and then do some yoga and stretching for 15mins.\n"
    			  		+ "Friday: Take a brisk walk for 15-20mins and then do some light cycling or dancing for 15mins.\n"
    			  		+ "Saturday:Have some rest and then take a swim for 15-20mins.\n"
    			  		
    			  		
    			  		+ "tips: You can adjust the time based on your energy level or doctors advice And feel free to take breaks!  ENJOY...\n");
    		      break; 
    		  case 3:
    			  System.out.println("Quote: 'Rest is not a weakness. Its a step to recovery."
    			  		+ "You are stronger than you think and what your facing is just a chapter-not your whole story.\n"
    			  		+ "Healing takes time, but every day brings you one step closer.\n"
    			  		+ "Hope is the best medidcine, and you carry it within you.\n"
    			  		+ "You've fought through tough days before, and you will rise again.\n"
    			 
    					  
    			  break;
    		  case 4:
    			  System.out.println("Advice: Drink lots of water and do what makes you happy today.");
    			  break;
    		  case 5:
    			  System.out.println("Great...Keep well!");
    			  break;++
    	      default:
    	    	  System.out.println("Try again");
    			  
  
    		  }
    		  
           } while (choice != 5);
      }
      
      public static void main(String[] args) {
    	  HealthForm form = new HealthForm();
    	  form.fillForm();
    	  form.displayForm();
    	  form.submitForm();ls
    	  form.showMenu(); 
    	  }
}
		 