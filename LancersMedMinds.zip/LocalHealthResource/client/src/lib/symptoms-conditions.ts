// This file contains static mappings for symptoms to conditions
// In a real application, this would be replaced by a proper medical API or database

interface Condition {
  name: string;
  description: string;
  symptoms: string[];
  severity: 'low' | 'medium' | 'high';
}

export const commonConditions: Condition[] = [
  {
    name: "Common Cold",
    description: "A viral infection of the upper respiratory tract that primarily affects the nose.",
    symptoms: ["runny nose", "sneezing", "congestion", "sore throat", "cough", "mild fever"],
    severity: "low",
  },
  {
    name: "Influenza (Flu)",
    description: "A contagious respiratory illness caused by influenza viruses.",
    symptoms: ["fever", "chills", "cough", "sore throat", "body aches", "fatigue", "headache"],
    severity: "medium",
  },
  {
    name: "COVID-19",
    description: "A respiratory illness caused by the SARS-CoV-2 virus.",
    symptoms: ["fever", "cough", "shortness of breath", "fatigue", "body aches", "loss of taste or smell"],
    severity: "high",
  },
  {
    name: "Migraine",
    description: "A neurological condition that causes severe headaches, often with nausea and sensitivity to light.",
    symptoms: ["headache", "nausea", "vomiting", "sensitivity to light", "sensitivity to sound"],
    severity: "medium",
  },
  {
    name: "Tension Headache",
    description: "The most common type of headache that feels like a constant ache or pressure around the head.",
    symptoms: ["headache", "pressure around head", "scalp tenderness", "neck stiffness"],
    severity: "low",
  },
  {
    name: "Strep Throat",
    description: "A bacterial infection that causes inflammation and pain in the throat.",
    symptoms: ["sore throat", "difficulty swallowing", "fever", "swollen lymph nodes", "red tonsils"],
    severity: "medium",
  },
  {
    name: "Gastroenteritis",
    description: "An intestinal infection that causes diarrhea, abdominal cramps, nausea, and vomiting.",
    symptoms: ["diarrhea", "abdominal cramps", "nausea", "vomiting", "fever", "headache"],
    severity: "medium",
  },
  {
    name: "Bronchitis",
    description: "Inflammation of the lining of the bronchial tubes, which carry air to and from the lungs.",
    symptoms: ["cough", "mucus production", "fatigue", "shortness of breath", "mild fever", "chest discomfort"],
    severity: "medium",
  },
  {
    name: "Allergies",
    description: "Allergic reactions occur when the body's immune system overreacts to substances that are typically harmless.",
    symptoms: ["sneezing", "itchy eyes", "runny nose", "congestion", "rash", "wheezing"],
    severity: "low",
  },
];

// Function to analyze symptoms and return matching conditions
export function analyzeSymptoms(symptoms: string[]): { condition: string; probability: number }[] {
  const results: { condition: string; probability: number }[] = [];
  const lowercaseSymptoms = symptoms.map(s => s.toLowerCase().trim());
  
  for (const condition of commonConditions) {
    // Count how many symptoms match
    const matchingSymptoms = condition.symptoms.filter(symptom => 
      lowercaseSymptoms.some(userSymptom => 
        userSymptom.includes(symptom) || symptom.includes(userSymptom)
      )
    );
    
    if (matchingSymptoms.length > 0) {
      // Calculate a simple probability based on number of matching symptoms
      const probability = matchingSymptoms.length / condition.symptoms.length;
      
      // Only include if at least 25% of symptoms match
      if (probability >= 0.25) {
        results.push({
          condition: condition.name,
          probability: parseFloat(probability.toFixed(2)),
        });
      }
    }
  }
  
  // Sort by probability (highest first)
  return results.sort((a, b) => b.probability - a.probability);
}
