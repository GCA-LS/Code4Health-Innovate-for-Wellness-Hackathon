import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Heart, Plus, Stethoscope, Hospital, BookX } from "lucide-react";

export default function Welcome() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-primary-foreground to-muted">
      <div className="container mx-auto px-4 py-8">
        <header className="text-center py-12">
          <Heart className="h-16 w-16 mx-auto text-primary mb-4" />
          <h1 className="text-4xl font-bold text-primary">Local Health Resource Finder</h1>
          <p className="text-xl mt-2 text-muted-foreground">Find the healthcare you need, when you need it</p>
        </header>
        
        <div className="flex flex-col items-center justify-center gap-6 mt-8">
          <Card className="w-full max-w-md shadow-lg">
            <CardHeader>
              <CardTitle className="text-2xl text-center">Welcome</CardTitle>
              <CardDescription className="text-center">
                Connect with local healthcare facilities based on your symptoms
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col gap-4">
              <div className="flex items-center gap-4">
                <Stethoscope className="h-8 w-8 text-primary" />
                <div>
                  <h3 className="font-semibold">Symptom Analysis</h3>
                  <p className="text-sm text-muted-foreground">Enter your symptoms to get possible conditions</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <Hospital className="h-8 w-8 text-primary" />
                <div>
                  <h3 className="font-semibold">Find Facilities</h3>
                  <p className="text-sm text-muted-foreground">Locate hospitals, clinics, and pharmacies near you</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <BookX className="h-8 w-8 text-primary" />
                <div>
                  <h3 className="font-semibold">Service Information</h3>
                  <p className="text-sm text-muted-foreground">View operating hours, services, and contact details</p>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex gap-4 justify-center">
              <Button asChild variant="default">
                <Link to="/login">Login</Link>
              </Button>
              <Button asChild variant="outline">
                <Link to="/register">Register</Link>
              </Button>
            </CardFooter>
          </Card>
          
          <div className="flex items-center justify-center gap-2 mt-8 text-xs text-muted-foreground">
            <Heart className="h-4 w-4" />
            <span>© 2023 Health Resource Finder</span>
          </div>
        </div>
      </div>
    </div>
  );
}
