import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Facility } from "@shared/schema";
import FacilityCard from "@/components/facility-card";
import MapView from "@/components/map-view";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, Building, MapPin, Search, ShieldPlus, Pill, Map } from "lucide-react";

interface LocationListProps {
  type: string;
}

export default function LocationList({ type }: LocationListProps) {
  const [, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const [showMap, setShowMap] = useState(false);
  
  const { data: facilities = [], isLoading } = useQuery<Facility[]>({
    queryKey: [`/api/facilities?type=${type}`],
  });
  
  const filteredFacilities = facilities.filter(facility => 
    facility.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    facility.address.toLowerCase().includes(searchTerm.toLowerCase()) ||
    (facility.services as string[]).some(service => 
      service.toLowerCase().includes(searchTerm.toLowerCase())
    )
  );
  
  const getTypeIcon = () => {
    switch (type) {
      case "hospital":
        return <Building className="h-5 w-5" />;
      case "clinic":
        return <ShieldPlus className="h-5 w-5" />;
      case "pharmacy":
        return <Pill className="h-5 w-5" />;
      default:
        return <Building className="h-5 w-5" />;
    }
  };
  
  const getTypeName = () => {
    return type.charAt(0).toUpperCase() + type.slice(1) + "s";
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-4">
        <div className="space-y-4">
          <Skeleton className="h-8 w-1/3" />
          <Skeleton className="h-10 w-full" />
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Skeleton className="h-64 w-full" />
            <Skeleton className="h-64 w-full" />
            <Skeleton className="h-64 w-full" />
            <Skeleton className="h-64 w-full" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted">
      <header className="bg-primary text-primary-foreground shadow-md">
        <div className="container mx-auto px-4 py-4">
          <div className="flex flex-col md:flex-row md:justify-between md:items-center gap-4">
            <div className="flex items-center">
              <Button 
                variant="ghost" 
                size="icon"
                onClick={() => setLocation("/dashboard")}
                className="mr-2"
              >
                <ArrowLeft className="h-4 w-4" />
              </Button>
              <div className="flex items-center space-x-2">
                {getTypeIcon()}
                <h1 className="text-xl font-bold">{getTypeName()}</h1>
              </div>
            </div>
            
            <div className="flex items-center space-x-2">
              <div className="relative max-w-xs w-full">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input 
                  type="search"
                  placeholder="Search by name, address, or service..."
                  className="pl-9"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>
              <Button 
                variant="secondary"
                size="icon"
                onClick={() => setShowMap(!showMap)}
              >
                {showMap ? <Building className="h-4 w-4" /> : <Map className="h-4 w-4" />}
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {showMap ? (
          <div className="bg-card rounded-lg shadow-md p-4 mb-4">
            <h2 className="text-lg font-semibold mb-2 flex items-center">
              <MapPin className="h-5 w-5 mr-2 text-primary" />
              Map View
            </h2>
            <MapView facilities={filteredFacilities} />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredFacilities.length > 0 ? (
              filteredFacilities.map((facility) => (
                <FacilityCard key={facility.id} facility={facility} />
              ))
            ) : (
              <div className="col-span-full text-center py-8">
                <p className="text-muted-foreground text-lg">
                  No {type}s found matching "{searchTerm}"
                </p>
                <Button 
                  variant="link" 
                  onClick={() => setSearchTerm("")}
                  className="mt-2"
                >
                  Clear search
                </Button>
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
