import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { User } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import SymptomAnalyzer from "@/components/symptom-analyzer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Building, PlusCircle, Pill, ShieldPlus, ShoppingCart, User as UserIcon } from "lucide-react";
import { Badge } from "@/components/ui/badge";

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [conditions, setConditions] = useState<{condition: string, probability: number}[]>([]);
  
  const { data: user, isLoading } = useQuery<User>({
    queryKey: ['/api/me'],
  });

  const { data: cartItems = [], isLoading: isCartLoading } = useQuery({
    queryKey: ['/api/cart'],
  });

  const handleLogout = async () => {
    try {
      await apiRequest("POST", "/api/logout", {});
      toast({
        title: "Logged out",
        description: "Successfully logged out of your account",
      });
      setLocation("/");
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to logout. Please try again.",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="container mx-auto p-4">
        <div className="space-y-4">
          <Skeleton className="h-8 w-1/3" />
          <Skeleton className="h-32 w-full" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Skeleton className="h-40 w-full" />
            <Skeleton className="h-40 w-full" />
            <Skeleton className="h-40 w-full" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted">
      <header className="bg-primary text-primary-foreground shadow-md">
        <div className="container mx-auto px-4 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-2">
              <ShieldPlus className="h-6 w-6" />
              <h1 className="text-xl font-bold">Health Resource Finder</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Button 
                variant="ghost" 
                size="sm" 
                className="flex items-center space-x-1"
                onClick={() => setLocation("/cart")}
              >
                <ShoppingCart className="h-4 w-4" />
                <span>Cart</span>
                {!isCartLoading && cartItems.length > 0 && (
                  <Badge variant="secondary" className="ml-1">
                    {cartItems.length}
                  </Badge>
                )}
              </Button>
              <Button 
                variant="ghost" 
                size="sm" 
                className="flex items-center space-x-1"
                onClick={() => setLocation("/profile")}
              >
                <UserIcon className="h-4 w-4" />
                <span>{user?.fullName || user?.username}</span>
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleLogout}
              >
                Logout
              </Button>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 gap-8">
          <section>
            <Card className="bg-card">
              <CardHeader>
                <CardTitle>Welcome, {user?.fullName || user?.username}!</CardTitle>
                <CardDescription>
                  Enter your symptoms below to find potential conditions and nearby healthcare facilities
                </CardDescription>
              </CardHeader>
              <CardContent>
                <SymptomAnalyzer onResults={setConditions} />
              </CardContent>
            </Card>
          </section>

          {conditions.length > 0 && (
            <section>
              <Card>
                <CardHeader>
                  <CardTitle>Potential Conditions</CardTitle>
                  <CardDescription>
                    Based on your symptoms, these conditions are possible. Consult a healthcare professional for proper diagnosis.
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {conditions.map((condition, index) => (
                      <div key={index} className="flex items-center justify-between p-3 border rounded-md">
                        <div className="font-medium">{condition.condition}</div>
                        <Badge variant={
                          condition.probability > 0.7 ? "destructive" : 
                          condition.probability > 0.5 ? "secondary" : "outline"
                        }>
                          {(condition.probability * 100).toFixed(0)}% match
                        </Badge>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </section>
          )}

          <section>
            <h2 className="text-2xl font-bold mb-4">Find Healthcare Facilities</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Card className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center">
                    <Building className="h-5 w-5 mr-2 text-primary" />
                    Hospitals
                  </CardTitle>
                  <CardDescription>
                    Emergency services, surgeries, and specialized treatments
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button 
                    variant="outline" 
                    className="w-full"
                    onClick={() => setLocation("/locations/hospital")}
                  >
                    <PlusCircle className="h-4 w-4 mr-2" />
                    View Hospitals
                  </Button>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center">
                    <ShieldPlus className="h-5 w-5 mr-2 text-primary" />
                    Clinics
                  </CardTitle>
                  <CardDescription>
                    Primary care, vaccinations, and routine check-ups
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button 
                    variant="outline" 
                    className="w-full"
                    onClick={() => setLocation("/locations/clinic")}
                  >
                    <PlusCircle className="h-4 w-4 mr-2" />
                    View Clinics
                  </Button>
                </CardContent>
              </Card>

              <Card className="hover:shadow-lg transition-shadow">
                <CardHeader className="pb-2">
                  <CardTitle className="flex items-center">
                    <Pill className="h-5 w-5 mr-2 text-primary" />
                    Pharmacies
                  </CardTitle>
                  <CardDescription>
                    Prescription services, over-the-counter medications, and consultations
                  </CardDescription>
                </CardHeader>
                <CardContent>
                  <Button 
                    variant="outline" 
                    className="w-full"
                    onClick={() => setLocation("/locations/pharmacy")}
                  >
                    <PlusCircle className="h-4 w-4 mr-2" />
                    View Pharmacies
                  </Button>
                </CardContent>
              </Card>
            </div>
          </section>
        </div>
      </main>
    </div>
  );
}
