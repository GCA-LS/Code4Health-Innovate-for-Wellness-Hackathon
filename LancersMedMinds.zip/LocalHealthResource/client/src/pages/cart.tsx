import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { User, CartItem, Facility } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import {
  ArrowLeft,
  ShieldPlus,
  ShoppingCart,
  Trash2,
  ClipboardCheck,
  AlertCircle,
  Loader2,
  MapPin
} from "lucide-react";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export default function Cart() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isConfirmOpen, setIsConfirmOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  
  const { data: user } = useQuery<User>({
    queryKey: ['/api/me'],
  });
  
  const { data: cartItems = [], isLoading: isCartLoading } = useQuery<CartItem[]>({
    queryKey: ['/api/cart'],
  });
  
  const { data: facilities = [] } = useQuery<Facility[]>({
    queryKey: ['/api/facilities'],
    enabled: !isCartLoading && cartItems.length > 0,
  });
  
  const removeItemMutation = useMutation({
    mutationFn: async (itemId: number) => {
      await apiRequest("DELETE", `/api/cart/${itemId}`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      toast({
        title: "Item removed",
        description: "The service has been removed from your cart",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to remove item",
      });
    },
  });
  
  const clearCartMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("DELETE", `/api/cart`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      setIsConfirmOpen(false);
      toast({
        title: "Cart cleared",
        description: "All items have been removed from your cart",
      });
    },
    onError: (error) => {
      setIsConfirmOpen(false);
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to clear cart",
      });
    },
  });
  
  const checkoutMutation = useMutation({
    mutationFn: async () => {
      // In a real application, this would process the cart items
      // For now, we'll just clear the cart
      await apiRequest("DELETE", `/api/cart`, undefined);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      setIsCheckoutOpen(false);
      toast({
        title: "Checkout complete",
        description: "Your services have been confirmed",
      });
    },
    onError: (error) => {
      setIsCheckoutOpen(false);
      toast({
        variant: "destructive",
        title: "Checkout failed",
        description: error instanceof Error ? error.message : "Failed to process checkout",
      });
    },
  });
  
  const getFacilityById = (facilityId: number): Facility | undefined => {
    return facilities.find(f => f.id === facilityId);
  };
  
  const groupedCartItems = cartItems.reduce((acc, item) => {
    if (!acc[item.facilityId]) {
      acc[item.facilityId] = [];
    }
    acc[item.facilityId].push(item);
    return acc;
  }, {} as Record<number, CartItem[]>);
  
  if (isCartLoading) {
    return (
      <div className="container mx-auto p-4">
        <div className="space-y-4">
          <Skeleton className="h-8 w-1/3" />
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-10 w-40" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted">
      <header className="bg-primary text-primary-foreground shadow-md">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => setLocation("/dashboard")}
              className="mr-2"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div className="flex items-center space-x-2">
              <ShoppingCart className="h-5 w-5" />
              <h1 className="text-xl font-bold">My Cart</h1>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        {cartItems.length === 0 ? (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <ShoppingCart className="h-5 w-5 mr-2" />
                Your Cart is Empty
              </CardTitle>
              <CardDescription>
                You haven't added any healthcare services to your cart yet
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Browse hospitals, clinics, and pharmacies to find services you need.
              </p>
            </CardContent>
            <CardFooter>
              <Button onClick={() => setLocation("/dashboard")}>
                Browse Facilities
              </Button>
            </CardFooter>
          </Card>
        ) : (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-2xl font-bold">Selected Services ({cartItems.length})</h2>
              <Button 
                variant="outline" 
                onClick={() => setIsConfirmOpen(true)}
                className="flex items-center space-x-1"
              >
                <Trash2 className="h-4 w-4 mr-2" />
                Clear Cart
              </Button>
            </div>
            
            {Object.entries(groupedCartItems).map(([facilityId, items]) => {
              const facility = getFacilityById(Number(facilityId));
              return (
                <Card key={facilityId}>
                  <CardHeader>
                    <CardTitle>{facility?.name || "Unknown Facility"}</CardTitle>
                    <CardDescription className="flex items-center">
                      <MapPin className="h-4 w-4 mr-1" />
                      {facility?.address || "Unknown location"}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <h3 className="font-medium mb-2">Selected Services:</h3>
                    <ul className="space-y-2">
                      {items.map((item) => (
                        <li key={item.id} className="flex justify-between items-center p-2 border rounded-md">
                          <span>{item.serviceName}</span>
                          <Button
                            variant="ghost"
                            size="icon"
                            onClick={() => removeItemMutation.mutate(item.id)}
                            disabled={removeItemMutation.isPending}
                          >
                            <Trash2 className="h-4 w-4 text-destructive" />
                          </Button>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              );
            })}
            
            <Card className="bg-muted-foreground/5">
              <CardContent className="pt-6">
                <div className="flex justify-between items-center">
                  <div>
                    <h3 className="text-lg font-medium">Ready to confirm your selection?</h3>
                    <p className="text-muted-foreground">
                      This will notify the facilities of your intent to visit.
                    </p>
                  </div>
                  <Button 
                    onClick={() => setIsCheckoutOpen(true)}
                    className="flex items-center space-x-1"
                  >
                    <ClipboardCheck className="h-4 w-4 mr-2" />
                    Confirm Visit
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </main>
      
      {/* Confirm clear cart dialog */}
      <AlertDialog open={isConfirmOpen} onOpenChange={setIsConfirmOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Clear your cart?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove all services from your cart. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => clearCartMutation.mutate()}
              disabled={clearCartMutation.isPending}
              className="bg-destructive text-destructive-foreground"
            >
              {clearCartMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Clearing...
                </>
              ) : (
                <>
                  <Trash2 className="mr-2 h-4 w-4" />
                  Clear Cart
                </>
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      
      {/* Checkout confirmation dialog */}
      <AlertDialog open={isCheckoutOpen} onOpenChange={setIsCheckoutOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Confirm your visit</AlertDialogTitle>
            <AlertDialogDescription>
              You're about to confirm your intention to visit these facilities for the selected services.
              In a real application, this would notify the facilities and possibly schedule appointments.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => checkoutMutation.mutate()}
              disabled={checkoutMutation.isPending}
            >
              {checkoutMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Processing...
                </>
              ) : (
                <>
                  <ClipboardCheck className="mr-2 h-4 w-4" />
                  Confirm Visit
                </>
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
