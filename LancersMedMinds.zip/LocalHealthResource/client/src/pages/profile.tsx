import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { User } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { ArrowLeft, ShieldPlus, User as UserIcon, LogOut, Clock } from "lucide-react";

export default function Profile() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  const { data: user, isLoading } = useQuery<User>({
    queryKey: ['/api/me'],
  });
  
  const { data: cartItems = [] } = useQuery({
    queryKey: ['/api/cart'],
  });

  const logoutMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("POST", "/api/logout", {});
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/me'] });
      toast({
        title: "Logged out",
        description: "Successfully logged out of your account",
      });
      setLocation("/");
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to logout",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="container mx-auto p-4">
        <div className="space-y-4">
          <Skeleton className="h-8 w-1/3" />
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-32 w-full" />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted">
      <header className="bg-primary text-primary-foreground shadow-md">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center">
            <Button 
              variant="ghost" 
              size="icon"
              onClick={() => setLocation("/dashboard")}
              className="mr-2"
            >
              <ArrowLeft className="h-4 w-4" />
            </Button>
            <div className="flex items-center space-x-2">
              <UserIcon className="h-5 w-5" />
              <h1 className="text-xl font-bold">Your Profile</h1>
            </div>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="md:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <UserIcon className="h-5 w-5 mr-2 text-primary" />
                  Profile Information
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Full Name</h3>
                  <p className="text-lg">{user?.fullName}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Username</h3>
                  <p className="text-lg">{user?.username}</p>
                </div>
                <div>
                  <h3 className="text-sm font-medium text-muted-foreground">Email</h3>
                  <p className="text-lg">{user?.email}</p>
                </div>
                <Button 
                  variant="outline" 
                  className="w-full flex items-center"
                  onClick={() => logoutMutation.mutate()}
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout
                </Button>
              </CardContent>
            </Card>
          </div>

          <div className="md:col-span-2">
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <ShieldPlus className="h-5 w-5 mr-2 text-primary" />
                    Health Summary
                  </CardTitle>
                  <CardDescription>
                    A summary of your current healthcare activities
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="p-4 border rounded-md">
                    <h3 className="text-lg font-medium flex items-center">
                      <Clock className="h-4 w-4 mr-2 text-primary" />
                      Current Activities
                    </h3>
                    
                    {cartItems.length > 0 ? (
                      <div className="mt-2">
                        <p className="text-muted-foreground">
                          You have {cartItems.length} service{cartItems.length > 1 ? 's' : ''} in your cart.
                        </p>
                        <Button 
                          variant="link" 
                          className="p-0 h-auto"
                          onClick={() => setLocation("/cart")}
                        >
                          View Cart
                        </Button>
                      </div>
                    ) : (
                      <p className="text-muted-foreground mt-2">
                        You have no pending healthcare services in your cart.
                      </p>
                    )}
                  </div>
                  
                  <div className="space-y-2">
                    <h3 className="text-lg font-medium">Quick Actions</h3>
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
                      <Button 
                        variant="outline" 
                        className="flex items-center justify-center"
                        onClick={() => setLocation("/dashboard")}
                      >
                        Check Symptoms
                      </Button>
                      <Button 
                        variant="outline"
                        className="flex items-center justify-center"
                        onClick={() => setLocation("/locations/hospital")}
                      >
                        Find Hospitals
                      </Button>
                      <Button 
                        variant="outline"
                        className="flex items-center justify-center"
                        onClick={() => setLocation("/locations/pharmacy")}
                      >
                        Find Pharmacies
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
