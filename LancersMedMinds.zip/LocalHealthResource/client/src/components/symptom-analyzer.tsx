import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { symptomAnalysisSchema, type SymptomAnalysis } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Textarea } from "@/components/ui/textarea";
import { Loader2, Stethoscope } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

interface SymptomAnalyzerProps {
  onResults: (results: {condition: string, probability: number}[]) => void;
}

export default function SymptomAnalyzer({ onResults }: SymptomAnalyzerProps) {
  const { toast } = useToast();
  const [showHint, setShowHint] = useState(false);
  
  const form = useForm<SymptomAnalysis>({
    resolver: zodResolver(symptomAnalysisSchema),
    defaultValues: {
      symptoms: "",
    },
  });

  const analyzeMutation = useMutation({
    mutationFn: async (data: SymptomAnalysis) => {
      const response = await apiRequest("POST", "/api/analyze-symptoms", data);
      return response.json() as Promise<{condition: string, probability: number}[]>;
    },
    onSuccess: (data) => {
      onResults(data);
      if (data.length === 0) {
        toast({
          title: "No matches found",
          description: "We couldn't find any conditions matching your symptoms. Please try different symptoms or consult a healthcare professional.",
        });
      }
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Analysis failed",
        description: error instanceof Error ? error.message : "Failed to analyze symptoms",
      });
    },
  });

  function onSubmit(values: SymptomAnalysis) {
    analyzeMutation.mutate(values);
  }

  return (
    <div>
      {showHint && (
        <Alert className="mb-4">
          <Stethoscope className="h-4 w-4" />
          <AlertTitle>Symptom Entry Tips</AlertTitle>
          <AlertDescription>
            Enter your symptoms separated by commas. For example: "headache, fever, cough".
            Be specific and include details about severity and duration if possible.
          </AlertDescription>
        </Alert>
      )}
      
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="symptoms"
            render={({ field }) => (
              <FormItem>
                <FormLabel className="flex justify-between items-center">
                  <span>Enter your symptoms</span>
                  <Button 
                    variant="ghost" 
                    size="sm"
                    type="button"
                    onClick={() => setShowHint(!showHint)}
                    className="h-auto py-0 px-2 text-xs"
                  >
                    {showHint ? "Hide tips" : "Show tips"}
                  </Button>
                </FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="e.g., headache, fever, sore throat"
                    className="min-h-20"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />
          
          <Button 
            type="submit"
            className="w-full"
            disabled={analyzeMutation.isPending}
          >
            {analyzeMutation.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Analyzing...
              </>
            ) : (
              <>
                <Stethoscope className="mr-2 h-4 w-4" />
                Analyze Symptoms
              </>
            )}
          </Button>
        </form>
      </Form>
    </div>
  );
}
