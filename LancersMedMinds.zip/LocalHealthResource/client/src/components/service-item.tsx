import { Button } from "@/components/ui/button";
import { CheckCircle2, Plus, Loader2 } from "lucide-react";

interface ServiceItemProps {
  service: string;
  isSelected: boolean;
  isPending: boolean;
  onToggle: () => void;
  onAddToCart: () => void;
}

export default function ServiceItem({
  service,
  isSelected,
  isPending,
  onToggle,
  onAddToCart,
}: ServiceItemProps) {
  return (
    <div 
      className={`
        flex justify-between items-center p-2 rounded-md border
        ${isSelected ? 'bg-primary/10 border-primary' : 'bg-card border-border'}
        hover:bg-muted/50 transition-colors cursor-pointer
      `}
      onClick={onToggle}
    >
      <div className="flex items-center">
        {isSelected ? (
          <CheckCircle2 className="h-4 w-4 text-primary mr-2" />
        ) : (
          <div className="h-4 w-4 rounded-full border border-muted-foreground mr-2" />
        )}
        <span className={isSelected ? 'font-medium' : ''}>{service}</span>
      </div>
      
      <Button
        variant="ghost"
        size="icon"
        className="h-6 w-6"
        disabled={isPending}
        onClick={(e) => {
          e.stopPropagation();
          onAddToCart();
        }}
      >
        {isPending ? (
          <Loader2 className="h-3 w-3 animate-spin" />
        ) : (
          <Plus className="h-3 w-3" />
        )}
      </Button>
    </div>
  );
}
