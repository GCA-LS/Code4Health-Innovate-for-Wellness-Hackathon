import { useEffect, useRef, useState } from "react";
import { Facility } from "@shared/schema";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { MapPin, Locate } from "lucide-react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

interface MapViewProps {
  facilities: Facility[];
}

export default function MapView({ facilities }: MapViewProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const [userLocation, setUserLocation] = useState<[number, number] | null>(null);
  const [locationError, setLocationError] = useState<string | null>(null);
  const [mapInstance, setMapInstance] = useState<any | null>(null);
  const [searchRadius, setSearchRadius] = useState<number>(5); // km
  const [mapReady, setMapReady] = useState<boolean>(false);

  // Initialize map
  useEffect(() => {
    if (!mapRef.current || mapInstance) return;

    // Default location (Maseru, Lesotho)
    const defaultLocation: [number, number] = [-29.3142, 27.4833];
    
    try {
      // Create Leaflet map
      const map = L.map(mapRef.current).setView(defaultLocation, 10);
      
      // Add tile layer (map imagery)
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      }).addTo(map);
      
      // Fix the icon path issue
      delete (L.Icon.Default.prototype as any)._getIconUrl;
      L.Icon.Default.mergeOptions({
        iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
        iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
        shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
      });
      
      setMapInstance(map);
      setMapReady(true);
      
      return () => {
        if (map) {
          map.remove();
        }
      };
    } catch (error) {
      console.error("Error initializing map:", error);
    }
  }, []);

  // Ask for user's location when they click on the locate button
  const getUserLocation = () => {
    if (!navigator.geolocation) {
      setLocationError("Geolocation is not supported by your browser");
      return;
    }
    
    setLocationError(null);
    
    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        setUserLocation([latitude, longitude]);
      },
      (error) => {
        switch (error.code) {
          case error.PERMISSION_DENIED:
            setLocationError("Location access denied. Please enable location services.");
            break;
          case error.POSITION_UNAVAILABLE:
            setLocationError("Location information is unavailable.");
            break;
          case error.TIMEOUT:
            setLocationError("Location request timed out.");
            break;
          default:
            setLocationError("An unknown error occurred.");
        }
      }
    );
  };

  // Update map when user location or facilities change
  useEffect(() => {
    if (!mapInstance || !mapReady) return;
    
    try {
      // Clear existing markers
      mapInstance.eachLayer((layer: any) => {
        if (layer instanceof L.Marker || layer instanceof L.Circle) {
          mapInstance.removeLayer(layer);
        }
      });
      
      // Add tile layer (map imagery) back
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      }).addTo(mapInstance);
      
      // Center on user's location if available
      if (userLocation) {
        mapInstance.setView(userLocation, 13);
        
        // Add user marker
        const userIcon = L.divIcon({
          className: 'user-location-marker',
          html: `<div style="position: relative; padding: 4px; border-radius: 50%; background-color: #3b82f6; border: 2px solid white;">
                  <div style="height: 12px; width: 12px; border-radius: 50%; background-color: #3b82f6; animation: ping 1s cubic-bezier(0, 0, 0.2, 1) infinite; position: absolute;"></div>
                  <div style="height: 12px; width: 12px; border-radius: 50%; background-color: #3b82f6; position: relative;"></div>
                 </div>`,
          iconSize: [20, 20],
          iconAnchor: [10, 10]
        });
        
        L.marker(userLocation, { icon: userIcon })
          .addTo(mapInstance)
          .bindPopup("<b>Your Location</b>")
          .openPopup();
        
        // Add search radius circle
        L.circle(userLocation, {
          radius: searchRadius * 1000, // convert km to meters
          color: 'rgba(59, 130, 246, 0.2)',
          fillColor: 'rgba(59, 130, 246, 0.1)',
          fillOpacity: 0.5
        }).addTo(mapInstance);
      }
      
      // Add facility markers
      facilities.forEach((facility) => {
        const lat = parseFloat(facility.latitude);
        const lng = parseFloat(facility.longitude);
        
        if (isNaN(lat) || isNaN(lng)) return;
        
        // Calculate if the facility is within the search radius
        let isWithinRadius = true;
        if (userLocation) {
          const [userLat, userLng] = userLocation;
          const distance = getDistance(userLat, userLng, lat, lng);
          isWithinRadius = distance <= searchRadius;
        }
        
        // Only show facilities within radius if user location is known
        if (!userLocation || isWithinRadius) {
          // Determine marker color based on facility type
          let markerColor = '';
          
          switch (facility.type) {
            case "hospital":
              markerColor = 'red';
              break;
            case "clinic":
              markerColor = 'blue';
              break;
            case "pharmacy":
              markerColor = 'green';
              break;
            default:
              markerColor = 'gray';
          }
          
          // Create a standard marker with proper icon
          const marker = L.marker([lat, lng], {
            icon: new L.Icon({
              iconUrl: `https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-2x-${markerColor}.png`,
              shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
              iconSize: [25, 41],
              iconAnchor: [12, 41],
              popupAnchor: [1, -34],
              shadowSize: [41, 41]
            })
          });
          
          // Add popup with facility information
          marker.bindPopup(`
            <div style="min-width: 200px;">
              <h3 style="font-weight: bold; margin-bottom: 5px;">${facility.name}</h3>
              <p style="margin: 5px 0;">${facility.address}</p>
              <p style="margin: 5px 0; font-size: 0.9em; color: #666;">${facility.operatingHours}</p>
              <p style="margin: 5px 0; font-weight: 600;">${facility.contactNumber}</p>
              <p style="margin-top: 8px; font-size: 0.9em; font-weight: bold;">Services:</p>
              <ul style="margin: 5px 0; padding-left: 20px; font-size: 0.9em;">
                ${(facility.services as string[]).map(service => `<li>${service}</li>`).join('')}
              </ul>
            </div>
          `).addTo(mapInstance);
        }
      });
    } catch (error) {
      console.error("Error updating map:", error);
    }
  }, [mapInstance, userLocation, facilities, searchRadius, mapReady]);

  // Haversine formula to calculate distance between two points on Earth
  function getDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371; // Radius of the Earth in km
    const dLat = deg2rad(lat2 - lat1);
    const dLon = deg2rad(lon2 - lon1);
    const a = 
      Math.sin(dLat/2) * Math.sin(dLat/2) +
      Math.cos(deg2rad(lat1)) * Math.cos(deg2rad(lat2)) * 
      Math.sin(dLon/2) * Math.sin(dLon/2); 
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a)); 
    const distance = R * c; // Distance in km
    return distance;
  }

  function deg2rad(deg: number): number {
    return deg * (Math.PI/180);
  }

  // Adjust the search radius
  const handleRadiusChange = (newRadius: number) => {
    setSearchRadius(newRadius);
  };
  
  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center space-x-2">
          <Button
            variant="outline"
            size="sm"
            onClick={getUserLocation}
            className="flex items-center space-x-1"
          >
            <Locate className="h-4 w-4 mr-1" />
            {userLocation ? "Update My Location" : "Use My Location"}
          </Button>
          
          {userLocation && (
            <div className="flex items-center space-x-1">
              <span className="text-sm text-muted-foreground">Search radius:</span>
              <Button 
                variant="outline" 
                size="sm"
                className={searchRadius === 2 ? "bg-primary text-primary-foreground" : ""}
                onClick={() => handleRadiusChange(2)}
              >
                2km
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                className={searchRadius === 5 ? "bg-primary text-primary-foreground" : ""}
                onClick={() => handleRadiusChange(5)}
              >
                5km
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                className={searchRadius === 10 ? "bg-primary text-primary-foreground" : ""}
                onClick={() => handleRadiusChange(10)}
              >
                10km
              </Button>
            </div>
          )}
        </div>
        
        <div className="flex items-center gap-3">
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-red-500 mr-1"></div>
            <span className="text-xs">Hospitals</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-blue-500 mr-1"></div>
            <span className="text-xs">Clinics</span>
          </div>
          <div className="flex items-center">
            <div className="w-3 h-3 rounded-full bg-green-500 mr-1"></div>
            <span className="text-xs">Pharmacies</span>
          </div>
        </div>
      </div>
      
      {locationError && (
        <Alert variant="destructive">
          <MapPin className="h-4 w-4" />
          <AlertTitle>Location Error</AlertTitle>
          <AlertDescription>{locationError}</AlertDescription>
        </Alert>
      )}
      
      <div 
        ref={mapRef} 
        className="w-full h-[500px] border rounded-md bg-muted"
        style={{ position: 'relative' }}
      >
        {!mapReady && (
          <div className="absolute inset-0 flex items-center justify-center">
            <p className="text-muted-foreground">Loading map...</p>
          </div>
        )}
      </div>
      
      {!userLocation && (
        <Alert>
          <Locate className="h-4 w-4" />
          <AlertTitle>Enable location for better results</AlertTitle>
          <AlertDescription>
            Click "Use My Location" to find healthcare facilities near you. This will help you find the closest options.
          </AlertDescription>
        </Alert>
      )}
    </div>
  );
}
