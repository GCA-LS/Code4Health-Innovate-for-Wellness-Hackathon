import { useState } from "react";
import { useQueryClient, useMutation } from "@tanstack/react-query";
import { Facility, InsertCartItem } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import ServiceItem from "@/components/service-item";
import {
  Building,
  ShieldPlus,
  Pill,
  Phone,
  Clock,
  MapPin,
  Plus,
  Check,
  ChevronDown,
  ChevronUp,
  Loader2
} from "lucide-react";

interface FacilityCardProps {
  facility: Facility;
}

export default function FacilityCard({ facility }: FacilityCardProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showAllServices, setShowAllServices] = useState(false);
  const [selectedServices, setSelectedServices] = useState<string[]>([]);
  
  const services = facility.services as string[];
  const displayServices = showAllServices 
    ? services 
    : services.slice(0, 3);
  
  const addToCartMutation = useMutation({
    mutationFn: async (service: string) => {
      const cartItem: InsertCartItem = {
        facilityId: facility.id,
        serviceName: service,
      };
      const response = await apiRequest("POST", "/api/cart", cartItem);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/cart'] });
      toast({
        title: "Service added",
        description: "The service has been added to your cart",
      });
    },
    onError: (error) => {
      toast({
        variant: "destructive",
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to add service to cart",
      });
    },
  });
  
  const handleToggleService = (service: string) => {
    if (selectedServices.includes(service)) {
      setSelectedServices(selectedServices.filter(s => s !== service));
    } else {
      setSelectedServices([...selectedServices, service]);
    }
  };
  
  const handleAddToCart = (service: string) => {
    addToCartMutation.mutate(service);
  };
  
  const getFacilityIcon = () => {
    switch (facility.type) {
      case "hospital":
        return <Building className="h-5 w-5 text-primary" />;
      case "clinic":
        return <ShieldPlus className="h-5 w-5 text-primary" />;
      case "pharmacy":
        return <Pill className="h-5 w-5 text-primary" />;
      default:
        return <Building className="h-5 w-5 text-primary" />;
    }
  };

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div className="flex items-center">
            {getFacilityIcon()}
            <Badge variant="outline" className="ml-2">
              {facility.type.charAt(0).toUpperCase() + facility.type.slice(1)}
            </Badge>
          </div>
        </div>
        <CardTitle className="mt-2">{facility.name}</CardTitle>
        <CardDescription className="flex items-center">
          <MapPin className="h-3 w-3 mr-1 flex-shrink-0" />
          <span className="truncate">{facility.address}</span>
        </CardDescription>
      </CardHeader>
      <CardContent className="flex-grow">
        <div className="space-y-4">
          <div className="flex items-center">
            <Phone className="h-4 w-4 mr-2 text-muted-foreground" />
            <span>{facility.contactNumber}</span>
          </div>
          <div className="flex items-start">
            <Clock className="h-4 w-4 mr-2 text-muted-foreground mt-0.5" />
            <span>{facility.operatingHours}</span>
          </div>
          
          <div>
            <h3 className="text-sm font-medium mb-2">Services:</h3>
            <div className="space-y-2">
              {displayServices.map((service) => (
                <ServiceItem 
                  key={service}
                  service={service}
                  isSelected={selectedServices.includes(service)}
                  isPending={addToCartMutation.isPending}
                  onToggle={() => handleToggleService(service)}
                  onAddToCart={() => handleAddToCart(service)}
                />
              ))}
              
              {services.length > 3 && (
                <Button
                  variant="ghost"
                  size="sm"
                  className="w-full mt-1 text-xs h-auto py-1"
                  onClick={() => setShowAllServices(!showAllServices)}
                >
                  {showAllServices ? (
                    <>
                      <ChevronUp className="h-3 w-3 mr-1" />
                      Show Less
                    </>
                  ) : (
                    <>
                      <ChevronDown className="h-3 w-3 mr-1" />
                      Show All ({services.length - 3} more)
                    </>
                  )}
                </Button>
              )}
            </div>
          </div>
        </div>
      </CardContent>
      <CardFooter className="pt-2">
        <Button
          className="w-full"
          disabled={selectedServices.length === 0 || addToCartMutation.isPending}
          onClick={() => {
            for (const service of selectedServices) {
              handleAddToCart(service);
            }
            setSelectedServices([]);
          }}
        >
          {addToCartMutation.isPending ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Adding...
            </>
          ) : selectedServices.length === 0 ? (
            <>
              <Plus className="mr-2 h-4 w-4" />
              Select Services
            </>
          ) : (
            <>
              <Check className="mr-2 h-4 w-4" />
              Add {selectedServices.length} to Cart
            </>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}
