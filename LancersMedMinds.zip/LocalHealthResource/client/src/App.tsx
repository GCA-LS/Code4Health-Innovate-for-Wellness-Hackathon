import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Welcome from "@/pages/welcome";
import Register from "@/pages/register";
import Login from "@/pages/login";
import Dashboard from "@/pages/dashboard";
import LocationList from "@/pages/location-list";
import Cart from "@/pages/cart";
import Profile from "@/pages/profile";
import AuthGuard from "@/components/auth-guard";

function Router() {
  return (
    <Switch>
      {/* Public routes */}
      <Route path="/" component={Welcome} />
      <Route path="/register" component={Register} />
      <Route path="/login" component={Login} />
      
      {/* Protected routes */}
      <Route path="/dashboard">
        <AuthGuard>
          <Dashboard />
        </AuthGuard>
      </Route>
      <Route path="/locations/:type">
        {(params) => (
          <AuthGuard>
            <LocationList type={params.type} />
          </AuthGuard>
        )}
      </Route>
      <Route path="/cart">
        <AuthGuard>
          <Cart />
        </AuthGuard>
      </Route>
      <Route path="/profile">
        <AuthGuard>
          <Profile />
        </AuthGuard>
      </Route>
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
