import { pgTable, text, serial, integer, boolean, timestamp, jsonb, uniqueIndex } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

// Facilities table (hospitals, clinics, pharmacies)
export const facilities = pgTable("facilities", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // 'hospital', 'clinic', 'pharmacy'
  address: text("address").notNull(),
  contactNumber: text("contact_number").notNull(),
  operatingHours: text("operating_hours").notNull(),
  latitude: text("latitude").notNull(),
  longitude: text("longitude").notNull(),
  services: jsonb("services").notNull(), // Array of services offered
});

export const insertFacilitySchema = createInsertSchema(facilities).omit({
  id: true,
});

// Cart items table - stores selected services by users
export const cartItems = pgTable("cart_items", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  facilityId: integer("facility_id").notNull().references(() => facilities.id),
  serviceName: text("service_name").notNull(),
  dateAdded: timestamp("date_added").defaultNow().notNull(),
});

export const insertCartItemSchema = createInsertSchema(cartItems).omit({
  id: true,
  dateAdded: true,
});

// Symptoms database for matching with conditions
export const symptoms = pgTable("symptoms", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  relatedConditions: jsonb("related_conditions").notNull(), // Array of condition objects
});

export const insertSymptomSchema = createInsertSchema(symptoms).omit({
  id: true,
});

// Types export
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Facility = typeof facilities.$inferSelect;
export type InsertFacility = z.infer<typeof insertFacilitySchema>;

export type CartItem = typeof cartItems.$inferSelect;
export type InsertCartItem = z.infer<typeof insertCartItemSchema>;

export type Symptom = typeof symptoms.$inferSelect;
export type InsertSymptom = z.infer<typeof insertSymptomSchema>;

// Auth schemas
export const loginSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  password: z.string().min(6, "Password must be at least 6 characters"),
});

export type LoginCredentials = z.infer<typeof loginSchema>;

// Symptom analysis schema
export const symptomAnalysisSchema = z.object({
  symptoms: z.string().min(3, "Please enter at least one symptom"),
});

export type SymptomAnalysis = z.infer<typeof symptomAnalysisSchema>;
