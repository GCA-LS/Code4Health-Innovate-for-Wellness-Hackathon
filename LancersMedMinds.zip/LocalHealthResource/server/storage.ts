import { 
  users, type User, type InsertUser, 
  facilities, type Facility, type InsertFacility,
  cartItems, type CartItem, type InsertCartItem,
  symptoms, type Symptom, type InsertSymptom
} from "@shared/schema";
import { db } from "./db";
import { eq, and } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Facility operations
  getFacility(id: number): Promise<Facility | undefined>;
  getFacilitiesByType(type: string): Promise<Facility[]>;
  getAllFacilities(): Promise<Facility[]>;
  
  // Cart operations
  getCartItems(userId: number): Promise<CartItem[]>;
  addToCart(item: InsertCartItem): Promise<CartItem>;
  removeFromCart(id: number): Promise<void>;
  clearCart(userId: number): Promise<void>;
  
  // Symptom operations
  getSymptomsByNames(symptomNames: string[]): Promise<Symptom[]>;
  analyzeSymptoms(symptomNames: string[]): Promise<{condition: string, probability: number}[]>;
}

export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  // Facility operations
  async getFacility(id: number): Promise<Facility | undefined> {
    const [facility] = await db.select().from(facilities).where(eq(facilities.id, id));
    return facility;
  }

  async getFacilitiesByType(type: string): Promise<Facility[]> {
    return await db.select().from(facilities).where(eq(facilities.type, type));
  }

  async getAllFacilities(): Promise<Facility[]> {
    return await db.select().from(facilities);
  }

  // Cart operations
  async getCartItems(userId: number): Promise<CartItem[]> {
    return await db.select().from(cartItems).where(eq(cartItems.userId, userId));
  }

  async addToCart(insertItem: InsertCartItem): Promise<CartItem> {
    const [cartItem] = await db.insert(cartItems).values(insertItem).returning();
    return cartItem;
  }

  async removeFromCart(id: number): Promise<void> {
    await db.delete(cartItems).where(eq(cartItems.id, id));
  }

  async clearCart(userId: number): Promise<void> {
    await db.delete(cartItems).where(eq(cartItems.userId, userId));
  }

  // Symptom operations
  async getSymptomsByNames(symptomNames: string[]): Promise<Symptom[]> {
    const lowerCaseNames = symptomNames.map(name => name.toLowerCase().trim());
    const symptomsList = await db.select().from(symptoms);
    return symptomsList.filter(
      (symptom) => lowerCaseNames.includes(symptom.name.toLowerCase())
    );
  }

  async analyzeSymptoms(symptomNames: string[]): Promise<{condition: string, probability: number}[]> {
    const symptoms = await this.getSymptomsByNames(symptomNames);
    
    // Create a map to aggregate condition probabilities
    const conditionMap = new Map<string, {total: number, count: number}>();
    
    // Process each symptom and its related conditions
    symptoms.forEach(symptom => {
      const conditions = symptom.relatedConditions as {name: string, probability: number}[];
      
      conditions.forEach(condition => {
        const current = conditionMap.get(condition.name) || {total: 0, count: 0};
        current.total += condition.probability;
        current.count += 1;
        conditionMap.set(condition.name, current);
      });
    });
    
    // Calculate average probability for each condition
    const result = Array.from(conditionMap.entries()).map(([name, data]) => ({
      condition: name,
      probability: Number((data.total / data.count).toFixed(2))
    }));
    
    // Sort by probability (highest first)
    return result.sort((a, b) => b.probability - a.probability);
  }

  // Seed the database with initial data
  async seedDatabase(): Promise<void> {
    // Check if data already exists
    const existingFacilities = await db.select().from(facilities);
    if (existingFacilities.length > 0) {
      console.log("Database already seeded");
      return;
    }

    console.log("Seeding database with initial data...");

    // Check if symptoms already exist
    const existingSymptoms = await db.select().from(symptoms);
    
    // Only add symptoms if none exist
    if (existingSymptoms.length === 0) {
      // Add some symptoms
      const commonSymptoms: InsertSymptom[] = [
        {
          name: "headache",
          relatedConditions: [
            { name: "Migraine", probability: 0.7 },
            { name: "Tension Headache", probability: 0.6 },
            { name: "Sinus Infection", probability: 0.4 },
          ],
        },
        {
          name: "fever",
          relatedConditions: [
            { name: "Common Cold", probability: 0.6 },
            { name: "Flu", probability: 0.8 },
            { name: "COVID-19", probability: 0.5 },
          ],
        },
        {
          name: "cough",
          relatedConditions: [
            { name: "Common Cold", probability: 0.7 },
            { name: "Bronchitis", probability: 0.5 },
            { name: "COVID-19", probability: 0.6 },
          ],
        },
        {
          name: "sore throat",
          relatedConditions: [
            { name: "Strep Throat", probability: 0.6 },
            { name: "Common Cold", probability: 0.7 },
            { name: "Tonsillitis", probability: 0.5 },
          ],
        },
        {
          name: "fatigue",
          relatedConditions: [
            { name: "Flu", probability: 0.7 },
            { name: "Anemia", probability: 0.5 },
            { name: "Depression", probability: 0.4 },
          ],
        }
      ];

      await db.insert(symptoms).values(commonSymptoms);
    } else {
      console.log("Symptoms already exist, skipping seed");
    }

    // Add some facilities in Lesotho
    const sampleFacilities: InsertFacility[] = [
      {
        name: "Queen Mamohato Memorial Hospital",
        type: "hospital",
        address: "Botšabelo Road, Maseru 100, Lesotho",
        contactNumber: "+266 2231 2490",
        operatingHours: "Open 24/7",
        latitude: "-29.324238",
        longitude: "27.485382",
        services: [
          "Emergency Services",
          "Surgery",
          "Cardiology",
          "Obstetrics & Gynecology",
          "Pediatrics",
          "Radiology"
        ]
      },
      {
        name: "Baylor College of Medicine Clinic",
        type: "clinic",
        address: "Airport Road, Maseru, Lesotho",
        contactNumber: "+266 2231 7211",
        operatingHours: "Mon-Fri: 8am-5pm",
        latitude: "-29.305723",
        longitude: "27.477819",
        services: [
          "HIV/AIDS Treatment",
          "Pediatric Care",
          "Vaccinations",
          "Family Medicine",
          "Health Education"
        ]
      },
      {
        name: "Lesotho Pharmaceutical Company",
        type: "pharmacy",
        address: "Kingsway Road, Maseru Mall, Maseru, Lesotho",
        contactNumber: "+266 2232 5970",
        operatingHours: "Mon-Sat: 8am-7pm, Sun: 9am-3pm",
        latitude: "-29.315850",
        longitude: "27.485235",
        services: [
          "Prescription Filling",
          "Over-the-counter Medications",
          "Health Consultations",
          "Medical Supplies",
          "Health Screenings"
        ]
      },
      {
        name: "Scott Hospital",
        type: "hospital",
        address: "Morija, Maseru District, Lesotho",
        contactNumber: "+266 2236 0292",
        operatingHours: "Open 24/7",
        latitude: "-29.639847",
        longitude: "27.519688",
        services: [
          "Emergency Care",
          "Surgery",
          "Maternity Services",
          "Primary Care",
          "HIV Treatment"
        ]
      },
      {
        name: "Mokhotlong Government Hospital",
        type: "hospital",
        address: "Mokhotlong District, Lesotho",
        contactNumber: "+266 2292 0202",
        operatingHours: "Open 24/7",
        latitude: "-29.294201",
        longitude: "29.074736",
        services: [
          "Emergency Care",
          "General Medicine",
          "Maternity Services",
          "Vaccination",
          "HIV/AIDS Services"
        ]
      },
      {
        name: "Paballong HIV/AIDS Care Centre",
        type: "clinic",
        address: "Ha Senekane, Maseru District, Lesotho",
        contactNumber: "+266 2233 2240",
        operatingHours: "Mon-Fri: 8am-4:30pm",
        latitude: "-29.313240",
        longitude: "27.550175",
        services: [
          "HIV/AIDS Testing",
          "HIV/AIDS Treatment",
          "Counseling",
          "Health Education",
          "Primary Care"
        ]
      },
      {
        name: "Makoanyane Military Hospital",
        type: "hospital",
        address: "Ha Ratjomose, Maseru, Lesotho",
        contactNumber: "+266 2232 4211",
        operatingHours: "Open 24/7",
        latitude: "-29.303889",
        longitude: "27.483333",
        services: [
          "Emergency Services",
          "Surgery",
          "General Medicine",
          "Dental Services",
          "X-Ray Services"
        ]
      },
      {
        name: "Roma Health Service Area",
        type: "clinic",
        address: "Roma, Maseru District, Lesotho",
        contactNumber: "+266 2234 0601",
        operatingHours: "Mon-Fri: 8am-5pm",
        latitude: "-29.447278",
        longitude: "27.728975",
        services: [
          "Primary Care",
          "Maternal Health",
          "Child Health",
          "TB Treatment",
          "HIV Services"
        ]
      },
      {
        name: "Seboche Hospital",
        type: "hospital",
        address: "Butha-Buthe District, Lesotho",
        contactNumber: "+266 2246 0032",
        operatingHours: "Open 24/7",
        latitude: "-28.773889",
        longitude: "28.420278",
        services: [
          "Emergency Care",
          "Surgery",
          "Maternity Services",
          "Pediatrics",
          "HIV/AIDS Treatment"
        ]
      },
      {
        name: "Likotsi Pharmacy",
        type: "pharmacy",
        address: "Main South 1 Road, Ha Likotsi, Maseru, Lesotho",
        contactNumber: "+266 5800 2100",
        operatingHours: "Mon-Fri: 8am-6pm, Sat: 9am-3pm",
        latitude: "-29.341667",
        longitude: "27.466667",
        services: [
          "Prescription Services",
          "Over-the-counter Medications",
          "Medical Supplies",
          "Health Advice",
          "Basic Health Screenings"
        ]
      },
      {
        name: "Pioneer Mall Pharmacy",
        type: "pharmacy",
        address: "Pioneer Shopping Centre, Maseru, Lesotho",
        contactNumber: "+266 2232 8105",
        operatingHours: "Mon-Sat: 9am-8pm, Sun: 10am-4pm",
        latitude: "-29.323099",
        longitude: "27.497829",
        services: [
          "Prescription Filling",
          "Health Consultations",
          "Cosmetics",
          "First Aid Supplies",
          "Baby Products"
        ]
      },
      {
        name: "Mafeteng Hospital",
        type: "hospital",
        address: "Mafeteng District, Lesotho",
        contactNumber: "+266 2270 0203",
        operatingHours: "Open 24/7",
        latitude: "-29.823333",
        longitude: "27.236944",
        services: [
          "Emergency Services",
          "General Surgery",
          "Internal Medicine",
          "Obstetrics",
          "Pediatrics"
        ]
      }
    ];

    await db.insert(facilities).values(sampleFacilities);
    console.log("Database seeded successfully");
  }
}

export const storage = new DatabaseStorage();
