import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertUserSchema, 
  loginSchema, 
  insertCartItemSchema, 
  symptomAnalysisSchema 
} from "@shared/schema";
import { z } from 'zod';
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import { pool } from "./db";

// Add session to Request type
declare module 'express-session' {
  interface SessionData {
    userId: number;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Set up session middleware with PostgreSQL session store
  const PgSession = connectPgSimple(session);
  app.use(
    session({
      store: new PgSession({
        pool,
        tableName: 'sessions',
        createTableIfMissing: true
      }),
      secret: process.env.SESSION_SECRET || 'local-health-secret',
      resave: false,
      saveUninitialized: false,
      cookie: {
        maxAge: 30 * 24 * 60 * 60 * 1000, // 30 days
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production'
      }
    })
  );

  // Seed the database 
  await (storage as any).seedDatabase();
  
  // User authentication routes
  app.post('/api/register', async (req: Request, res: Response) => {
    try {
      const userData = insertUserSchema.parse(req.body);
      
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Username already exists" });
      }

      const user = await storage.createUser(userData);
      
      // Log the user in automatically after registration
      req.session.userId = user.id;
      
      // Don't send password back to client
      const { password, ...userWithoutPassword } = user;
      
      return res.status(201).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      console.error("Error creating user:", error);
      return res.status(500).json({ message: "Error creating user" });
    }
  });

  app.post('/api/login', async (req: Request, res: Response) => {
    try {
      const credentials = loginSchema.parse(req.body);
      
      const user = await storage.getUserByUsername(credentials.username);
      if (!user) {
        return res.status(401).json({ message: "Invalid username or password" });
      }

      if (user.password !== credentials.password) {
        return res.status(401).json({ message: "Invalid username or password" });
      }

      // Create session
      req.session.userId = user.id;

      // Don't send password back to client
      const { password, ...userWithoutPassword } = user;
      
      return res.status(200).json(userWithoutPassword);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      console.error("Error during login:", error);
      return res.status(500).json({ message: "Error during login" });
    }
  });

  app.post('/api/logout', (req: Request, res: Response) => {
    req.session.destroy((err: Error) => {
      if (err) {
        return res.status(500).json({ message: "Error during logout" });
      }
      res.status(200).json({ message: "Logged out successfully" });
    });
  });

  app.get('/api/me', async (req: Request, res: Response) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const user = await storage.getUser(req.session.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      // Don't send password back to client
      const { password, ...userWithoutPassword } = user;
      
      return res.status(200).json(userWithoutPassword);
    } catch (error) {
      console.error("Error fetching user:", error);
      return res.status(500).json({ message: "Error fetching user" });
    }
  });

  // Facility routes
  app.get('/api/facilities', async (req: Request, res: Response) => {
    try {
      let facilities;
      
      if (req.query.type) {
        facilities = await storage.getFacilitiesByType(req.query.type as string);
      } else {
        facilities = await storage.getAllFacilities();
      }
      
      return res.status(200).json(facilities);
    } catch (error) {
      console.error("Error fetching facilities:", error);
      return res.status(500).json({ message: "Error fetching facilities" });
    }
  });

  app.get('/api/facilities/:id', async (req: Request, res: Response) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid facility ID" });
      }

      const facility = await storage.getFacility(id);
      if (!facility) {
        return res.status(404).json({ message: "Facility not found" });
      }
      
      return res.status(200).json(facility);
    } catch (error) {
      console.error("Error fetching facility:", error);
      return res.status(500).json({ message: "Error fetching facility" });
    }
  });

  // Cart routes
  app.get('/api/cart', async (req: Request, res: Response) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const cartItems = await storage.getCartItems(req.session.userId);
      return res.status(200).json(cartItems);
    } catch (error) {
      console.error("Error fetching cart items:", error);
      return res.status(500).json({ message: "Error fetching cart items" });
    }
  });

  app.post('/api/cart', async (req: Request, res: Response) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const cartItemData = insertCartItemSchema.parse({
        ...req.body,
        userId: req.session.userId
      });

      const cartItem = await storage.addToCart(cartItemData);
      return res.status(201).json(cartItem);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      console.error("Error adding item to cart:", error);
      return res.status(500).json({ message: "Error adding item to cart" });
    }
  });

  app.delete('/api/cart/:id', async (req: Request, res: Response) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ message: "Invalid cart item ID" });
      }

      await storage.removeFromCart(id);
      return res.status(200).json({ message: "Item removed from cart" });
    } catch (error) {
      console.error("Error removing item from cart:", error);
      return res.status(500).json({ message: "Error removing item from cart" });
    }
  });

  app.delete('/api/cart', async (req: Request, res: Response) => {
    if (!req.session.userId) {
      return res.status(401).json({ message: "Not authenticated" });
    }

    try {
      await storage.clearCart(req.session.userId);
      return res.status(200).json({ message: "Cart cleared" });
    } catch (error) {
      console.error("Error clearing cart:", error);
      return res.status(500).json({ message: "Error clearing cart" });
    }
  });

  // Symptom analysis route
  app.post('/api/analyze-symptoms', async (req: Request, res: Response) => {
    try {
      const { symptoms } = symptomAnalysisSchema.parse(req.body);
      
      // Split the symptoms string into an array
      const symptomArray = symptoms.split(',').map(s => s.trim());
      
      if (symptomArray.length === 0) {
        return res.status(400).json({ message: "No symptoms provided" });
      }

      const conditions = await storage.analyzeSymptoms(symptomArray);
      return res.status(200).json(conditions);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          message: "Validation error", 
          errors: error.errors 
        });
      }
      console.error("Error analyzing symptoms:", error);
      return res.status(500).json({ message: "Error analyzing symptoms" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
