import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.util.List;

class HealthCenter {
    String name, type, city;
    double latitude, longitude;

    HealthCenter(String name, String type, String city, double latitude, double longitude) {
        this.name = name;
        this.type = type;
        this.city = city;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public double distanceTo(double userLat, double userLon) {
        return Math.sqrt(Math.pow(latitude - userLat, 2) + Math.pow(longitude - userLon, 2));
    }

    public String display() {
        return name + " - " + type + " - " + city;
    }
}

public class HealthCenterLocator {
    private JFrame frame;
    private JPanel panelMain;
    private JTextField latField, lonField;
    private JTextArea resultArea;

    private List<HealthCenter> centers = Arrays.asList(
            new HealthCenter("Queen Mamohato Memorial Hospital", "Hospital", "Maseru", -29.3101, 27.4794),
            new HealthCenter("Maseru Private Clinic", "Clinic", "Maseru", -29.3115, 27.4780),
            new HealthCenter("Khubetsoana Pharmacy", "Pharmacy", "Maseru", -29.3150, 27.4805),
            new HealthCenter("Motebang Hospital", "Hospital", "Leribe", -28.8794, 28.0456),
            new HealthCenter("Maputsoe Health Centre", "Clinic", "Leribe", -28.9050, 28.0150)
    );

    public HealthCenterLocator() {
        frame = new JFrame("HealthFinder Main Menu");
        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        panelMain = new JPanel();
        panelMain.setLayout(new BoxLayout(panelMain, BoxLayout.Y_AXIS));
        panelMain.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel welcomeLabel = new JLabel("Welcome to HealthFinder");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 18));
        welcomeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel latLabel = new JLabel("Enter Your Latitude:");
        latField = new JTextField(10);

        JLabel lonLabel = new JLabel("Enter Your Longitude:");
        lonField = new JTextField(10);

        JButton findButton = new JButton("Find Nearby Health Centers");
        findButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        resultArea = new JTextArea(10, 30);
        resultArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultArea);

        findButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                findNearby();
            }
        });

        panelMain.add(welcomeLabel);
        panelMain.add(Box.createRigidArea(new Dimension(0, 10)));
        panelMain.add(latLabel);
        panelMain.add(latField);
        panelMain.add(lonLabel);
        panelMain.add(lonField);
        panelMain.add(Box.createRigidArea(new Dimension(0, 10)));
        panelMain.add(findButton);
        panelMain.add(Box.createRigidArea(new Dimension(0, 10)));
        panelMain.add(scrollPane);

        frame.add(panelMain);
        frame.setVisible(true);
    }

    private void findNearby() {
        try {
            double userLat = Double.parseDouble(latField.getText());
            double userLon = Double.parseDouble(lonField.getText());

            centers.sort(Comparator.comparingDouble(c -> c.distanceTo(userLat, userLon)));

            resultArea.setText("Nearest Health Centers:\n\n");
            for (int i = 0; i < Math.min(5, centers.size()); i++) {
                resultArea.append((i + 1) + ". " + centers.get(i).display() + "\n");
            }
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(frame, "Please enter valid numeric coordinates.", "Input Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new HealthCenterLocator();
    }
}