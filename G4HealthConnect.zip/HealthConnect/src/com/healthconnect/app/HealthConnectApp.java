package com.healthconnect.app;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.URI;
import java.util.*;
import java.util.List;

public class HealthConnectApp {
    private JFrame frame;
    private JComboBox<String> languageSelector;
    private JTextField searchField;
    private JPanel resultsPanel;
    private JLabel offlineMapLabel;
    private Locale currentLocale;
    private Map<String, List<String[]>> healthcareCenters;
    private List<String[]> allLocations;
    private Map<String, String[]> translations = new HashMap<>();
    private JPanel buttonPanel;

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new HealthConnectApp().createAndShowGUI());
    }

    private void initializeTranslations() {
        translations.put("Language", new String[]{"Language:", "Langue:", "Idioma:", "Puo:"});
        translations.put("Search", new String[]{"Search:", "Chercher:", "Buscar:", "Batla:"});
        translations.put("Hospitals", new String[]{"Hospitals", "Hôpitaux", "Hospitales", "Lipetlele"});
        translations.put("Clinics", new String[]{"Clinics", "Cliniques", "Clínicas", "Litsebeletso"});
        translations.put("Pharmacies", new String[]{"Pharmacies", "Pharmacies", "Farmacias", "Lipheheliso"});
        translations.put("Map Info", new String[]{"Map Info", "Infos Carte", "Información Mapa", "Tlhahisoleseding Map"});
        translations.put("Emergency Call", new String[]{"Emergency Call", "Appel d'urgence", "Llamada de emergencia", "Mohala oa tšohanyetso"});
        translations.put("Health Tips", new String[]{"Health Tips", "Conseils santé", "Consejos de salud", "Malebela a bophelo"});
        translations.put("First Aid", new String[]{"First Aid", "Premiers secours", "Primeros auxilios", "Thuso ea pele"});
        translations.put("OfflineMapText", new String[]{
            "Select a healthcare center to view offline map.",
            "Sélectionnez un centre de santé pour voir la carte hors ligne.",
            "Seleccione un centro de salud para ver el mapa sin conexión.",
            "Khetha setsi sa bophelo ho bona 'mapa ntle le inthanete."
        });
        translations.put("NoResults", new String[]{
            "No results found.",
            "Aucun résultat trouvé.",
            "No se encontraron resultados.",
            "Ha ho liphetho tse fumanoeng."
        });
        translations.put("Open Map", new String[]{"Open Map", "Ouvrir la carte", "Abrir mapa", "Bula 'Mapa"});
        translations.put("Offline Map", new String[]{"Offline Map", "Carte hors ligne", "Mapa sin conexión", "'Mapa ntle le inthanete"});
    }

    private void createAndShowGUI() {
        initializeTranslations();
        currentLocale = new Locale("en");
        frame = new JFrame("HealthConnect");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(950, 600);

        JPanel topPanel = new JPanel(new GridLayout(2, 1));

        JPanel langPanel = new JPanel();
        langPanel.add(new JLabel(translations.get("Language")[0]));
        languageSelector = new JComboBox<>(new String[]{"English", "Français", "Español", "Sesotho"});
        languageSelector.addActionListener(e -> changeLanguage(languageSelector.getSelectedIndex()));
        langPanel.add(languageSelector);

        JPanel searchPanel = new JPanel();
        searchPanel.add(new JLabel(translations.get("Search")[0]));
        searchField = new JTextField(20);
        searchField.addActionListener(e -> filterResults(searchField.getText().trim()));
        searchPanel.add(searchField);

        topPanel.add(langPanel);
        topPanel.add(searchPanel);

        resultsPanel = new JPanel();
        resultsPanel.setLayout(new BoxLayout(resultsPanel, BoxLayout.Y_AXIS));

        JScrollPane scrollPane = new JScrollPane(resultsPanel);
        scrollPane.setPreferredSize(new Dimension(600, 400));

        buttonPanel = new JPanel(new GridLayout(7, 1));
        String[] labels = {
            translations.get("Hospitals")[0],
            translations.get("Clinics")[0],
            translations.get("Pharmacies")[0],
            translations.get("Map Info")[0],
            translations.get("Emergency Call")[0],
            translations.get("Health Tips")[0],
            translations.get("First Aid")[0]
        };

        String[] actions = {"Hospitals", "Clinics", "Pharmacies", "Map Info", "Emergency", "Tips", "FirstAid"};

        for (int i = 0; i < labels.length; i++) {
            JButton btn = new JButton(labels[i]);
            String action = actions[i];
            btn.addActionListener(e -> handleButtonClick(action));
            buttonPanel.add(btn);
        }

        offlineMapLabel = new JLabel(translations.get("OfflineMapText")[0]);
        resultsPanel.add(offlineMapLabel);

        JSplitPane splitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, buttonPanel, scrollPane);
        splitPane.setDividerLocation(250);

        frame.add(topPanel, BorderLayout.NORTH);
        frame.add(splitPane, BorderLayout.CENTER);
        frame.setVisible(true);

        initializeHealthcareData();
        updateResults("Hospitals");
    }

    private void initializeHealthcareData() {
        healthcareCenters = new HashMap<>();
        healthcareCenters.put("Hospitals", Arrays.asList(
            new String[]{"Queen Mamohato Memorial Hospital", "Maseru", "-29.3193, 27.4856"},
            new String[]{"Motebang Hospital", "Leribe", "-28.8714, 28.0453"},
            new String[]{"Berea Government Hospital", "Berea", "-29.1638, 27.8982"},
            new String[]{"Seboche Mission Hospital", "Butha-Buthe", "-28.7651, 28.2438"},
            new String[]{"Ntsekhe Hospital", "Mohale's Hoek", "-30.1514, 27.4719"}
        ));
        healthcareCenters.put("Clinics", Arrays.asList(
            new String[]{"Qoaling Filter Clinic", "Maseru", "-29.3414, 27.4887"},
            new String[]{"Mamohau Health Centre", "Leribe", "-28.8722, 28.0422"},
            new String[]{"Maputsoe Filter Clinic", "Leribe", "-28.8843, 28.0039"},
            new String[]{"Motsekuoa Clinic", "Mafeteng", "-29.8317, 27.2546"},
            new String[]{"Roma Clinic", "Roma", "-29.4493, 27.7172"}
        ));
        healthcareCenters.put("Pharmacies", Arrays.asList(
            new String[]{"Medics Pharmacy", "Maseru", "-29.3123, 27.4950"},
            new String[]{"HealthPlus Pharmacy", "Maseru", "-29.3111, 27.4872"},
            new String[]{"Leribe Pharmacy", "Leribe", "-28.8723, 28.0410"},
            new String[]{"Berea Community Pharmacy", "Berea", "-29.1582, 27.9037"},
            new String[]{"Roma Pharmacy", "Roma", "-29.4502, 27.7193"}
        ));

        allLocations = new ArrayList<>();
        for (List<String[]> list : healthcareCenters.values()) {
            allLocations.addAll(list);
        }
    }

    private void updateResults(String type) {
        resultsPanel.removeAll();
        List<String[]> centers = healthcareCenters.getOrDefault(type, new ArrayList<>());
        for (String[] info : centers) {
            resultsPanel.add(createCenterPanel(info));
        }
        if (centers.isEmpty()) {
            resultsPanel.add(new JLabel(translations.get("NoResults")[languageSelector.getSelectedIndex()]));
        }
        resultsPanel.revalidate();
        resultsPanel.repaint();
    }

    private JPanel createCenterPanel(String[] data) {
        JPanel panel = new JPanel(new GridLayout(3, 1));
        panel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        panel.add(new JLabel("Name: " + data[0]));
        panel.add(new JLabel("Location: " + data[1]));

        JPanel mapButtons = new JPanel();
        JButton openMapBtn = new JButton(translations.get("Open Map")[languageSelector.getSelectedIndex()]);
        openMapBtn.addActionListener(e -> openGoogleMaps(data[2]));
        JButton offlineMapBtn = new JButton(translations.get("Offline Map")[languageSelector.getSelectedIndex()]);
        offlineMapBtn.addActionListener(e -> JOptionPane.showMessageDialog(frame, "Offline Map:\n" + data[2]));

        mapButtons.add(openMapBtn);
        mapButtons.add(offlineMapBtn);
        panel.add(mapButtons);

        return panel;
    }

    private void openGoogleMaps(String coordinates) {
        try {
            String cleanedCoords = coordinates.replaceAll("\\s+", "");
            URI uri = new URI("https://www.google.com/maps/search/?api=1&query=" + cleanedCoords);
            Desktop.getDesktop().browse(uri);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(frame, "Could not open map: " + ex.getMessage());
        }
    }

    private void filterResults(String query) {
        resultsPanel.removeAll();
        boolean found = false;
        for (String[] loc : allLocations) {
            if (loc[0].toLowerCase().contains(query.toLowerCase()) || loc[1].toLowerCase().contains(query.toLowerCase())) {
                resultsPanel.add(createCenterPanel(loc));
                found = true;
            }
        }
        if (!found) {
            resultsPanel.add(new JLabel(translations.get("NoResults")[languageSelector.getSelectedIndex()]));
        }
        resultsPanel.revalidate();
        resultsPanel.repaint();
    }

    private void handleButtonClick(String action) {
        if (action.equals("Emergency")) {
            JOptionPane.showMessageDialog(frame, "Dial: 121 (Emergency Services in Lesotho)");
        } else if (action.equals("Tips")) {
            JOptionPane.showMessageDialog(frame, "Tip: Drink clean water, wash hands regularly, and wear masks when needed.");
        } else if (action.equals("FirstAid")) {
            JOptionPane.showMessageDialog(frame, "Basic First Aid:\n- Bleeding: Apply pressure.\n- Burns: Cool with water.\n- Choking: Heimlich maneuver.");
        } else {
            updateResults(action);
        }
    }

    private void changeLanguage(int index) {
        switch (index) {
            case 0: currentLocale = new Locale("en"); break;
            case 1: currentLocale = new Locale("fr"); break;
            case 2: currentLocale = new Locale("es"); break;
            case 3: currentLocale = new Locale("st"); break;
        }
        refreshUI();
    }

    private void refreshUI() {
        int langIndex = languageSelector.getSelectedIndex();

        // Update top labels
        ((JLabel)((JPanel)((JPanel)frame.getContentPane().getComponent(0)).getComponent(0)).getComponent(0))
            .setText(translations.get("Language")[langIndex]);
        ((JLabel)((JPanel)((JPanel)frame.getContentPane().getComponent(0)).getComponent(1)).getComponent(0))
            .setText(translations.get("Search")[langIndex]);

        // Update buttons directly from stored buttonPanel
        ((JButton)buttonPanel.getComponent(0)).setText(translations.get("Hospitals")[langIndex]);
        ((JButton)buttonPanel.getComponent(1)).setText(translations.get("Clinics")[langIndex]);
        ((JButton)buttonPanel.getComponent(2)).setText(translations.get("Pharmacies")[langIndex]);
        ((JButton)buttonPanel.getComponent(3)).setText(translations.get("Map Info")[langIndex]);
        ((JButton)buttonPanel.getComponent(4)).setText(translations.get("Emergency Call")[langIndex]);
        ((JButton)buttonPanel.getComponent(5)).setText(translations.get("Health Tips")[langIndex]);
        ((JButton)buttonPanel.getComponent(6)).setText(translations.get("First Aid")[langIndex]);

        // Update offline label and results
        offlineMapLabel.setText(translations.get("OfflineMapText")[langIndex]);
        filterResults(searchField.getText().trim());
    }
}