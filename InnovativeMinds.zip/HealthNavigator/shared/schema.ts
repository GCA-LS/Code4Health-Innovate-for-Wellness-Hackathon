import { pgTable, text, serial, integer, boolean, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Facility types
export const facilities = pgTable("facilities", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // hospital, clinic, pharmacy
  address: text("address").notNull(),
  latitude: text("latitude").notNull(),
  longitude: text("longitude").notNull(),
  phone: text("phone").notNull(),
  website: text("website"),
  email: text("email"),
  services: text("services").array(),
  openingHours: jsonb("opening_hours").notNull(),
  isFavorite: boolean("is_favorite").default(false),
});

export const insertFacilitySchema = createInsertSchema(facilities).omit({
  id: true,
});

// Appointments
export const appointments = pgTable("appointments", {
  id: serial("id").primaryKey(),
  facilityId: integer("facility_id").notNull(),
  title: text("title").notNull(),
  date: timestamp("date").notNull(),
  notes: text("notes"),
  status: text("status").default("pending"), // pending, confirmed, completed, canceled
});

export const insertAppointmentSchema = createInsertSchema(appointments).omit({
  id: true,
});

// Reminders
export const reminders = pgTable("reminders", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  appointmentId: integer("appointment_id"),
  triggerTime: timestamp("trigger_time").notNull(),
  isActive: boolean("is_active").default(true),
});

export const insertReminderSchema = createInsertSchema(reminders).omit({
  id: true,
});

// Users
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Favorite facilities
export const favorites = pgTable("favorites", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  facilityId: integer("facility_id").notNull(),
});

export const insertFavoriteSchema = createInsertSchema(favorites).omit({
  id: true,
});

// Type definitions
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertFacility = z.infer<typeof insertFacilitySchema>;
export type Facility = typeof facilities.$inferSelect;

export type InsertAppointment = z.infer<typeof insertAppointmentSchema>;
export type Appointment = typeof appointments.$inferSelect;

export type InsertReminder = z.infer<typeof insertReminderSchema>;
export type Reminder = typeof reminders.$inferSelect;

export type InsertFavorite = z.infer<typeof insertFavoriteSchema>;
export type Favorite = typeof favorites.$inferSelect;
