import { 
  users, type User, type InsertUser,
  facilities, type Facility, type InsertFacility,
  appointments, type Appointment, type InsertAppointment,
  reminders, type Reminder, type InsertReminder,
  favorites, type Favorite, type InsertFavorite
} from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Facility operations
  getFacilities(): Promise<Facility[]>;
  getFacility(id: number): Promise<Facility | undefined>;
  getFacilitiesByType(type: string): Promise<Facility[]>;
  createFacility(facility: InsertFacility): Promise<Facility>;
  updateFacility(id: number, facility: Partial<InsertFacility>): Promise<Facility | undefined>;
  
  // Appointment operations
  getAppointments(): Promise<Appointment[]>;
  getAppointment(id: number): Promise<Appointment | undefined>;
  createAppointment(appointment: InsertAppointment): Promise<Appointment>;
  updateAppointment(id: number, appointment: Partial<InsertAppointment>): Promise<Appointment | undefined>;
  deleteAppointment(id: number): Promise<boolean>;
  
  // Reminder operations
  getReminders(): Promise<Reminder[]>;
  getReminder(id: number): Promise<Reminder | undefined>;
  createReminder(reminder: InsertReminder): Promise<Reminder>;
  updateReminder(id: number, reminder: Partial<InsertReminder>): Promise<Reminder | undefined>;
  deleteReminder(id: number): Promise<boolean>;
  
  // Favorite operations
  getFavorites(userId: number): Promise<Facility[]>;
  addFavorite(favorite: InsertFavorite): Promise<Favorite>;
  removeFavorite(userId: number, facilityId: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private facilities: Map<number, Facility>;
  private appointments: Map<number, Appointment>;
  private reminders: Map<number, Reminder>;
  private favorites: Map<number, Favorite>;
  
  private userIdCounter: number;
  private facilityIdCounter: number;
  private appointmentIdCounter: number;
  private reminderIdCounter: number;
  private favoriteIdCounter: number;

  constructor() {
    this.users = new Map();
    this.facilities = new Map();
    this.appointments = new Map();
    this.reminders = new Map();
    this.favorites = new Map();
    
    this.userIdCounter = 1;
    this.facilityIdCounter = 1;
    this.appointmentIdCounter = 1;
    this.reminderIdCounter = 1;
    this.favoriteIdCounter = 1;
    
    // Initialize with sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Sample healthcare facilities
    const sampleFacilities: InsertFacility[] = [
      {
        name: "General Hospital",
        type: "hospital",
        address: "123 Main Street, City",
        latitude: "37.7749",
        longitude: "-122.4194",
        phone: "(555) 123-4567",
        website: "https://generalhospital.example",
        email: "info@generalhospital.example",
        services: ["Emergency Care", "Surgery", "Pediatrics", "Cardiology"],
        openingHours: {
          monday: "24 hours",
          tuesday: "24 hours",
          wednesday: "24 hours",
          thursday: "24 hours",
          friday: "24 hours",
          saturday: "24 hours",
          sunday: "24 hours"
        },
        isFavorite: false
      },
      {
        name: "Community Clinic",
        type: "clinic",
        address: "456 Oak Avenue, City",
        latitude: "37.7695",
        longitude: "-122.4238",
        phone: "(555) 987-6543",
        website: "https://communityclinic.example",
        email: "info@communityclinic.example",
        services: ["Family Medicine", "Vaccinations", "Physical Therapy"],
        openingHours: {
          monday: "9:00 AM - 5:00 PM",
          tuesday: "9:00 AM - 5:00 PM",
          wednesday: "9:00 AM - 5:00 PM",
          thursday: "9:00 AM - 5:00 PM",
          friday: "9:00 AM - 5:00 PM",
          saturday: "10:00 AM - 2:00 PM",
          sunday: "Closed"
        },
        isFavorite: false
      },
      {
        name: "City Pharmacy",
        type: "pharmacy",
        address: "789 Pine Street, City",
        latitude: "37.7815",
        longitude: "-122.4158",
        phone: "(555) 456-7890",
        website: "https://citypharmacy.example",
        email: "info@citypharmacy.example",
        services: ["Prescription Filling", "Medication Counseling", "Vaccinations"],
        openingHours: {
          monday: "8:00 AM - 8:00 PM",
          tuesday: "8:00 AM - 8:00 PM",
          wednesday: "8:00 AM - 8:00 PM",
          thursday: "8:00 AM - 8:00 PM",
          friday: "8:00 AM - 8:00 PM",
          saturday: "9:00 AM - 6:00 PM",
          sunday: "10:00 AM - 4:00 PM"
        },
        isFavorite: false
      }
    ];
    
    sampleFacilities.forEach(facility => {
      this.createFacility(facility);
    });
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Facility operations
  async getFacilities(): Promise<Facility[]> {
    return Array.from(this.facilities.values());
  }

  async getFacility(id: number): Promise<Facility | undefined> {
    return this.facilities.get(id);
  }

  async getFacilitiesByType(type: string): Promise<Facility[]> {
    return Array.from(this.facilities.values()).filter(
      (facility) => facility.type === type,
    );
  }

  async createFacility(insertFacility: InsertFacility): Promise<Facility> {
    const id = this.facilityIdCounter++;
    const facility: Facility = { ...insertFacility, id };
    this.facilities.set(id, facility);
    return facility;
  }

  async updateFacility(id: number, facilityData: Partial<InsertFacility>): Promise<Facility | undefined> {
    const facility = this.facilities.get(id);
    if (!facility) return undefined;
    
    const updatedFacility = { ...facility, ...facilityData };
    this.facilities.set(id, updatedFacility);
    return updatedFacility;
  }

  // Appointment operations
  async getAppointments(): Promise<Appointment[]> {
    return Array.from(this.appointments.values());
  }

  async getAppointment(id: number): Promise<Appointment | undefined> {
    return this.appointments.get(id);
  }

  async createAppointment(insertAppointment: InsertAppointment): Promise<Appointment> {
    const id = this.appointmentIdCounter++;
    const appointment: Appointment = { ...insertAppointment, id };
    this.appointments.set(id, appointment);
    return appointment;
  }

  async updateAppointment(id: number, appointmentData: Partial<InsertAppointment>): Promise<Appointment | undefined> {
    const appointment = this.appointments.get(id);
    if (!appointment) return undefined;
    
    const updatedAppointment = { ...appointment, ...appointmentData };
    this.appointments.set(id, updatedAppointment);
    return updatedAppointment;
  }

  async deleteAppointment(id: number): Promise<boolean> {
    return this.appointments.delete(id);
  }

  // Reminder operations
  async getReminders(): Promise<Reminder[]> {
    return Array.from(this.reminders.values());
  }

  async getReminder(id: number): Promise<Reminder | undefined> {
    return this.reminders.get(id);
  }

  async createReminder(insertReminder: InsertReminder): Promise<Reminder> {
    const id = this.reminderIdCounter++;
    const reminder: Reminder = { ...insertReminder, id };
    this.reminders.set(id, reminder);
    return reminder;
  }

  async updateReminder(id: number, reminderData: Partial<InsertReminder>): Promise<Reminder | undefined> {
    const reminder = this.reminders.get(id);
    if (!reminder) return undefined;
    
    const updatedReminder = { ...reminder, ...reminderData };
    this.reminders.set(id, updatedReminder);
    return updatedReminder;
  }

  async deleteReminder(id: number): Promise<boolean> {
    return this.reminders.delete(id);
  }

  // Favorite operations
  async getFavorites(userId: number): Promise<Facility[]> {
    const userFavorites = Array.from(this.favorites.values()).filter(
      (favorite) => favorite.userId === userId,
    );
    
    return userFavorites.map(favorite => 
      this.facilities.get(favorite.facilityId)
    ).filter((facility): facility is Facility => facility !== undefined);
  }

  async addFavorite(insertFavorite: InsertFavorite): Promise<Favorite> {
    const id = this.favoriteIdCounter++;
    const favorite: Favorite = { ...insertFavorite, id };
    this.favorites.set(id, favorite);
    
    // Also update the isFavorite flag on the facility
    const facility = this.facilities.get(insertFavorite.facilityId);
    if (facility) {
      this.facilities.set(facility.id, { ...facility, isFavorite: true });
    }
    
    return favorite;
  }

  async removeFavorite(userId: number, facilityId: number): Promise<boolean> {
    const favorite = Array.from(this.favorites.values()).find(
      (fav) => fav.userId === userId && fav.facilityId === facilityId,
    );
    
    if (!favorite) return false;
    
    const result = this.favorites.delete(favorite.id);
    
    // Update the isFavorite flag on the facility
    if (result) {
      const facility = this.facilities.get(facilityId);
      if (facility) {
        this.facilities.set(facilityId, { ...facility, isFavorite: false });
      }
    }
    
    return result;
  }
}

export const storage = new MemStorage();
