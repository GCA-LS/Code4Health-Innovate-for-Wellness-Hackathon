import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { 
  MapPin, 
  Phone, 
  Globe, 
  Mail, 
  Clock, 
  Heart,
  ArrowRight,
  CalendarPlus
} from 'lucide-react';
import { Link } from 'wouter';
import { Facility } from '@shared/schema';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AppointmentForm } from './AppointmentForm';

interface FacilityCardProps {
  facility: Facility;
  showActions?: boolean;
  onFavoriteToggle?: (facility: Facility) => void;
}

export function FacilityCard({ facility, showActions = true, onFavoriteToggle }: FacilityCardProps) {
  const facilityTypeIcon = {
    hospital: "https://pixabay.com/get/g31afed9d39c1e4769b316451d1abfcb1b4492e96d0e0dd1c17eea5e927952c9b1666204fcf4f68da774a1a9ec87077bd5450b1568aa84e7fcd3ba8e3d3a2c47c_1280.jpg",
    clinic: "https://pixabay.com/get/gdc27d0ef0bfec09bfad22d893137888a64193dfbfa92d619dfaeb5611cb48abb4a84b7ed7f684935482cc66d56e62e961653d53e0503e9ad5e56ab8b0f1d4c7b_1280.jpg",
    pharmacy: "https://pixabay.com/get/g4f335e154ea875f397a359ebb0b9d95c488a434c9f26ac3be00790c7bdd05a643769d4f113f4efa305d59dfc55ca909584a9b8b14085988e9fabec29b8b0698d_1280.jpg"
  };

  const facilityIcon = facilityTypeIcon[facility.type as keyof typeof facilityTypeIcon] || facilityTypeIcon.hospital;

  // Get a preview of services (first 3)
  const servicesPreview = facility.services.slice(0, 3);
  const hasMoreServices = facility.services.length > 3;

  // Today's hours
  const daysOfWeek = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
  const today = daysOfWeek[new Date().getDay()];
  const todayHours = facility.openingHours[today as keyof typeof facility.openingHours] || 'Closed';

  return (
    <Card className="h-full flex flex-col">
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <CardTitle className="text-xl font-bold">{facility.name}</CardTitle>
          <Badge variant={facility.type === 'hospital' ? 'destructive' : 
                          facility.type === 'clinic' ? 'default' : 'secondary'}>
            {facility.type.charAt(0).toUpperCase() + facility.type.slice(1)}
          </Badge>
        </div>
      </CardHeader>

      <CardContent className="flex-1">
        <div className="space-y-3">
          <div className="flex items-start gap-2">
            <MapPin className="h-4 w-4 text-muted-foreground shrink-0 mt-1" />
            <span className="text-sm">{facility.address}</span>
          </div>

          <div className="flex items-center gap-2">
            <Phone className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm">{facility.phone}</span>
          </div>

          {facility.website && (
            <div className="flex items-center gap-2">
              <Globe className="h-4 w-4 text-muted-foreground" />
              <a 
                href={facility.website} 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-sm text-primary hover:underline"
              >
                Website
              </a>
            </div>
          )}

          {facility.email && (
            <div className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-muted-foreground" />
              <a 
                href={`mailto:${facility.email}`} 
                className="text-sm text-primary hover:underline"
              >
                {facility.email}
              </a>
            </div>
          )}

          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4 text-muted-foreground" />
            <span className="text-sm">Today: {todayHours}</span>
          </div>

          <div className="mt-4">
            <p className="text-sm font-medium mb-1">Services:</p>
            <div className="flex flex-wrap gap-1">
              {servicesPreview.map((service, index) => (
                <Badge key={index} variant="outline" className="text-xs">
                  {service}
                </Badge>
              ))}
              {hasMoreServices && (
                <Badge variant="outline" className="text-xs">
                  +{facility.services.length - 3} more
                </Badge>
              )}
            </div>
          </div>
        </div>
      </CardContent>

      {showActions && (
        <CardFooter className="flex justify-between pt-2 gap-2">
          <Button
            variant="outline"
            size="sm"
            className={facility.isFavorite ? "text-red-500" : ""}
            onClick={() => onFavoriteToggle?.(facility)}
            aria-label={facility.isFavorite ? "Remove from favorites" : "Add to favorites"}
          >
            <Heart className="h-4 w-4 mr-1" fill={facility.isFavorite ? "currentColor" : "none"} />
            {facility.isFavorite ? "Favorited" : "Favorite"}
          </Button>

          <div className="flex gap-2">
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm">
                  <CalendarPlus className="h-4 w-4 mr-1" />
                  Book
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Book Appointment at {facility.name}</DialogTitle>
                </DialogHeader>
                <AppointmentForm facilityId={facility.id} facilityName={facility.name} />
              </DialogContent>
            </Dialog>
            
            <Link href={`/facility/${facility.id}`}>
              <Button size="sm">
                Details
                <ArrowRight className="h-4 w-4 ml-1" />
              </Button>
            </Link>
          </div>
        </CardFooter>
      )}
    </Card>
  );
}
