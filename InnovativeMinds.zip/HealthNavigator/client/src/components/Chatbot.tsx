import { useState, useRef, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Mic, MicOff, Send, Bot, X } from 'lucide-react';
import { useSpeechRecognition } from '@/hooks/use-speech-recognition';
import { useTextToSpeech } from '@/hooks/use-text-to-speech';
import { getBotResponse } from '@/lib/chatbot';
import { ScrollArea } from '@/components/ui/scroll-area';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'bot';
  timestamp: Date;
}

export function Chatbot() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'Hello! I can help you find healthcare facilities, schedule appointments, or answer questions about our services. How can I assist you today?',
      sender: 'bot',
      timestamp: new Date()
    }
  ]);
  const [input, setInput] = useState('');
  const [isOpen, setIsOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Speech recognition setup
  const { 
    transcript, 
    isListening, 
    startListening, 
    stopListening, 
    resetTranscript,
    hasSupport: hasSpeechRecognition
  } = useSpeechRecognition({
    onResult: (result) => {
      setInput(result);
    }
  });

  // Text to speech setup
  const {
    speak,
    stop: stopSpeaking,
    hasSupport: hasSpeechSynthesis
  } = useTextToSpeech();

  // Scroll to the bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Disable transcript auto-updating for now to fix infinite loop
  useEffect(() => {
    if (isListening && transcript && transcript !== input && input === '') {
      setInput(transcript);
    }
  }, [transcript, isListening, input]);

  const handleSendMessage = async () => {
    if (!input.trim()) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      text: input,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setInput('');
    resetTranscript();

    // Get bot response
    const botResponse = await getBotResponse(input);
    
    // Add bot message
    const botMessage: Message = {
      id: (Date.now() + 1).toString(),
      text: botResponse,
      sender: 'bot',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, botMessage]);
    
    // Speak the response if text-to-speech is enabled
    if (hasSpeechSynthesis) {
      speak(botResponse);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSendMessage();
    }
  };

  const toggleMicrophone = () => {
    if (isListening) {
      stopListening();
    } else {
      resetTranscript();
      startListening();
    }
  };

  const toggleChatbot = () => {
    setIsOpen(!isOpen);
    if (isOpen) {
      stopSpeaking(); // Stop speaking when closing the chatbot
    }
  };

  return (
    <>
      {/* Floating button to open/close the chatbot */}
      <Button
        className="fixed bottom-4 right-4 rounded-full w-14 h-14 p-0 z-50"
        onClick={toggleChatbot}
        variant="default"
        aria-label="Chat with healthcare assistant"
      >
        {isOpen ? <X size={24} /> : <Bot size={24} />}
      </Button>

      {/* Chatbot dialog */}
      {isOpen && (
        <Card className="fixed bottom-20 right-4 w-80 sm:w-96 shadow-lg z-40 border-primary">
          <CardHeader className="bg-primary text-primary-foreground p-3">
            <CardTitle className="text-lg flex items-center">
              <Bot className="mr-2" size={20} />
              Healthcare Assistant
            </CardTitle>
          </CardHeader>
          
          <CardContent className="p-0">
            <ScrollArea className="h-80 p-4">
              {messages.map((message) => (
                <div
                  key={message.id}
                  className={`mb-4 ${
                    message.sender === 'user' ? 'text-right' : 'text-left'
                  }`}
                >
                  <div
                    className={`inline-block p-3 rounded-lg ${
                      message.sender === 'user'
                        ? 'bg-primary text-primary-foreground'
                        : 'bg-muted'
                    }`}
                  >
                    {message.text}
                  </div>
                  <div className="text-xs text-muted-foreground mt-1">
                    {message.timestamp.toLocaleTimeString([], { 
                      hour: '2-digit', 
                      minute: '2-digit' 
                    })}
                  </div>
                </div>
              ))}
              <div ref={messagesEndRef} />
            </ScrollArea>
          </CardContent>
          
          <CardFooter className="p-3 border-t">
            <div className="flex w-full items-center space-x-2">
              <Input
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Type a message..."
                className="flex-1"
              />
              
              {hasSpeechRecognition && (
                <Button
                  variant="outline"
                  size="icon"
                  onClick={toggleMicrophone}
                  aria-label={isListening ? "Stop voice input" : "Start voice input"}
                  className={isListening ? "bg-red-100" : ""}
                >
                  {isListening ? <MicOff size={20} /> : <Mic size={20} />}
                </Button>
              )}
              
              <Button 
                onClick={handleSendMessage} 
                disabled={!input.trim()}
                size="icon"
                aria-label="Send message"
              >
                <Send size={20} />
              </Button>
            </div>
          </CardFooter>
        </Card>
      )}
    </>
  );
}
