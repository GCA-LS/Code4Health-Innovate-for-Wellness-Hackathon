import { ReactNode, useState } from 'react';
import { Link, useLocation } from 'wouter';
import { Button } from '@/components/ui/button';
import {
  Hospital,
  Calendar,
  Clock,
  Menu,
  X,
  Home,
  Map as MapIcon,
  Search,
  SunMoon,
  Moon,
  Sun
} from 'lucide-react';
import { AccessibilityControls } from '@/components/AccessibilityControls';
import { Chatbot } from '@/components/Chatbot';
import { useTheme } from 'next-themes';

interface MainLayoutProps {
  children: ReactNode;
}

export function MainLayout({ children }: MainLayoutProps) {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { theme, setTheme } = useTheme();

  const toggleMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const isActive = (path: string) => {
    return location === path;
  };

  const toggleTheme = () => {
    setTheme(theme === 'dark' ? 'light' : 'dark');
  };

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header className="bg-primary text-primary-foreground py-3 px-4 shadow-md">
        <div className="container mx-auto flex justify-between items-center">
          <Link href="/">
            <a className="flex items-center space-x-2 text-lg font-bold">
              <Hospital size={24} />
              <span>Health Resource Finder</span>
            </a>
          </Link>

          {/* Mobile menu button */}
          <Button
            variant="ghost"
            size="icon"
            className="md:hidden"
            onClick={toggleMenu}
            aria-label={isMobileMenuOpen ? "Close menu" : "Open menu"}
          >
            {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </Button>

          {/* Desktop navigation */}
          <nav className="hidden md:flex items-center space-x-4">
            <Link href="/">
              <a className={`px-3 py-2 rounded-md hover:bg-primary-foreground/10 flex items-center ${isActive('/') ? 'bg-primary-foreground/20' : ''}`}>
                <Home size={20} className="mr-2" />
                Home
              </a>
            </Link>
            <Link href="/facilities">
              <a className={`px-3 py-2 rounded-md hover:bg-primary-foreground/10 flex items-center ${isActive('/facilities') ? 'bg-primary-foreground/20' : ''}`}>
                <MapIcon size={20} className="mr-2" />
                Facilities
              </a>
            </Link>
            <Link href="/appointments">
              <a className={`px-3 py-2 rounded-md hover:bg-primary-foreground/10 flex items-center ${isActive('/appointments') ? 'bg-primary-foreground/20' : ''}`}>
                <Calendar size={20} className="mr-2" />
                Appointments
              </a>
            </Link>
            <Link href="/reminders">
              <a className={`px-3 py-2 rounded-md hover:bg-primary-foreground/10 flex items-center ${isActive('/reminders') ? 'bg-primary-foreground/20' : ''}`}>
                <Clock size={20} className="mr-2" />
                Reminders
              </a>
            </Link>
            <Button 
              variant="ghost" 
              size="icon" 
              onClick={toggleTheme}
              aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
            >
              {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
            </Button>
            <AccessibilityControls />
          </nav>
        </div>
      </header>

      {/* Mobile menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-background border-b">
          <nav className="container mx-auto py-2 px-4">
            <ul className="space-y-2">
              <li>
                <Link href="/">
                  <a 
                    className={`flex items-center px-3 py-2 rounded-md ${isActive('/') ? 'bg-muted' : ''}`}
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <Home size={20} className="mr-2" />
                    Home
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/facilities">
                  <a 
                    className={`flex items-center px-3 py-2 rounded-md ${isActive('/facilities') ? 'bg-muted' : ''}`}
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <MapIcon size={20} className="mr-2" />
                    Facilities
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/appointments">
                  <a 
                    className={`flex items-center px-3 py-2 rounded-md ${isActive('/appointments') ? 'bg-muted' : ''}`}
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <Calendar size={20} className="mr-2" />
                    Appointments
                  </a>
                </Link>
              </li>
              <li>
                <Link href="/reminders">
                  <a 
                    className={`flex items-center px-3 py-2 rounded-md ${isActive('/reminders') ? 'bg-muted' : ''}`}
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <Clock size={20} className="mr-2" />
                    Reminders
                  </a>
                </Link>
              </li>
              <li>
                <div className="flex items-center justify-between px-3 py-2">
                  <span className="flex items-center">
                    <SunMoon size={20} className="mr-2" />
                    Theme
                  </span>
                  <Button 
                    variant="ghost" 
                    size="icon" 
                    onClick={toggleTheme}
                    aria-label={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
                  >
                    {theme === 'dark' ? <Sun size={20} /> : <Moon size={20} />}
                  </Button>
                </div>
              </li>
              <li>
                <div className="px-3 py-2">
                  <AccessibilityControls />
                </div>
              </li>
            </ul>
          </nav>
        </div>
      )}

      {/* Main content */}
      <main className="flex-1 container mx-auto py-6 px-4">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-muted py-4 px-4">
        <div className="container mx-auto text-center text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} Health Resource Finder</p>
          <p className="mt-1">Making healthcare resources accessible for everyone</p>
        </div>
      </footer>

      {/* Chatbot */}
      <Chatbot />
    </div>
  );
}
