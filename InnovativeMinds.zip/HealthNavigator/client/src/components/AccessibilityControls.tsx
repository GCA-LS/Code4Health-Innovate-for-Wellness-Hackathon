import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { VolumeX, Volume2, Eye, EyeOff } from 'lucide-react';
import { 
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { useTextToSpeech } from '@/hooks/use-text-to-speech';

export function AccessibilityControls() {
  const [highContrast, setHighContrast] = useState(false);
  const [largeText, setLargeText] = useState(false);
  const [screenReader, setScreenReader] = useState(false);
  const [fontSize, setFontSize] = useState(100);
  
  const { speak, hasSupport: ttsSupported } = useTextToSpeech();

  // Apply high contrast mode
  const toggleHighContrast = () => {
    setHighContrast(!highContrast);
    document.documentElement.classList.toggle('high-contrast');
  };

  // Apply large text mode
  const toggleLargeText = () => {
    setLargeText(!largeText);
    if (!largeText) {
      document.documentElement.style.fontSize = `${fontSize}%`;
    } else {
      document.documentElement.style.fontSize = '100%';
    }
  };

  // Update font size dynamically
  const handleFontSizeChange = (value: number[]) => {
    const newSize = value[0];
    setFontSize(newSize);
    if (largeText) {
      document.documentElement.style.fontSize = `${newSize}%`;
    }
  };

  // Toggle screen reader functionality
  const toggleScreenReader = () => {
    setScreenReader(!screenReader);
    if (!screenReader && ttsSupported) {
      speak("Screen reader activated. Use the tab key to navigate and press enter to select items.");
    }
  };

  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="outline" size="icon" aria-label="Accessibility options">
          <Eye size={20} />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-80" align="end">
        <div className="space-y-4">
          <h3 className="font-medium text-lg">Accessibility Options</h3>
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="high-contrast">High Contrast</Label>
              <p className="text-sm text-muted-foreground">
                Enhance color contrast for better visibility
              </p>
            </div>
            <Switch
              id="high-contrast"
              checked={highContrast}
              onCheckedChange={toggleHighContrast}
              aria-label="Toggle high contrast mode"
            />
          </div>
          
          <div className="flex items-center justify-between">
            <div className="space-y-0.5">
              <Label htmlFor="large-text">Large Text</Label>
              <p className="text-sm text-muted-foreground">
                Increase text size for better readability
              </p>
            </div>
            <Switch
              id="large-text"
              checked={largeText}
              onCheckedChange={toggleLargeText}
              aria-label="Toggle large text mode"
            />
          </div>
          
          {largeText && (
            <div className="space-y-2">
              <Label>Text Size: {fontSize}%</Label>
              <Slider
                defaultValue={[fontSize]}
                min={100}
                max={200}
                step={10}
                onValueChange={handleFontSizeChange}
                aria-label="Adjust font size"
              />
            </div>
          )}
          
          {ttsSupported && (
            <div className="flex items-center justify-between">
              <div className="space-y-0.5">
                <Label htmlFor="screen-reader">Screen Reader</Label>
                <p className="text-sm text-muted-foreground">
                  Enable voice guidance for navigation
                </p>
              </div>
              <Switch
                id="screen-reader"
                checked={screenReader}
                onCheckedChange={toggleScreenReader}
                aria-label="Toggle screen reader"
              />
            </div>
          )}
          
          <p className="text-xs text-muted-foreground mt-2">
            For voice input, use the mic button in the chatbot. For voice output, enable the screen reader or use the chatbot's speech function.
          </p>
        </div>
      </PopoverContent>
    </Popover>
  );
}
