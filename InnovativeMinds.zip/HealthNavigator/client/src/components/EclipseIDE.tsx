import { useState, useEffect } from 'react';
import { 
  ChevronRight, 
  ChevronDown, 
  File, 
  Folder, 
  Code, 
  Play, 
  Save,
  Settings,
  X,
  Archive,
  Bug,
  Search,
  FileText,
  Terminal,
  Coffee
} from 'lucide-react';

// Sample file structure for demo purposes
const initialFileStructure = [
  {
    id: '1',
    name: 'src',
    type: 'folder',
    expanded: true,
    children: [
      {
        id: '2',
        name: 'main',
        type: 'folder',
        expanded: true,
        children: [
          {
            id: '3',
            name: 'java',
            type: 'folder',
            expanded: true,
            children: [
              {
                id: '4',
                name: 'com',
                type: 'folder',
                expanded: true,
                children: [
                  {
                    id: '5',
                    name: 'example',
                    type: 'folder',
                    expanded: true,
                    children: [
                      {
                        id: '6',
                        name: 'Main.java',
                        type: 'file',
                        language: 'java',
                        content: 'package com.example;\n\npublic class Main {\n\n    public static void main(String[] args) {\n        System.out.println("Hello, Eclipse!");\n    }\n}'
                      },
                      {
                        id: '7',
                        name: 'User.java',
                        type: 'file',
                        language: 'java',
                        content: 'package com.example;\n\npublic class User {\n    private String name;\n    private String email;\n\n    public User(String name, String email) {\n        this.name = name;\n        this.email = email;\n    }\n\n    public String getName() {\n        return name;\n    }\n\n    public void setName(String name) {\n        this.name = name;\n    }\n\n    public String getEmail() {\n        return email;\n    }\n\n    public void setEmail(String email) {\n        this.email = email;\n    }\n}'
                      }
                    ]
                  }
                ]
              }
            ]
          },
          {
            id: '8',
            name: 'resources',
            type: 'folder',
            expanded: false,
            children: [
              {
                id: '9',
                name: 'application.properties',
                type: 'file',
                language: 'properties',
                content: 'app.name=Eclipse Demo\napp.version=1.0.0\nspring.profiles.active=dev'
              }
            ]
          }
        ]
      },
      {
        id: '10',
        name: 'test',
        type: 'folder',
        expanded: false,
        children: [
          {
            id: '11',
            name: 'java',
            type: 'folder',
            expanded: false,
            children: [
              {
                id: '12',
                name: 'com',
                type: 'folder',
                expanded: false,
                children: [
                  {
                    id: '13',
                    name: 'example',
                    type: 'folder',
                    expanded: false,
                    children: [
                      {
                        id: '14',
                        name: 'MainTest.java',
                        type: 'file',
                        language: 'java',
                        content: 'package com.example;\n\nimport org.junit.Test;\nimport static org.junit.Assert.*;\n\npublic class MainTest {\n\n    @Test\n    public void testMain() {\n        // Test implementation\n        assertTrue(true);\n    }\n}'
                      }
                    ]
                  }
                ]
              }
            ]
          }
        ]
      }
    ]
  },
  {
    id: '15',
    name: 'pom.xml',
    type: 'file',
    language: 'xml',
    content: '<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"\n  xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/maven-v4_0_0.xsd">\n  <modelVersion>4.0.0</modelVersion>\n  <groupId>com.example</groupId>\n  <artifactId>eclipse-demo</artifactId>\n  <packaging>jar</packaging>\n  <version>1.0-SNAPSHOT</version>\n  <name>eclipse-demo</name>\n  <url>http://maven.apache.org</url>\n  <dependencies>\n    <dependency>\n      <groupId>junit</groupId>\n      <artifactId>junit</artifactId>\n      <version>4.12</version>\n      <scope>test</scope>\n    </dependency>\n  </dependencies>\n</project>'
  },
  {
    id: '16',
    name: '.classpath',
    type: 'file',
    language: 'xml',
    content: '<?xml version="1.0" encoding="UTF-8"?>\n<classpath>\n\t<classpathentry kind="src" output="target/classes" path="src/main/java"/>\n\t<classpathentry kind="src" output="target/test-classes" path="src/test/java"/>\n\t<classpathentry kind="con" path="org.eclipse.jdt.launching.JRE_CONTAINER"/>\n\t<classpathentry kind="con" path="org.eclipse.m2e.MAVEN2_CLASSPATH_CONTAINER"/>\n\t<classpathentry kind="output" path="target/classes"/>\n</classpath>'
  }
];

// Sample problems list
const initialProblems = [
  {
    id: '1',
    type: 'error' as const,
    message: 'The import org.junit cannot be resolved',
    resource: 'MainTest.java',
    path: '/src/test/java/com/example/MainTest.java',
    lineNumber: 3
  },
  {
    id: '2',
    type: 'warning' as const,
    message: 'The value of the local variable name is not used',
    resource: 'User.java',
    path: '/src/main/java/com/example/User.java',
    lineNumber: 8
  }
];

// Sample console output
const initialConsoleOutput = [
  '[INFO] Scanning for projects...',
  '[INFO] -------------------------< com.example:eclipse-demo >-------------------------',
  '[INFO] Building eclipse-demo 1.0-SNAPSHOT',
  '[INFO] --------------------------------[ jar ]---------------------------------',
  '[INFO] --- maven-clean-plugin:2.5:clean (default-clean) @ eclipse-demo ---',
  '[INFO] Deleting /workspace/eclipse-demo/target',
  '[INFO] --- maven-resources-plugin:2.6:resources (default-resources) @ eclipse-demo ---',
  '[INFO] Using \'UTF-8\' encoding to copy filtered resources.',
  '[INFO] skip non existing resourceDirectory /workspace/eclipse-demo/src/main/resources',
  '[INFO] --- maven-compiler-plugin:3.1:compile (default-compile) @ eclipse-demo ---',
  '[INFO] Changes detected - recompiling the module!',
  '[INFO] Compiling 2 source files to /workspace/eclipse-demo/target/classes',
  '[INFO] --- maven-resources-plugin:2.6:testResources (default-testResources) @ eclipse-demo ---',
  '[INFO] Using \'UTF-8\' encoding to copy filtered resources.',
  '[INFO] skip non existing resourceDirectory /workspace/eclipse-demo/src/test/resources',
  '[INFO] --- maven-compiler-plugin:3.1:testCompile (default-testCompile) @ eclipse-demo ---',
  '[INFO] Changes detected - recompiling the module!',
  '[INFO] Compiling 1 source file to /workspace/eclipse-demo/target/test-classes',
  '[INFO] -------------------------------------------------------------',
  '[ERROR] COMPILATION ERROR : ',
  '[INFO] -------------------------------------------------------------',
  '[ERROR] /workspace/eclipse-demo/src/test/java/com/example/MainTest.java:[3,17] package org.junit does not exist',
  '[ERROR] /workspace/eclipse-demo/src/test/java/com/example/MainTest.java:[4,1] static import only from classes and interfaces',
  '[ERROR] /workspace/eclipse-demo/src/test/java/com/example/MainTest.java:[8,5] cannot find symbol',
  '[ERROR]   symbol:   class Test',
  '[ERROR]   location: class com.example.MainTest',
  '[INFO] 4 errors ',
  '[INFO] -------------------------------------------------------------',
  '[INFO] BUILD FAILURE',
  '[INFO] -------------------------------------------------------------',
  '[INFO] Total time:  1.234 s',
  '[INFO] Finished at: 2023-01-01T12:00:00Z',
  '[INFO] -------------------------------------------------------------'
];

interface TreeItem {
  id: string;
  name: string;
  type: 'file' | 'folder';
  language?: string;
  content?: string;
  expanded?: boolean;
  children?: TreeItem[];
}

type TreeItemWithStringType = {
  id: string;
  name: string;
  type: string;
  language?: string;
  content?: string;
  expanded?: boolean;
  children?: TreeItemWithStringType[];
};

interface Tab {
  id: string;
  name: string;
  content: string;
  language: string;
  path: string;
}

interface Problem {
  id: string;
  type: 'error' | 'warning' | 'info';
  message: string;
  resource: string;
  path: string;
  lineNumber: number;
}

export default function EclipseIDE() {
  const [fileStructure, setFileStructure] = useState<TreeItem[]>(initialFileStructure as unknown as TreeItem[]);
  const [openTabs, setOpenTabs] = useState<Tab[]>([]);
  const [activeTab, setActiveTab] = useState<string | null>(null);
  const [problems, setProblems] = useState<Problem[]>(initialProblems as Problem[]);
  const [consoleOutput, setConsoleOutput] = useState<string[]>(initialConsoleOutput);
  const [consoleVisible, setConsoleVisible] = useState(false);
  const [isDarkTheme, setIsDarkTheme] = useState(false);

  // Function to toggle folder expansion
  const toggleFolder = (id: string) => {
    const updateExpanded = (items: TreeItem[]): TreeItem[] => {
      return items.map(item => {
        if (item.id === id) {
          return { ...item, expanded: !item.expanded };
        }
        if (item.children) {
          return { ...item, children: updateExpanded(item.children) };
        }
        return item;
      });
    };
    
    setFileStructure(updateExpanded(fileStructure));
  };

  // Function to open a file in a tab
  const openFile = (file: TreeItem, path: string = '') => {
    if (file.type !== 'file') return;
    
    const currentPath = path ? path + '/' + file.name : file.name;
    
    // Check if the file is already open
    if (!openTabs.some(tab => tab.id === file.id)) {
      const newTab: Tab = {
        id: file.id,
        name: file.name,
        content: file.content || '',
        language: file.language || 'text',
        path: currentPath
      };
      
      setOpenTabs([...openTabs, newTab]);
    }
    
    setActiveTab(file.id);
  };

  // Function to close a tab
  const closeTab = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    const updatedTabs = openTabs.filter(tab => tab.id !== id);
    setOpenTabs(updatedTabs);
    
    // If we're closing the active tab, set a new active tab
    if (activeTab === id) {
      if (updatedTabs.length > 0) {
        setActiveTab(updatedTabs[updatedTabs.length - 1].id);
      } else {
        setActiveTab(null);
      }
    }
  };

  // Function to get the full path of a file
  const getFilePath = (file: TreeItem, items: TreeItem[], currentPath: string = ''): string => {
    for (const item of items) {
      if (item.id === file.id) {
        return currentPath ? currentPath + '/' + item.name : item.name;
      }
      
      if (item.children) {
        const path = getFilePath(file, item.children, currentPath ? currentPath + '/' + item.name : item.name);
        if (path) return path;
      }
    }
    
    return '';
  };

  // Function to render the file tree recursively
  const renderFileTree = (items: TreeItem[], parentPath: string = '') => {
    return (
      <ul className="eclipse-tree">
        {items.map(item => {
          const path = parentPath ? parentPath + '/' + item.name : item.name;
          
          if (item.type === 'folder') {
            return (
              <li key={item.id}>
                <div 
                  className={`eclipse-tree-item eclipse-folder`}
                  onClick={() => toggleFolder(item.id)}
                >
                  {item.expanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
                  <Folder size={16} />
                  {item.name}
                </div>
                {item.expanded && item.children && (
                  <div className="pl-4">
                    {renderFileTree(item.children, path)}
                  </div>
                )}
              </li>
            );
          } else {
            return (
              <li key={item.id}>
                <div 
                  className={`eclipse-tree-item eclipse-file ${activeTab === item.id ? 'selected' : ''}`}
                  onClick={() => openFile(item, parentPath)}
                >
                  <File size={16} />
                  {item.name}
                </div>
              </li>
            );
          }
        })}
      </ul>
    );
  };

  // Generate line numbers for editor
  const generateLineNumbers = (content: string) => {
    const lines = content.split('\n');
    return (
      <div className="eclipse-line-numbers">
        {lines.map((_, index) => (
          <div key={index}>{index + 1}</div>
        ))}
      </div>
    );
  };

  // Toggle dark theme
  const toggleTheme = () => {
    setIsDarkTheme(!isDarkTheme);
  };

  // Run the simulated build
  const runBuild = () => {
    setConsoleVisible(true);
    // Scroll to the bottom of the console
    setTimeout(() => {
      const consoleElem = document.querySelector('.eclipse-console-content');
      if (consoleElem) {
        consoleElem.scrollTop = consoleElem.scrollHeight;
      }
    }, 100);
  };

  // Calculate active tab content
  const activeTabContent = activeTab 
    ? openTabs.find(tab => tab.id === activeTab)?.content
    : null;

  return (
    <div className={`eclipse-workspace ${isDarkTheme ? 'eclipse-dark' : 'eclipse-theme'}`}>
      {/* Header - Menubar and toolbar */}
      <header className="eclipse-header">
        <div className="eclipse-menubar">
          <div className="eclipse-menu-item">File</div>
          <div className="eclipse-menu-item">Edit</div>
          <div className="eclipse-menu-item">Source</div>
          <div className="eclipse-menu-item">Refactor</div>
          <div className="eclipse-menu-item">Navigate</div>
          <div className="eclipse-menu-item">Search</div>
          <div className="eclipse-menu-item">Project</div>
          <div className="eclipse-menu-item">Run</div>
          <div className="eclipse-menu-item">Window</div>
          <div className="eclipse-menu-item">Help</div>
        </div>
      </header>
      
      {/* Toolbar */}
      <div className="eclipse-toolbar">
        <div className="eclipse-toolbar-button" onClick={runBuild}>
          <Play size={16} />
          Run
        </div>
        <div className="eclipse-toolbar-button">
          <Bug size={16} />
          Debug
        </div>
        <div className="eclipse-toolbar-button">
          <Save size={16} />
          Save
        </div>
        <div className="eclipse-toolbar-button">
          <Search size={16} />
          Search
        </div>
        <div className="eclipse-toolbar-button" onClick={toggleTheme}>
          <Settings size={16} />
          {isDarkTheme ? 'Light Theme' : 'Dark Theme'}
        </div>
      </div>
      
      {/* Sidebar with file explorer */}
      <div className="eclipse-sidebar">
        <div className="eclipse-panel-container">
          <div className="eclipse-panel-header">
            <span>Explorer</span>
          </div>
          <div className="eclipse-panel-content eclipse-explorer">
            {renderFileTree(fileStructure)}
          </div>
        </div>
      </div>
      
      {/* Main content area */}
      <div className="eclipse-main">
        {/* Tabs */}
        <div className="eclipse-tabs">
          {openTabs.map(tab => (
            <div 
              key={tab.id}
              className={`eclipse-tab ${activeTab === tab.id ? 'active' : ''}`}
              onClick={() => setActiveTab(tab.id)}
            >
              <File size={16} />
              {tab.name}
              <span className="eclipse-tab-close" onClick={(e) => closeTab(tab.id, e)}>
                <X size={14} />
              </span>
            </div>
          ))}
        </div>
        
        {/* Editor or Welcome Screen */}
        <div className="eclipse-editor">
          {activeTabContent ? (
            <>
              {generateLineNumbers(activeTabContent)}
              <pre className="eclipse-code">{activeTabContent}</pre>
            </>
          ) : (
            <div className="flex items-center justify-center w-full text-center">
              <div className="max-w-md p-8">
                <Coffee size={48} className="mx-auto mb-4" />
                <h2 className="text-2xl font-bold mb-2">Welcome to Eclipse IDE</h2>
                <p className="mb-4">Select a file from the explorer to begin editing</p>
              </div>
            </div>
          )}
        </div>
        
        {/* Problems and Console Panels */}
        {(problems.length > 0 || consoleVisible) && (
          <div className="eclipse-console">
            <div className="eclipse-tabs">
              <div className={`eclipse-tab ${!consoleVisible ? 'active' : ''}`} onClick={() => setConsoleVisible(false)}>
                <X size={14} className="text-red-500" />
                Problems ({problems.filter(p => p.type === 'error').length})
              </div>
              <div className={`eclipse-tab ${consoleVisible ? 'active' : ''}`} onClick={() => setConsoleVisible(true)}>
                <Terminal size={14} />
                Console
              </div>
            </div>
            
            <div className="eclipse-panel-content">
              {!consoleVisible ? (
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="px-2 py-1 text-left"></th>
                      <th className="px-2 py-1 text-left">Description</th>
                      <th className="px-2 py-1 text-left">Resource</th>
                      <th className="px-2 py-1 text-left">Path</th>
                      <th className="px-2 py-1 text-left">Location</th>
                    </tr>
                  </thead>
                  <tbody>
                    {problems.map(problem => (
                      <tr key={problem.id} className="hover:bg-gray-100 dark:hover:bg-gray-800">
                        <td className="px-2 py-1">
                          <span className={`eclipse-problem-marker eclipse-${problem.type}`}></span>
                        </td>
                        <td className="px-2 py-1">{problem.message}</td>
                        <td className="px-2 py-1">{problem.resource}</td>
                        <td className="px-2 py-1">{problem.path}</td>
                        <td className="px-2 py-1">line {problem.lineNumber}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              ) : (
                <div className="eclipse-console-content font-mono text-xs p-2 h-full overflow-auto">
                  {consoleOutput.map((line, index) => (
                    <div key={index} className={line.includes('[ERROR]') ? 'text-red-500' : ''}>
                      {line}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}
      </div>
      
      {/* Status bar */}
      <div className="eclipse-footer">
        <div className="eclipse-status-line">
          <div className="eclipse-status-items">
            <div className="eclipse-status-item">
              Eclipse IDE Demo
            </div>
            <div className="eclipse-status-item">
              Java Project
            </div>
            {activeTab && (
              <div className="eclipse-status-item">
                Line: 1, Column: 1
              </div>
            )}
          </div>
          <div className="eclipse-status-items">
            <div className="eclipse-status-item">
              UTF-8
            </div>
            <div className="eclipse-status-item">
              Java SE 11
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}