import { useState } from 'react';
import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { format } from 'date-fns';
import { CalendarIcon } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';
import { apiRequest } from '@/lib/queryClient';
import { insertAppointmentSchema } from '@shared/schema';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { ReminderForm } from './ReminderForm';

interface AppointmentFormProps {
  facilityId: number;
  facilityName: string;
}

// Extend the appointment schema for form validation
const formSchema = insertAppointmentSchema.extend({
  date: z.date({
    required_error: "Please select a date",
  }),
  time: z.string().min(1, "Please select a time"),
  createReminder: z.boolean().default(false),
});

type FormValues = z.infer<typeof formSchema>;

export function AppointmentForm({ facilityId, facilityName }: AppointmentFormProps) {
  const { toast } = useToast();
  const [showReminderForm, setShowReminderForm] = useState(false);
  const [appointmentId, setAppointmentId] = useState<number | null>(null);

  // Initialize form with default values
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      facilityId,
      title: '',
      date: undefined,
      time: '',
      notes: '',
      status: 'pending',
      createReminder: false,
    },
  });

  const onSubmit = async (data: FormValues) => {
    try {
      // Combine date and time for the API
      const dateTime = new Date(data.date);
      const [hours, minutes] = data.time.split(':').map(Number);
      dateTime.setHours(hours, minutes);

      // Create appointment payload
      const appointmentData = {
        facilityId: data.facilityId,
        title: data.title,
        date: dateTime.toISOString(),
        notes: data.notes,
        status: data.status,
      };

      // Submit appointment request
      const response = await apiRequest('POST', '/api/appointments', appointmentData);
      const appointment = await response.json();

      // Show success message
      toast({
        title: 'Appointment Scheduled',
        description: `Your appointment at ${facilityName} has been scheduled successfully.`,
      });

      // Reset form
      form.reset();

      // If user wants to create a reminder, show the reminder form
      if (data.createReminder) {
        setAppointmentId(appointment.id);
        setShowReminderForm(true);
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to schedule appointment. Please try again.',
        variant: 'destructive',
      });
      console.error('Appointment creation error:', error);
    }
  };

  // Time slots generation for the select input
  const generateTimeSlots = () => {
    const slots = [];
    for (let hour = 8; hour < 18; hour++) {
      for (let minute = 0; minute < 60; minute += 30) {
        const formattedHour = hour.toString().padStart(2, '0');
        const formattedMinute = minute.toString().padStart(2, '0');
        slots.push(`${formattedHour}:${formattedMinute}`);
      }
    }
    return slots;
  };

  const timeSlots = generateTimeSlots();

  return (
    <>
      <Form {...form}>
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
          <FormField
            control={form.control}
            name="title"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Appointment Title</FormLabel>
                <FormControl>
                  <Input placeholder="e.g., Annual Check-up" {...field} />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <FormField
              control={form.control}
              name="date"
              render={({ field }) => (
                <FormItem className="flex flex-col">
                  <FormLabel>Date</FormLabel>
                  <Popover>
                    <PopoverTrigger asChild>
                      <FormControl>
                        <Button
                          variant={"outline"}
                          className={cn(
                            "pl-3 text-left font-normal",
                            !field.value && "text-muted-foreground"
                          )}
                        >
                          {field.value ? (
                            format(field.value, "PPP")
                          ) : (
                            <span>Pick a date</span>
                          )}
                          <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                        </Button>
                      </FormControl>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={field.value}
                        onSelect={field.onChange}
                        disabled={(date) => date < new Date()}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="time"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Time</FormLabel>
                  <Select onValueChange={field.onChange} defaultValue={field.value}>
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select a time" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {timeSlots.map((time) => (
                        <SelectItem key={time} value={time}>
                          {time}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
          </div>

          <FormField
            control={form.control}
            name="notes"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Notes</FormLabel>
                <FormControl>
                  <Textarea 
                    placeholder="Add any additional information or special requests"
                    {...field}
                  />
                </FormControl>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="createReminder"
            render={({ field }) => (
              <FormItem className="flex flex-row items-center justify-between rounded-lg border p-3">
                <div className="space-y-0.5">
                  <FormLabel>Create a reminder</FormLabel>
                  <p className="text-sm text-muted-foreground">
                    Set a reminder for this appointment
                  </p>
                </div>
                <FormControl>
                  <Switch
                    checked={field.value}
                    onCheckedChange={field.onChange}
                  />
                </FormControl>
              </FormItem>
            )}
          />

          <Button type="submit" className="w-full">
            Schedule Appointment
          </Button>
        </form>
      </Form>

      {/* Reminder form dialog */}
      {showReminderForm && appointmentId && (
        <Dialog open={showReminderForm} onOpenChange={setShowReminderForm}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Set a Reminder</DialogTitle>
            </DialogHeader>
            <ReminderForm 
              appointmentId={appointmentId} 
              onComplete={() => setShowReminderForm(false)}
            />
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}
