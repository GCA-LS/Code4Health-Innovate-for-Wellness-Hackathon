import { useState, useEffect } from 'react';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle,
  CardDescription,
  CardFooter
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Search, 
  MapPin, 
  ArrowDownAZ,
  ArrowUpZA,
  Hospital, 
  Building2, 
  PillIcon,
  Loader2
} from 'lucide-react';
import { FacilityCard } from './FacilityCard';
import { Facility } from '@shared/schema';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useGeolocation } from '@/hooks/use-geolocation';
import { calculateDistance } from '@/lib/mapUtils';
import { Skeleton } from '@/components/ui/skeleton';

export function DirectoryList() {
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState('all');
  const [sortType, setSortType] = useState<'name-asc' | 'name-desc' | 'distance'>('distance');
  
  const queryClient = useQueryClient();
  const { data: location } = useGeolocation();
  
  // Fetch facilities
  const { data: facilities, isLoading, error } = useQuery({
    queryKey: ['/api/facilities'],
  });

  // Toggle facility favorite status
  const handleFavoriteToggle = async (facility: Facility) => {
    try {
      // Optimistically update UI
      const updatedFacility = { ...facility, isFavorite: !facility.isFavorite };
      
      queryClient.setQueryData(['/api/facilities'], (oldData: Facility[] | undefined) => {
        if (!oldData) return [updatedFacility];
        return oldData.map(f => f.id === facility.id ? updatedFacility : f);
      });
      
      // In a real app with user auth, we would call the API to update favorites
      // For this demo, we'll just update the facility directly
      await apiRequest('PATCH', `/api/facilities/${facility.id}`, { isFavorite: !facility.isFavorite });
    } catch (error) {
      console.error('Error toggling favorite:', error);
      
      // Revert optimistic update on error
      queryClient.invalidateQueries({ queryKey: ['/api/facilities'] });
    }
  };

  // Filter and sort facilities
  const filteredFacilities = facilities ? facilities
    // Apply search filter
    .filter((facility: Facility) => {
      const searchLower = searchTerm.toLowerCase();
      return (
        facility.name.toLowerCase().includes(searchLower) ||
        facility.address.toLowerCase().includes(searchLower) ||
        facility.services.some(service => service.toLowerCase().includes(searchLower))
      );
    })
    // Apply type filter
    .filter((facility: Facility) => {
      if (activeTab === 'all') return true;
      return facility.type === activeTab;
    })
    // Apply sorting
    .sort((a: Facility, b: Facility) => {
      if (sortType === 'name-asc') {
        return a.name.localeCompare(b.name);
      } else if (sortType === 'name-desc') {
        return b.name.localeCompare(a.name);
      } else if (sortType === 'distance' && location.latitude && location.longitude) {
        const distanceA = calculateDistance(
          { lat: location.latitude, lng: location.longitude },
          { lat: parseFloat(a.latitude), lng: parseFloat(a.longitude) }
        );
        const distanceB = calculateDistance(
          { lat: location.latitude, lng: location.longitude },
          { lat: parseFloat(b.latitude), lng: parseFloat(b.longitude) }
        );
        return distanceA - distanceB;
      }
      return 0;
    }) : [];

  // Loading skeletons
  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Healthcare Directory</CardTitle>
          <CardDescription>Loading healthcare facilities...</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i} className="overflow-hidden">
                <CardContent className="p-0">
                  <div className="p-4 space-y-3">
                    <Skeleton className="h-6 w-3/4" />
                    <Skeleton className="h-4 w-1/2" />
                    <div className="space-y-2">
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-full" />
                      <Skeleton className="h-4 w-3/4" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  // Error state
  if (error) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Error Loading Facilities</CardTitle>
        </CardHeader>
        <CardContent>
          <p>Failed to load healthcare facilities. Please try again later.</p>
          <Button onClick={() => queryClient.invalidateQueries({ queryKey: ['/api/facilities'] })} className="mt-4">
            Retry
          </Button>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Healthcare Directory</CardTitle>
        <CardDescription>Find healthcare facilities near you</CardDescription>
      </CardHeader>
      
      <CardContent>
        <div className="flex flex-col space-y-4">
          {/* Search and filter */}
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search by name, address, or service..."
                className="pl-8"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            
            <div className="flex gap-2">
              <Button
                variant={sortType === 'distance' ? 'default' : 'outline'}
                size="sm"
                className="whitespace-nowrap"
                onClick={() => setSortType('distance')}
              >
                <MapPin className="h-4 w-4 mr-1" />
                By Distance
              </Button>
              
              <Button
                variant={sortType === 'name-asc' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSortType('name-asc')}
              >
                <ArrowDownAZ className="h-4 w-4" />
              </Button>
              
              <Button
                variant={sortType === 'name-desc' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setSortType('name-desc')}
              >
                <ArrowUpZA className="h-4 w-4" />
              </Button>
            </div>
          </div>
          
          {/* Tabs by facility type */}
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-4 w-full">
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="hospital">
                <Hospital className="h-4 w-4 mr-1" />
                Hospitals
              </TabsTrigger>
              <TabsTrigger value="clinic">
                <Building2 className="h-4 w-4 mr-1" />
                Clinics
              </TabsTrigger>
              <TabsTrigger value="pharmacy">
                <PillIcon className="h-4 w-4 mr-1" />
                Pharmacies
              </TabsTrigger>
            </TabsList>
          </Tabs>
          
          {/* Results count */}
          <div className="text-sm text-muted-foreground">
            {filteredFacilities.length} 
            {filteredFacilities.length === 1 ? ' facility' : ' facilities'} found
          </div>
          
          {/* Results list */}
          {filteredFacilities.length === 0 ? (
            <div className="py-12 text-center">
              <Search className="h-12 w-12 mx-auto text-muted-foreground opacity-50" />
              <h3 className="mt-4 text-lg font-medium">No facilities found</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                Try adjusting your search or filter criteria
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-2">
              {filteredFacilities.map((facility: Facility) => (
                <FacilityCard 
                  key={facility.id} 
                  facility={facility} 
                  onFavoriteToggle={handleFavoriteToggle}
                />
              ))}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
