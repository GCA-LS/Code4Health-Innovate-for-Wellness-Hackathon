import { useRef, useEffect, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Facility } from '@shared/schema';
import { useGeolocation } from '@/hooks/use-geolocation';
import 'leaflet/dist/leaflet.css';
import * as L from 'leaflet';

// Need to fix Leaflet icon issue in browser environments
import icon from 'leaflet/dist/images/marker-icon.png';
import iconShadow from 'leaflet/dist/images/marker-shadow.png';

// Fix default icon issue
const DefaultIcon = L.icon({
  iconUrl: icon,
  shadowUrl: iconShadow,
  iconSize: [25, 41],
  iconAnchor: [12, 41]
});
L.Marker.prototype.options.icon = DefaultIcon;

interface MapProps {
  facilities: Facility[];
  onFacilitySelect?: (facility: Facility) => void;
  height?: string;
}

export function Map({ facilities, onFacilitySelect, height = '400px' }: MapProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const [mapInstance, setMapInstance] = useState<L.Map | null>(null);
  const markersRef = useRef<L.Marker[]>([]);
  const userMarkerRef = useRef<L.Marker | null>(null);
  const { data: location, loading: locationLoading, error: locationError } = useGeolocation();

  // Initialize the map
  useEffect(() => {
    if (!mapRef.current) return;

    // Default location (fallback)
    const defaultLocation = { lat: 37.7749, lng: -122.4194 }; // San Francisco

    // Create map only if it doesn't exist yet
    if (!mapInstance) {
      const map = L.map(mapRef.current).setView([defaultLocation.lat, defaultLocation.lng], 13);
      
      // Add the OpenStreetMap tile layer
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
        maxZoom: 19,
      }).addTo(map);
      
      setMapInstance(map);
      
      // Force map to update its container size
      setTimeout(() => {
        map.invalidateSize();
      }, 100);
    }

    return () => {
      // Cleanup by removing the map when component unmounts
      if (mapInstance) {
        mapInstance.remove();
        setMapInstance(null);
      }
    };
  }, []);

  // Update user location when it changes
  useEffect(() => {
    if (!mapInstance) return;

    // User location or default
    const defaultLocation = { lat: 37.7749, lng: -122.4194 }; // San Francisco
    const userLocation = location.latitude && location.longitude
      ? { lat: location.latitude, lng: location.longitude }
      : defaultLocation;

    // Remove previous user marker if exists
    if (userMarkerRef.current) {
      userMarkerRef.current.remove();
    }

    // Create user marker icon
    const userIcon = L.divIcon({
      className: 'user-location-marker',
      html: `<div style="background-color: #4285F4; width: 16px; height: 16px; border-radius: 50%; border: 2px solid white;"></div>`,
      iconSize: [20, 20],
      iconAnchor: [10, 10]
    });

    // Add user marker
    const marker = L.marker([userLocation.lat, userLocation.lng], {
      icon: userIcon,
      title: 'Your Location',
      zIndexOffset: 1000
    }).addTo(mapInstance);
    
    marker.bindPopup('<div><strong>Your Location</strong></div>');
    userMarkerRef.current = marker;

    // Center map on user location
    mapInstance.setView([userLocation.lat, userLocation.lng], mapInstance.getZoom());

  }, [mapInstance, location.latitude, location.longitude]);

  // Add facility markers when map is ready and facilities change
  useEffect(() => {
    if (!mapInstance || !facilities.length) return;

    // Clear existing markers
    markersRef.current.forEach(marker => marker.remove());
    markersRef.current = [];
    
    const markers: L.Marker[] = [];
    const markerBounds = L.latLngBounds([]);
    
    // Create custom icons for different facility types
    const icons = {
      hospital: L.divIcon({
        className: 'facility-marker hospital',
        html: `<div style="background-color: #ef4444; width: 12px; height: 12px; border-radius: 50%; border: 2px solid white;"></div>`,
        iconSize: [16, 16],
        iconAnchor: [8, 8]
      }),
      clinic: L.divIcon({
        className: 'facility-marker clinic',
        html: `<div style="background-color: #3b82f6; width: 12px; height: 12px; border-radius: 50%; border: 2px solid white;"></div>`,
        iconSize: [16, 16],
        iconAnchor: [8, 8]
      }),
      pharmacy: L.divIcon({
        className: 'facility-marker pharmacy',
        html: `<div style="background-color: #22c55e; width: 12px; height: 12px; border-radius: 50%; border: 2px solid white;"></div>`,
        iconSize: [16, 16],
        iconAnchor: [8, 8]
      })
    };

    facilities.forEach(facility => {
      const lat = parseFloat(facility.latitude);
      const lng = parseFloat(facility.longitude);
      
      // Skip if invalid coordinates
      if (isNaN(lat) || isNaN(lng)) {
        console.warn(`Invalid coordinates for facility: ${facility.name}`);
        return;
      }
      
      // Get the appropriate icon
      const icon = icons[facility.type as keyof typeof icons] || icons.hospital;
      
      // Create marker
      const marker = L.marker([lat, lng], {
        icon: icon,
        title: facility.name
      }).addTo(mapInstance);
      
      // Create popup content
      const popupContent = `
        <div style="max-width: 200px; padding: 5px;">
          <h3 style="margin: 0 0 5px; font-size: 16px;">${facility.name}</h3>
          <p style="margin: 0 0 5px; font-size: 12px; color: #666;">
            <strong>${facility.type.charAt(0).toUpperCase() + facility.type.slice(1)}</strong>
          </p>
          <p style="margin: 0 0 5px; font-size: 13px;">${facility.address}</p>
          <p style="margin: 0; font-size: 13px;">${facility.phone}</p>
        </div>
      `;
      
      // Add popup
      marker.bindPopup(popupContent);
      
      // Add click event
      marker.on('click', () => {
        // If callback provided, call it
        if (onFacilitySelect) {
          onFacilitySelect(facility);
        }
      });
      
      // Extend bounds
      markerBounds.extend([lat, lng]);
      markers.push(marker);
    });
    
    // Store markers for cleanup
    markersRef.current = markers;
    
    // Only adjust bounds if we have facilities
    if (markers.length > 0) {
      mapInstance.fitBounds(markerBounds, {
        padding: [50, 50]
      });
    }
    
    // Resize map to make sure it renders correctly
    mapInstance.invalidateSize();
  }, [mapInstance, facilities, onFacilitySelect]);

  // Error states
  if (locationError && !mapInstance) {
    return (
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col items-center justify-center h-[400px]">
            <p className="text-destructive">
              Error accessing location: {locationError}. Using default location.
            </p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="overflow-hidden">
      <CardContent className="p-0">
        <div 
          ref={mapRef} 
          className="w-full" 
          style={{ height }}
          aria-label="Map showing healthcare facilities"
        />
      </CardContent>
    </Card>
  );
}
