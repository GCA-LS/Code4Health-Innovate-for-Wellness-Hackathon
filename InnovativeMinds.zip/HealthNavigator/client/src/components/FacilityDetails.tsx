import { useState } from 'react';
import { Facility } from '@shared/schema';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { AppointmentForm } from './AppointmentForm';
import { 
  MapPin, 
  Phone, 
  Globe, 
  Mail, 
  Clock, 
  Calendar, 
  Heart,
  Clipboard,
  Share2,
  ArrowLeft
} from 'lucide-react';
import { Link } from 'wouter';
import { Map } from './Map';
import { useToast } from '@/hooks/use-toast';

interface FacilityDetailsProps {
  facility: Facility;
  onFavoriteToggle?: (facility: Facility) => void;
  showBackButton?: boolean;
}

export function FacilityDetails({ facility, onFavoriteToggle, showBackButton = true }: FacilityDetailsProps) {
  const { toast } = useToast();
  const [copied, setCopied] = useState(false);

  // Format the opening hours nicely
  const openingHoursList = Object.entries(facility.openingHours).map(([day, hours]) => ({
    day: day.charAt(0).toUpperCase() + day.slice(1),
    hours
  }));

  // Handle copying address
  const copyAddress = () => {
    navigator.clipboard.writeText(facility.address);
    setCopied(true);
    
    toast({
      title: 'Address Copied',
      description: 'The facility address has been copied to your clipboard.',
    });
    
    setTimeout(() => setCopied(false), 2000);
  };

  // Handle sharing
  const shareFacility = () => {
    if (navigator.share) {
      navigator.share({
        title: facility.name,
        text: `Check out ${facility.name} at ${facility.address}`,
        url: window.location.href,
      }).catch(() => {
        toast({
          title: 'Sharing Failed',
          description: 'Could not share this facility information.',
          variant: 'destructive',
        });
      });
    } else {
      copyAddress();
    }
  };

  return (
    <div className="space-y-6">
      {showBackButton && (
        <Link href="/facilities" className="inline-block">
          <Button variant="ghost" className="mb-2">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Facilities
          </Button>
        </Link>
      )}
    
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <div className="flex justify-between items-start">
                <div>
                  <CardTitle className="text-2xl font-bold">{facility.name}</CardTitle>
                  <CardDescription>{facility.address}</CardDescription>
                </div>
                <Badge 
                  variant={facility.type === 'hospital' ? 'destructive' : 
                          facility.type === 'clinic' ? 'default' : 'secondary'}
                  className="text-sm"
                >
                  {facility.type.charAt(0).toUpperCase() + facility.type.slice(1)}
                </Badge>
              </div>
            </CardHeader>
            
            <CardContent>
              <Tabs defaultValue="info" className="mt-2">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="info">Information</TabsTrigger>
                  <TabsTrigger value="services">Services</TabsTrigger>
                </TabsList>
                
                <TabsContent value="info" className="space-y-4">
                  <div className="grid gap-4 mt-4">
                    <div className="flex items-center gap-2">
                      <Phone className="h-5 w-5 text-primary" />
                      <a href={`tel:${facility.phone}`} className="text-primary hover:underline">
                        {facility.phone}
                      </a>
                    </div>
                    
                    {facility.email && (
                      <div className="flex items-center gap-2">
                        <Mail className="h-5 w-5 text-primary" />
                        <a href={`mailto:${facility.email}`} className="text-primary hover:underline">
                          {facility.email}
                        </a>
                      </div>
                    )}
                    
                    {facility.website && (
                      <div className="flex items-center gap-2">
                        <Globe className="h-5 w-5 text-primary" />
                        <a 
                          href={facility.website} 
                          target="_blank" 
                          rel="noopener noreferrer" 
                          className="text-primary hover:underline"
                        >
                          Visit Website
                        </a>
                      </div>
                    )}
                    
                    <div className="flex items-start gap-2">
                      <Clock className="h-5 w-5 text-primary mt-1" />
                      <div>
                        <p className="font-medium">Opening Hours</p>
                        <div className="mt-1 grid grid-cols-1 md:grid-cols-2 gap-1 text-sm">
                          {openingHoursList.map((item) => (
                            <div key={item.day} className="flex justify-between">
                              <span className="font-medium mr-2">{item.day}</span>
                              <span>{item.hours}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                    
                    <div className="flex gap-2 mt-4">
                      <Button 
                        variant="outline" 
                        className="flex-1"
                        onClick={copyAddress}
                      >
                        <Clipboard className="h-4 w-4 mr-2" />
                        {copied ? 'Copied' : 'Copy Address'}
                      </Button>
                      
                      <Button 
                        variant="outline" 
                        className="flex-1"
                        onClick={shareFacility}
                      >
                        <Share2 className="h-4 w-4 mr-2" />
                        Share
                      </Button>
                      
                      <Button
                        variant="outline"
                        className={`flex-1 ${facility.isFavorite ? "text-red-500" : ""}`}
                        onClick={() => onFavoriteToggle?.(facility)}
                      >
                        <Heart 
                          className="h-4 w-4 mr-2" 
                          fill={facility.isFavorite ? "currentColor" : "none"} 
                        />
                        {facility.isFavorite ? "Favorited" : "Favorite"}
                      </Button>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="services">
                  <div className="mt-4">
                    <h3 className="font-medium mb-2">Available Services</h3>
                    <div className="flex flex-wrap gap-2">
                      {facility.services.map((service, index) => (
                        <Badge key={index} variant="outline">
                          {service}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
        
        <div>
          <Card className="h-full flex flex-col">
            <CardHeader>
              <CardTitle className="text-lg">Book Appointment</CardTitle>
              <CardDescription>
                Schedule an appointment at {facility.name}
              </CardDescription>
            </CardHeader>
            
            <CardContent className="flex-1 flex flex-col justify-between">
              <div>
                <p className="text-sm text-muted-foreground mb-6">
                  Select a date and time for your appointment with one of our healthcare providers.
                </p>
              </div>
              
              <Dialog>
                <DialogTrigger asChild>
                  <Button className="w-full">
                    <Calendar className="h-5 w-5 mr-2" />
                    Book Appointment
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Book Appointment at {facility.name}</DialogTitle>
                  </DialogHeader>
                  <AppointmentForm facilityId={facility.id} facilityName={facility.name} />
                </DialogContent>
              </Dialog>
            </CardContent>
          </Card>
        </div>
      </div>
      
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Location</CardTitle>
        </CardHeader>
        <CardContent>
          <Map 
            facilities={[facility]} 
            height="300px"
          />
          <div className="mt-4 flex gap-4">
            <Button 
              variant="outline" 
              className="flex-1"
              onClick={() => {
                window.open(`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(facility.address)}`, '_blank');
              }}
            >
              <MapPin className="h-4 w-4 mr-2" />
              Directions
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
