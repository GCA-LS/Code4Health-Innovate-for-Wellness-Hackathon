import { zodResolver } from '@hookform/resolvers/zod';
import { useForm } from 'react-hook-form';
import { z } from 'zod';
import { format } from 'date-fns';
import { CalendarIcon, Clock } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';
import { apiRequest } from '@/lib/queryClient';
import { insertReminderSchema } from '@shared/schema';

interface ReminderFormProps {
  appointmentId?: number;
  onComplete?: () => void;
}

// Extend the reminder schema for form validation
const formSchema = insertReminderSchema.extend({
  triggerDate: z.date({
    required_error: "Please select a date",
  }),
  triggerTime: z.string().min(1, "Please select a time"),
});

type FormValues = z.infer<typeof formSchema>;

export function ReminderForm({ appointmentId, onComplete }: ReminderFormProps) {
  const { toast } = useToast();

  // Initialize form with default values
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: appointmentId ? 'Appointment Reminder' : '',
      description: '',
      appointmentId: appointmentId || undefined,
      triggerDate: undefined,
      triggerTime: '',
      isActive: true,
    },
  });

  const onSubmit = async (data: FormValues) => {
    try {
      // Combine date and time for the API
      const triggerDate = new Date(data.triggerDate);
      const [hours, minutes] = data.triggerTime.split(':').map(Number);
      triggerDate.setHours(hours, minutes);

      // Create reminder payload
      const reminderData = {
        title: data.title,
        description: data.description,
        appointmentId: data.appointmentId,
        triggerTime: triggerDate.toISOString(),
        isActive: data.isActive,
      };

      // Submit reminder request
      await apiRequest('POST', '/api/reminders', reminderData);

      // Show success message
      toast({
        title: 'Reminder Set',
        description: 'Your reminder has been set successfully.',
      });

      // Reset form
      form.reset();
      
      // Call completion callback if provided
      if (onComplete) {
        onComplete();
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to set reminder. Please try again.',
        variant: 'destructive',
      });
      console.error('Reminder creation error:', error);
    }
  };

  // Time slots generation for the select input
  const generateTimeSlots = () => {
    const slots = [];
    for (let hour = 0; hour < 24; hour++) {
      for (let minute = 0; minute < 60; minute += 15) {
        const formattedHour = hour.toString().padStart(2, '0');
        const formattedMinute = minute.toString().padStart(2, '0');
        slots.push(`${formattedHour}:${formattedMinute}`);
      }
    }
    return slots;
  };

  const timeSlots = generateTimeSlots();

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField
          control={form.control}
          name="title"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Reminder Title</FormLabel>
              <FormControl>
                <Input placeholder="e.g., Take medication" {...field} />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <FormField
          control={form.control}
          name="description"
          render={({ field }) => (
            <FormItem>
              <FormLabel>Description</FormLabel>
              <FormControl>
                <Textarea 
                  placeholder="Add details about this reminder"
                  {...field}
                />
              </FormControl>
              <FormMessage />
            </FormItem>
          )}
        />

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <FormField
            control={form.control}
            name="triggerDate"
            render={({ field }) => (
              <FormItem className="flex flex-col">
                <FormLabel>Date</FormLabel>
                <Popover>
                  <PopoverTrigger asChild>
                    <FormControl>
                      <Button
                        variant={"outline"}
                        className={cn(
                          "pl-3 text-left font-normal",
                          !field.value && "text-muted-foreground"
                        )}
                      >
                        {field.value ? (
                          format(field.value, "PPP")
                        ) : (
                          <span>Pick a date</span>
                        )}
                        <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                      </Button>
                    </FormControl>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar
                      mode="single"
                      selected={field.value}
                      onSelect={field.onChange}
                      disabled={(date) => date < new Date()}
                      initialFocus
                    />
                  </PopoverContent>
                </Popover>
                <FormMessage />
              </FormItem>
            )}
          />

          <FormField
            control={form.control}
            name="triggerTime"
            render={({ field }) => (
              <FormItem>
                <FormLabel>Time</FormLabel>
                <Select onValueChange={field.onChange} defaultValue={field.value}>
                  <FormControl>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a time" />
                    </SelectTrigger>
                  </FormControl>
                  <SelectContent className="max-h-[200px]">
                    {timeSlots.map((time) => (
                      <SelectItem key={time} value={time}>
                        {time}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <FormMessage />
              </FormItem>
            )}
          />
        </div>

        <Button type="submit" className="w-full">
          Set Reminder
        </Button>
      </form>
    </Form>
  );
}
