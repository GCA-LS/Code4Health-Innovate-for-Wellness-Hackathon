import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "next-themes";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Facility from "@/pages/Facility";
import Facilities from "@/pages/Facilities";
import Appointments from "@/pages/Appointments";
import Reminders from "@/pages/Reminders";
import EclipsePage from "@/pages/EclipsePage";
import { MainLayout } from "@/components/layout/MainLayout";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/facilities" component={Facilities} />
      <Route path="/facility/:id" component={Facility} />
      <Route path="/appointments" component={Appointments} />
      <Route path="/reminders" component={Reminders} />
      <Route path="/eclipse" component={EclipsePage} />
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider attribute="class" defaultTheme="light">
        <TooltipProvider>
          <MainLayout>
            <Router />
          </MainLayout>
          <Toaster />
        </TooltipProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
