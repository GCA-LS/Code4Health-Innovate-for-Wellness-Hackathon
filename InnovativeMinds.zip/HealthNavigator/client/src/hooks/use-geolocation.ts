import { useState, useEffect } from 'react';

interface GeolocationOptions {
  enableHighAccuracy?: boolean;
  timeout?: number;
  maximumAge?: number;
}

interface GeolocationState {
  loading: boolean;
  error: string | null;
  data: {
    latitude: number | null;
    longitude: number | null;
    accuracy: number | null;
    timestamp: number | null;
  };
}

export function useGeolocation(options: GeolocationOptions = {}) {
  const [state, setState] = useState<GeolocationState>({
    loading: true,
    error: null,
    data: {
      latitude: null,
      longitude: null,
      accuracy: null,
      timestamp: null
    }
  });

  useEffect(() => {
    if (!navigator.geolocation) {
      setState(prevState => ({
        ...prevState,
        loading: false,
        error: 'Geolocation is not supported by your browser'
      }));
      return;
    }

    const geoOptions = {
      enableHighAccuracy: options.enableHighAccuracy || false,
      timeout: options.timeout || 5000,
      maximumAge: options.maximumAge || 0
    };

    const successHandler = (position: GeolocationPosition) => {
      setState({
        loading: false,
        error: null,
        data: {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude,
          accuracy: position.coords.accuracy,
          timestamp: position.timestamp
        }
      });
    };

    const errorHandler = (error: GeolocationPositionError) => {
      setState(prevState => ({
        ...prevState,
        loading: false,
        error: error.message
      }));
    };

    // Get position once
    navigator.geolocation.getCurrentPosition(
      successHandler,
      errorHandler,
      geoOptions
    );

    // Watch for position changes
    const watchId = navigator.geolocation.watchPosition(
      successHandler,
      errorHandler,
      geoOptions
    );

    // Clean up by clearing the watch
    return () => {
      navigator.geolocation.clearWatch(watchId);
    };
  }, [options.enableHighAccuracy, options.timeout, options.maximumAge]);

  return state;
}
