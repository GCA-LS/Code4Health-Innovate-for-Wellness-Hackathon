import { useState, useEffect, useCallback } from 'react';

// Check if browser supports SpeechRecognition
const SpeechRecognition = window.SpeechRecognition || (window as any).webkitSpeechRecognition;
const hasSpeechRecognition = !!SpeechRecognition;

interface UseSpeechRecognitionProps {
  onResult?: (transcript: string) => void;
  onError?: (error: Error) => void;
  continuous?: boolean;
  language?: string;
}

interface UseSpeechRecognitionReturn {
  isListening: boolean;
  transcript: string;
  error: Error | null;
  startListening: () => void;
  stopListening: () => void;
  resetTranscript: () => void;
  hasSupport: boolean;
}

export function useSpeechRecognition({
  onResult,
  onError,
  continuous = false,
  language = 'en-US'
}: UseSpeechRecognitionProps = {}): UseSpeechRecognitionReturn {
  const [recognition, setRecognition] = useState<any>(null);
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    if (!hasSpeechRecognition) return;
    
    const recognitionInstance = new SpeechRecognition();
    recognitionInstance.continuous = continuous;
    recognitionInstance.lang = language;
    recognitionInstance.interimResults = false;
    
    recognitionInstance.onresult = (event: any) => {
      const transcript = event.results[event.results.length - 1][0].transcript;
      setTranscript(prevTranscript => prevTranscript + ' ' + transcript);
      
      if (onResult) {
        onResult(transcript);
      }
    };
    
    recognitionInstance.onerror = (event: any) => {
      const error = new Error(`Speech recognition error: ${event.error}`);
      setError(error);
      
      if (onError) {
        onError(error);
      }
    };
    
    recognitionInstance.onend = () => {
      setIsListening(false);
    };
    
    setRecognition(recognitionInstance);
    
    return () => {
      if (recognitionInstance) {
        recognitionInstance.stop();
      }
    };
  }, [continuous, language, onError, onResult]);

  const startListening = useCallback(() => {
    if (!recognition) return;
    
    try {
      recognition.start();
      setIsListening(true);
      setError(null);
    } catch (err) {
      const error = err instanceof Error ? err : new Error('Unknown error starting speech recognition');
      setError(error);
      
      if (onError) {
        onError(error);
      }
    }
  }, [recognition, onError]);

  const stopListening = useCallback(() => {
    if (!recognition) return;
    
    try {
      recognition.stop();
      setIsListening(false);
    } catch (err) {
      const error = err instanceof Error ? err : new Error('Unknown error stopping speech recognition');
      setError(error);
      
      if (onError) {
        onError(error);
      }
    }
  }, [recognition, onError]);

  const resetTranscript = useCallback(() => {
    setTranscript('');
  }, []);

  return {
    isListening,
    transcript,
    error,
    startListening,
    stopListening,
    resetTranscript,
    hasSupport: hasSpeechRecognition
  };
}
