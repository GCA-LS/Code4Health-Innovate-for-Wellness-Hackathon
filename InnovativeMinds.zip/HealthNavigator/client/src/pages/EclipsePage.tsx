import { useEffect } from 'react';
import EclipseIDE from '@/components/EclipseIDE';

export default function EclipsePage() {
  // Add CSS to the body to ensure the Eclipse IDE takes up the full viewport
  useEffect(() => {
    // Save previous body styles
    const previousOverflow = document.body.style.overflow;
    const previousPadding = document.body.style.padding;
    const previousMargin = document.body.style.margin;
    
    // Apply styles for Eclipse IDE
    document.body.style.overflow = 'hidden';
    document.body.style.padding = '0';
    document.body.style.margin = '0';

    // Cleanup when component unmounts
    return () => {
      document.body.style.overflow = previousOverflow;
      document.body.style.padding = previousPadding;
      document.body.style.margin = previousMargin;
    };
  }, []);

  return (
    <div className="eclipse-fullscreen">
      <EclipseIDE />
    </div>
  );
}