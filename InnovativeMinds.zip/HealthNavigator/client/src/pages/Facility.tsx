import { useEffect } from 'react';
import { useRoute } from 'wouter';
import { FacilityDetails } from '@/components/FacilityDetails';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Skeleton } from '@/components/ui/skeleton';
import { Card, CardContent } from '@/components/ui/card';
import { apiRequest } from '@/lib/queryClient';
import { Facility } from '@shared/schema';

export default function FacilityPage() {
  const [match, params] = useRoute<{ id: string }>('/facility/:id');
  const facilityId = match ? parseInt(params.id) : 0;
  const queryClient = useQueryClient();

  const { data: facility, isLoading, error } = useQuery({
    queryKey: [`/api/facilities/${facilityId}`],
    enabled: !!facilityId,
  });

  // Toggle favorite status
  const handleFavoriteToggle = async (facility: Facility) => {
    try {
      // Optimistically update UI
      const updatedFacility = { ...facility, isFavorite: !facility.isFavorite };
      
      queryClient.setQueryData([`/api/facilities/${facilityId}`], updatedFacility);
      
      // Update global facilities list as well
      queryClient.setQueryData(['/api/facilities'], (oldData: Facility[] | undefined) => {
        if (!oldData) return [updatedFacility];
        return oldData.map(f => f.id === facility.id ? updatedFacility : f);
      });
      
      // In a real app with user auth, we would call the API to update favorites
      // For this demo, we'll just update the facility directly
      await apiRequest('PATCH', `/api/facilities/${facility.id}`, { isFavorite: !facility.isFavorite });
    } catch (error) {
      console.error('Error toggling favorite:', error);
      
      // Revert optimistic update on error
      queryClient.invalidateQueries({ queryKey: [`/api/facilities/${facilityId}`] });
      queryClient.invalidateQueries({ queryKey: ['/api/facilities'] });
    }
  };

  // Set page title
  useEffect(() => {
    if (facility) {
      document.title = `${facility.name} | Health Resource Finder`;
    } else {
      document.title = "Facility Details | Health Resource Finder";
    }
    
    return () => {
      document.title = "Health Resource Finder";
    };
  }, [facility]);

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-12 w-48" />
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2">
            <Card>
              <CardContent className="p-6">
                <Skeleton className="h-10 w-3/4 mb-4" />
                <Skeleton className="h-6 w-1/2 mb-8" />
                <div className="space-y-4">
                  {Array.from({ length: 5 }).map((_, index) => (
                    <Skeleton key={index} className="h-6 w-full" />
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
          <div>
            <Card>
              <CardContent className="p-6">
                <Skeleton className="h-8 w-3/4 mb-4" />
                <Skeleton className="h-6 w-full mb-2" />
                <Skeleton className="h-6 w-full mb-6" />
                <Skeleton className="h-10 w-full" />
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    );
  }

  if (error || !facility) {
    return (
      <Card>
        <CardContent className="p-6 text-center">
          <h2 className="text-xl font-bold mb-2">Facility Not Found</h2>
          <p className="text-muted-foreground mb-4">
            The facility you're looking for could not be found or has been removed.
          </p>
          <a href="/facilities" className="text-primary hover:underline">
            Return to Facilities Directory
          </a>
        </CardContent>
      </Card>
    );
  }

  return (
    <FacilityDetails 
      facility={facility} 
      onFavoriteToggle={handleFavoriteToggle}
    />
  );
}
