import { useState } from 'react';
import { Link } from 'wouter';
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Hospital, 
  Search, 
  MapPin, 
  Calendar, 
  Clock, 
  ArrowRight,
  Building2,
  PillIcon,
  BadgePlus,
  Speech,
  Code
} from 'lucide-react';
import { Map } from '@/components/Map';
import { Facility } from '@shared/schema';
import { useQuery } from '@tanstack/react-query';
import { useLocation } from 'wouter';

export default function Home() {
  const [_, navigate] = useLocation();
  
  // Fetch facilities for the map
  const { data: facilities = [], isLoading } = useQuery<Facility[]>({
    queryKey: ['/api/facilities'],
  });

  // Handle facility selection from map
  const handleFacilitySelect = (facility: Facility) => {
    navigate(`/facility/${facility.id}`);
  };

  return (
    <div className="space-y-6">
      <section className="mb-8">
        <div className="bg-primary text-primary-foreground rounded-lg p-8 shadow-lg relative overflow-hidden">
          <div className="max-w-3xl mx-auto text-center space-y-4">
            <h1 className="text-3xl md:text-4xl font-bold">Find Healthcare Resources Near You</h1>
            <p className="text-lg opacity-90">
              Discover nearby clinics, hospitals, and pharmacies with our easy-to-use health resource finder.
            </p>
            <div className="flex flex-col sm:flex-row justify-center gap-4 mt-6">
              <Button asChild size="lg" className="gap-2">
                <Link href="/facilities">
                  <Search className="h-5 w-5" />
                  Find Healthcare Resources
                </Link>
              </Button>
              <Button asChild size="lg" variant="outline" className="bg-primary-foreground/10 text-primary-foreground border-primary-foreground/20 hover:bg-primary-foreground/20 gap-2">
                <Link href="/appointments">
                  <Calendar className="h-5 w-5" />
                  Book an Appointment
                </Link>
              </Button>
            </div>
          </div>
          <div className="absolute inset-0 bg-gradient-to-r from-primary to-primary opacity-50 pointer-events-none"></div>
        </div>
      </section>

      <section className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-2xl font-bold">Healthcare Map</h2>
          <Button asChild variant="outline">
            <Link href="/facilities">
              See All <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </div>
        <Card>
          <CardContent className="p-0">
            <Map 
              facilities={facilities} 
              height="500px" 
              onFacilitySelect={handleFacilitySelect}
            />
          </CardContent>
        </Card>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-bold mb-4">Facility Types</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <Hospital className="h-8 w-8 text-red-500 mb-2" />
              <CardTitle>Hospitals</CardTitle>
              <CardDescription>
                Emergency and specialized care facilities
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Find hospitals offering emergency services, surgeries, and specialized medical care.
              </p>
            </CardContent>
            <CardFooter>
              <Button asChild variant="outline" className="w-full">
                <Link href="/facilities?type=hospital">
                  Find Hospitals <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <Building2 className="h-8 w-8 text-blue-500 mb-2" />
              <CardTitle>Clinics</CardTitle>
              <CardDescription>
                Primary care and outpatient services
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Discover clinics providing check-ups, vaccinations, and specialized outpatient care.
              </p>
            </CardContent>
            <CardFooter>
              <Button asChild variant="outline" className="w-full">
                <Link href="/facilities?type=clinic">
                  Find Clinics <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
            </CardFooter>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <PillIcon className="h-8 w-8 text-green-500 mb-2" />
              <CardTitle>Pharmacies</CardTitle>
              <CardDescription>
                Medication and health product providers
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Locate pharmacies for prescriptions, over-the-counter medications, and health supplies.
              </p>
            </CardContent>
            <CardFooter>
              <Button asChild variant="outline" className="w-full">
                <Link href="/facilities?type=pharmacy">
                  Find Pharmacies <ArrowRight className="ml-1 h-4 w-4" />
                </Link>
              </Button>
            </CardFooter>
          </Card>
        </div>
      </section>

      <section className="mb-8">
        <h2 className="text-2xl font-bold mb-4">Key Features</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          <Card>
            <CardHeader className="pb-2">
              <MapPin className="h-6 w-6 text-primary mb-2" />
              <CardTitle className="text-lg">Location Search</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Find healthcare resources close to your current location or any address.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <Speech className="h-6 w-6 text-primary mb-2" />
              <CardTitle className="text-lg">Voice Assistant</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Use voice commands to navigate and search for healthcare services.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <Calendar className="h-6 w-6 text-primary mb-2" />
              <CardTitle className="text-lg">Appointment Booking</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Schedule appointments with healthcare providers directly through the app.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-2">
              <Clock className="h-6 w-6 text-primary mb-2" />
              <CardTitle className="text-lg">Reminders</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                Set reminders for appointments and medications to stay on track.
              </p>
            </CardContent>
          </Card>
        </div>
      </section>

      <section>
        <Card className="bg-muted border-none">
          <CardHeader>
            <CardTitle className="text-xl text-center">Need Help Finding Healthcare Resources?</CardTitle>
            <CardDescription className="text-center">
              Our chatbot assistant can help you find the right healthcare facility for your needs.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex justify-center gap-4 flex-wrap">
            <Button onClick={() => alert("The chatbot assistant is already available in the bottom-right corner!")}>
              <BadgePlus className="mr-2 h-5 w-5" />
              Open Chatbot Assistant
            </Button>
            <Button variant="outline" asChild>
              <Link href="/eclipse">
                <Speech className="mr-2 h-5 w-5" />
                Try Eclipse IDE Demo
              </Link>
            </Button>
          </CardContent>
        </Card>
      </section>
    </div>
  );
}
