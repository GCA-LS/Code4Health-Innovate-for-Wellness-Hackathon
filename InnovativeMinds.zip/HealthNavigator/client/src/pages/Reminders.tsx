import { useEffect, useState } from 'react';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from '@/components/ui/card';
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Bell, 
  Calendar, 
  Clock, 
  Plus, 
  Edit3, 
  Trash2, 
  Power, 
  BellOff,
  Filter
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { format, isPast } from 'date-fns';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Switch } from '@/components/ui/switch';
import { ReminderForm } from '@/components/ReminderForm';
import { Skeleton } from '@/components/ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Reminder } from '@shared/schema';

export default function Reminders() {
  const [activeTab, setActiveTab] = useState('active');
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Fetch reminders
  const { data: reminders = [], isLoading } = useQuery({
    queryKey: ['/api/reminders'],
  });

  // Fetch appointments to get titles for reminders linked to appointments
  const { data: appointments = [] } = useQuery({
    queryKey: ['/api/appointments'],
  });

  // Set page title
  useEffect(() => {
    document.title = "Reminders | Health Resource Finder";
    
    return () => {
      document.title = "Health Resource Finder";
    };
  }, []);

  // Filter and sort reminders
  const filteredReminders = reminders
    .filter((reminder: Reminder) => {
      if (activeTab === 'active') {
        return reminder.isActive;
      } else if (activeTab === 'inactive') {
        return !reminder.isActive;
      } else if (activeTab === 'past') {
        return isPast(new Date(reminder.triggerTime));
      }
      return true;
    })
    .sort((a: Reminder, b: Reminder) => {
      // Sort by trigger time (soonest first for active, most recent first for past)
      const timeA = new Date(a.triggerTime).getTime();
      const timeB = new Date(b.triggerTime).getTime();
      
      return activeTab === 'past' ? timeB - timeA : timeA - timeB;
    });

  // Delete a reminder
  const handleDeleteReminder = async (id: number) => {
    try {
      if (!confirm('Are you sure you want to delete this reminder?')) {
        return;
      }
      
      await apiRequest('DELETE', `/api/reminders/${id}`, undefined);
      
      toast({
        title: 'Reminder Deleted',
        description: 'The reminder has been deleted successfully.',
      });
      
      // Refresh reminders
      queryClient.invalidateQueries({ queryKey: ['/api/reminders'] });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to delete reminder. Please try again.',
        variant: 'destructive',
      });
      console.error('Error deleting reminder:', error);
    }
  };

  // Toggle reminder active status
  const handleToggleActive = async (reminder: Reminder) => {
    try {
      await apiRequest('PATCH', `/api/reminders/${reminder.id}`, { 
        isActive: !reminder.isActive 
      });
      
      toast({
        title: reminder.isActive ? 'Reminder Deactivated' : 'Reminder Activated',
        description: `The reminder has been ${reminder.isActive ? 'deactivated' : 'activated'} successfully.`,
      });
      
      // Refresh reminders
      queryClient.invalidateQueries({ queryKey: ['/api/reminders'] });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update reminder. Please try again.',
        variant: 'destructive',
      });
      console.error('Error updating reminder:', error);
    }
  };

  // Get appointment title by ID
  const getAppointmentTitle = (appointmentId: number | null) => {
    if (!appointmentId) return null;
    
    const appointment = appointments.find((a: any) => a.id === appointmentId);
    return appointment ? appointment.title : null;
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
        <h1 className="text-2xl font-bold">Reminders</h1>
        
        <Dialog>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              New Reminder
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Reminder</DialogTitle>
            </DialogHeader>
            <ReminderForm onComplete={() => {
              queryClient.invalidateQueries({ queryKey: ['/api/reminders'] });
            }} />
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle>Your Reminders</CardTitle>
          <CardDescription>
            Manage your healthcare reminders and alerts
          </CardDescription>
          
          <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-4">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="active">Active</TabsTrigger>
              <TabsTrigger value="inactive">Inactive</TabsTrigger>
              <TabsTrigger value="past">Past</TabsTrigger>
            </TabsList>
          </Tabs>
        </CardHeader>
        
        <CardContent>
          {isLoading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-center justify-between p-4 border rounded-md">
                  <div className="space-y-2">
                    <Skeleton className="h-5 w-40" />
                    <Skeleton className="h-4 w-60" />
                  </div>
                  <Skeleton className="h-10 w-20" />
                </div>
              ))}
            </div>
          ) : filteredReminders.length === 0 ? (
            <div className="text-center py-8">
              <Bell className="h-12 w-12 mx-auto text-muted-foreground opacity-50" />
              <h3 className="mt-4 text-lg font-medium">No {activeTab} reminders found</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                {activeTab === 'active'
                  ? "You don't have any active reminders."
                  : activeTab === 'inactive'
                  ? "You don't have any inactive reminders."
                  : "You don't have any past reminders."}
              </p>
              <Button className="mt-4" asChild>
                <DialogTrigger>
                  <Plus className="h-4 w-4 mr-2" />
                  Create Reminder
                </DialogTrigger>
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Reminder</TableHead>
                    <TableHead>Date & Time</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredReminders.map((reminder: Reminder) => {
                    const appointmentTitle = getAppointmentTitle(reminder.appointmentId);
                    const isPastReminder = isPast(new Date(reminder.triggerTime));
                    
                    return (
                      <TableRow key={reminder.id}>
                        <TableCell className="font-medium">
                          {reminder.title}
                          {reminder.description && (
                            <p className="text-sm text-muted-foreground mt-1 line-clamp-1">
                              {reminder.description}
                            </p>
                          )}
                          {appointmentTitle && (
                            <Badge variant="outline" className="mt-1">
                              <Calendar className="h-3 w-3 mr-1" />
                              {appointmentTitle}
                            </Badge>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-col">
                            <span className="flex items-center">
                              <Calendar className="h-4 w-4 mr-1 text-muted-foreground" />
                              {format(new Date(reminder.triggerTime), 'MMM d, yyyy')}
                            </span>
                            <span className="flex items-center text-sm text-muted-foreground">
                              <Clock className="h-3 w-3 mr-1" />
                              {format(new Date(reminder.triggerTime), 'h:mm a')}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell>
                          {isPastReminder ? (
                            <Badge variant="secondary">Past</Badge>
                          ) : reminder.isActive ? (
                            <Badge variant="default" className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300">
                              Active
                            </Badge>
                          ) : (
                            <Badge variant="outline">Inactive</Badge>
                          )}
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex items-center justify-end gap-2">
                            <Dialog>
                              <DialogTrigger asChild>
                                <Button variant="outline" size="sm">
                                  <Edit3 className="h-4 w-4" />
                                  <span className="sr-only">Edit</span>
                                </Button>
                              </DialogTrigger>
                              <DialogContent>
                                <DialogHeader>
                                  <DialogTitle>Edit Reminder</DialogTitle>
                                </DialogHeader>
                                {/* In a real app, this would be an edit form with the reminder data pre-filled */}
                                <p className="text-center text-muted-foreground py-4">
                                  Editing functionality would be implemented here
                                </p>
                              </DialogContent>
                            </Dialog>
                            
                            {!isPastReminder && (
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleToggleActive(reminder)}
                              >
                                {reminder.isActive ? (
                                  <BellOff className="h-4 w-4 text-amber-500" />
                                ) : (
                                  <Bell className="h-4 w-4 text-green-500" />
                                )}
                                <span className="sr-only">
                                  {reminder.isActive ? 'Deactivate' : 'Activate'}
                                </span>
                              </Button>
                            )}
                            
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleDeleteReminder(reminder.id)}
                            >
                              <Trash2 className="h-4 w-4 text-red-500" />
                              <span className="sr-only">Delete</span>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
