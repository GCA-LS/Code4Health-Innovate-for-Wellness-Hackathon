import { useEffect, useState } from 'react';
import { DirectoryList } from '@/components/DirectoryList';
import { useLocation } from 'wouter';
import { useTheme } from 'next-themes';

export default function Facilities() {
  const [location, setLocation] = useLocation();
  const [facilityType, setFacilityType] = useState<string | null>(null);
  const { theme } = useTheme();

  // Check for type in query params
  useEffect(() => {
    const searchParams = new URLSearchParams(window.location.search);
    const type = searchParams.get('type');
    if (type) {
      setFacilityType(type);
    }
  }, [location]);

  // Set page title
  useEffect(() => {
    document.title = "Find Healthcare Facilities | Health Resource Finder";
    
    return () => {
      document.title = "Health Resource Finder";
    };
  }, []);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">
        Find Healthcare Facilities
        {facilityType && ` - ${facilityType.charAt(0).toUpperCase() + facilityType.slice(1)}s`}
      </h1>
      
      <DirectoryList />
    </div>
  );
}
