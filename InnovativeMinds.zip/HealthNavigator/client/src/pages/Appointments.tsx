import { useEffect, useState } from 'react';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription, 
  CardFooter 
} from '@/components/ui/card';
import { 
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Calendar, 
  Clock, 
  Plus, 
  Edit3, 
  Trash2, 
  AlertCircle, 
  CheckCircle, 
  X, 
  CalendarIcon,
  Filter 
} from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { AppointmentForm } from '@/components/AppointmentForm';
import { ReminderForm } from '@/components/ReminderForm';
import { Skeleton } from '@/components/ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { Appointment } from '@shared/schema';

export default function Appointments() {
  const [activeTab, setActiveTab] = useState('upcoming');
  const [selectedFacilityId, setSelectedFacilityId] = useState<number | null>(null);
  const [selectedFacilityName, setSelectedFacilityName] = useState('');
  const [filterStatus, setFilterStatus] = useState<string | null>(null);
  
  const queryClient = useQueryClient();
  const { toast } = useToast();

  // Fetch appointments
  const { data: appointments = [], isLoading: isLoadingAppointments } = useQuery({
    queryKey: ['/api/appointments'],
  });

  // Fetch facilities for the dropdown
  const { data: facilities = [], isLoading: isLoadingFacilities } = useQuery({
    queryKey: ['/api/facilities'],
  });

  // Set page title
  useEffect(() => {
    document.title = "Appointments | Health Resource Finder";
    
    return () => {
      document.title = "Health Resource Finder";
    };
  }, []);

  // Filter and sort appointments
  const filteredAppointments = appointments
    .filter((appointment: Appointment) => {
      // Filter by status if set
      if (filterStatus && appointment.status !== filterStatus) {
        return false;
      }
      
      const appointmentDate = new Date(appointment.date);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      if (activeTab === 'upcoming') {
        return appointmentDate >= today && appointment.status !== 'canceled' && appointment.status !== 'completed';
      } else if (activeTab === 'past') {
        return appointmentDate < today || appointment.status === 'completed';
      } else if (activeTab === 'canceled') {
        return appointment.status === 'canceled';
      }
      
      return true;
    })
    .sort((a: Appointment, b: Appointment) => {
      // Sort by date (newest first for past, oldest first for upcoming)
      const dateA = new Date(a.date);
      const dateB = new Date(b.date);
      
      return activeTab === 'past' ? dateB.getTime() - dateA.getTime() : dateA.getTime() - dateB.getTime();
    });

  // Cancel an appointment
  const handleCancelAppointment = async (id: number) => {
    try {
      if (!confirm('Are you sure you want to cancel this appointment?')) {
        return;
      }
      
      await apiRequest('PATCH', `/api/appointments/${id}`, { status: 'canceled' });
      
      toast({
        title: 'Appointment Canceled',
        description: 'The appointment has been canceled successfully.',
      });
      
      // Refresh appointments
      queryClient.invalidateQueries({ queryKey: ['/api/appointments'] });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to cancel appointment. Please try again.',
        variant: 'destructive',
      });
      console.error('Error canceling appointment:', error);
    }
  };

  // Mark an appointment as completed
  const handleCompleteAppointment = async (id: number) => {
    try {
      await apiRequest('PATCH', `/api/appointments/${id}`, { status: 'completed' });
      
      toast({
        title: 'Appointment Completed',
        description: 'The appointment has been marked as completed.',
      });
      
      // Refresh appointments
      queryClient.invalidateQueries({ queryKey: ['/api/appointments'] });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to update appointment status. Please try again.',
        variant: 'destructive',
      });
      console.error('Error updating appointment:', error);
    }
  };

  // Get facility name by ID
  const getFacilityName = (facilityId: number) => {
    const facility = facilities.find((f: any) => f.id === facilityId);
    return facility ? facility.name : 'Unknown Facility';
  };

  // Open appointment form with a specific facility
  const openAppointmentForm = (facilityId: number, facilityName: string) => {
    setSelectedFacilityId(facilityId);
    setSelectedFacilityName(facilityName);
  };

  // Status badge color mapping
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <Badge variant="outline">Pending</Badge>;
      case 'confirmed':
        return <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300">Confirmed</Badge>;
      case 'completed':
        return <Badge variant="secondary">Completed</Badge>;
      case 'canceled':
        return <Badge variant="destructive">Canceled</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
        <h1 className="text-2xl font-bold">Appointments</h1>
        
        <Dialog>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              New Appointment
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Schedule New Appointment</DialogTitle>
            </DialogHeader>
            
            {isLoadingFacilities ? (
              <div className="space-y-2">
                <Skeleton className="h-5 w-40" />
                <Skeleton className="h-10 w-full" />
                <Skeleton className="h-5 w-40" />
                <Skeleton className="h-10 w-full" />
              </div>
            ) : (
              <>
                {selectedFacilityId ? (
                  <AppointmentForm 
                    facilityId={selectedFacilityId} 
                    facilityName={selectedFacilityName}
                    key={selectedFacilityId} // Force re-render on facility change
                  />
                ) : (
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium mb-1">Select a Facility</label>
                      <Select onValueChange={(value) => {
                        const id = parseInt(value);
                        const name = getFacilityName(id);
                        openAppointmentForm(id, name);
                      }}>
                        <SelectTrigger>
                          <SelectValue placeholder="Choose a healthcare facility" />
                        </SelectTrigger>
                        <SelectContent>
                          {facilities.map((facility: any) => (
                            <SelectItem key={facility.id} value={facility.id.toString()}>
                              {facility.name} ({facility.type})
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      Please select a healthcare facility to schedule an appointment with.
                    </p>
                  </div>
                )}
              </>
            )}
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-4">
            <div>
              <CardTitle>Your Appointments</CardTitle>
              <CardDescription>
                Manage your scheduled healthcare appointments
              </CardDescription>
            </div>
            
            <div className="flex items-center gap-2">
              <Select 
                onValueChange={(value) => setFilterStatus(value === 'all' ? null : value)}
                defaultValue="all"
              >
                <SelectTrigger className="w-[180px]">
                  <div className="flex items-center">
                    <Filter className="mr-2 h-4 w-4" />
                    <span>Filter by Status</span>
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Statuses</SelectItem>
                  <SelectItem value="pending">Pending</SelectItem>
                  <SelectItem value="confirmed">Confirmed</SelectItem>
                  <SelectItem value="completed">Completed</SelectItem>
                  <SelectItem value="canceled">Canceled</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-4">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="upcoming">Upcoming</TabsTrigger>
              <TabsTrigger value="past">Past</TabsTrigger>
              <TabsTrigger value="canceled">Canceled</TabsTrigger>
            </TabsList>
          </Tabs>
        </CardHeader>
        
        <CardContent>
          {isLoadingAppointments ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="flex items-center justify-between p-4 border rounded-md">
                  <div className="space-y-2">
                    <Skeleton className="h-5 w-40" />
                    <Skeleton className="h-4 w-60" />
                  </div>
                  <Skeleton className="h-10 w-20" />
                </div>
              ))}
            </div>
          ) : filteredAppointments.length === 0 ? (
            <div className="text-center py-8">
              <CalendarIcon className="h-12 w-12 mx-auto text-muted-foreground opacity-50" />
              <h3 className="mt-4 text-lg font-medium">No {activeTab} appointments found</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                {activeTab === 'upcoming'
                  ? "You don't have any upcoming appointments scheduled."
                  : activeTab === 'past'
                  ? "You don't have any past appointments."
                  : "You don't have any canceled appointments."}
              </p>
              <Button className="mt-4" asChild>
                <DialogTrigger>
                  <Plus className="h-4 w-4 mr-2" />
                  Schedule Appointment
                </DialogTrigger>
              </Button>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Appointment</TableHead>
                    <TableHead>Facility</TableHead>
                    <TableHead>Date & Time</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredAppointments.map((appointment: Appointment) => (
                    <TableRow key={appointment.id}>
                      <TableCell className="font-medium">
                        {appointment.title}
                        {appointment.notes && (
                          <p className="text-sm text-muted-foreground mt-1 line-clamp-1">
                            {appointment.notes}
                          </p>
                        )}
                      </TableCell>
                      <TableCell>{getFacilityName(appointment.facilityId)}</TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span className="flex items-center">
                            <Calendar className="h-4 w-4 mr-1 text-muted-foreground" />
                            {format(new Date(appointment.date), 'MMM d, yyyy')}
                          </span>
                          <span className="flex items-center text-sm text-muted-foreground">
                            <Clock className="h-3 w-3 mr-1" />
                            {format(new Date(appointment.date), 'h:mm a')}
                          </span>
                        </div>
                      </TableCell>
                      <TableCell>
                        {getStatusBadge(appointment.status)}
                      </TableCell>
                      <TableCell className="text-right">
                        <div className="flex items-center justify-end gap-2">
                          {appointment.status !== 'canceled' && appointment.status !== 'completed' && (
                            <>
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button variant="outline" size="sm">
                                    <Edit3 className="h-4 w-4" />
                                    <span className="sr-only">Edit</span>
                                  </Button>
                                </DialogTrigger>
                                <DialogContent>
                                  <DialogHeader>
                                    <DialogTitle>Edit Appointment</DialogTitle>
                                  </DialogHeader>
                                  {/* In a real app, this would be an edit form */}
                                  <p className="text-center text-muted-foreground py-4">
                                    Editing functionality would be implemented here
                                  </p>
                                </DialogContent>
                              </Dialog>
                              
                              <Dialog>
                                <DialogTrigger asChild>
                                  <Button variant="outline" size="sm">
                                    <Clock className="h-4 w-4" />
                                    <span className="sr-only">Set Reminder</span>
                                  </Button>
                                </DialogTrigger>
                                <DialogContent>
                                  <DialogHeader>
                                    <DialogTitle>Set Reminder for Appointment</DialogTitle>
                                  </DialogHeader>
                                  <ReminderForm 
                                    appointmentId={appointment.id}
                                  />
                                </DialogContent>
                              </Dialog>
                              
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleCompleteAppointment(appointment.id)}
                              >
                                <CheckCircle className="h-4 w-4 text-green-500" />
                                <span className="sr-only">Mark as Completed</span>
                              </Button>
                              
                              <Button
                                variant="outline"
                                size="sm"
                                onClick={() => handleCancelAppointment(appointment.id)}
                              >
                                <X className="h-4 w-4 text-red-500" />
                                <span className="sr-only">Cancel</span>
                              </Button>
                            </>
                          )}
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
