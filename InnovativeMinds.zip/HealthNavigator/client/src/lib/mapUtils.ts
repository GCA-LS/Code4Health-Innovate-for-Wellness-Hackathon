import { Facility } from '@shared/schema';
import L from 'leaflet';

// Initialize Leaflet Map
export function initializeMap(
  element: HTMLElement, 
  center: { lat: number; lng: number }
): L.Map {
  const map = L.map(element).setView([center.lat, center.lng], 13);
  
  // Add the OpenStreetMap tile layer
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
    maxZoom: 19,
  }).addTo(map);
  
  return map;
}

// Add a marker for the user's location
export function addUserMarker(
  map: L.Map, 
  position: { lat: number; lng: number }
): L.Marker {
  const userIcon = L.divIcon({
    className: 'user-location-marker',
    html: `<div style="background-color: #4285F4; width: 16px; height: 16px; border-radius: 50%; border: 2px solid white;"></div>`,
    iconSize: [20, 20],
    iconAnchor: [10, 10]
  });
  
  const marker = L.marker([position.lat, position.lng], {
    icon: userIcon,
    title: 'Your Location',
    zIndexOffset: 1000
  }).addTo(map);
  
  marker.bindPopup('<div><strong>Your Location</strong></div>');
  
  return marker;
}

// Add markers for healthcare facilities
export function addFacilityMarkers(
  map: L.Map, 
  facilities: Facility[],
  onFacilitySelect?: (facility: Facility) => void
): L.Marker[] {
  const markers: L.Marker[] = [];
  const markerBounds = L.latLngBounds([]);
  
  // Create custom icons for different facility types
  const icons = {
    hospital: L.divIcon({
      className: 'facility-marker hospital',
      html: `<div style="background-color: #ef4444; width: 12px; height: 12px; border-radius: 50%; border: 2px solid white;"></div>`,
      iconSize: [16, 16],
      iconAnchor: [8, 8]
    }),
    clinic: L.divIcon({
      className: 'facility-marker clinic',
      html: `<div style="background-color: #3b82f6; width: 12px; height: 12px; border-radius: 50%; border: 2px solid white;"></div>`,
      iconSize: [16, 16],
      iconAnchor: [8, 8]
    }),
    pharmacy: L.divIcon({
      className: 'facility-marker pharmacy',
      html: `<div style="background-color: #22c55e; width: 12px; height: 12px; border-radius: 50%; border: 2px solid white;"></div>`,
      iconSize: [16, 16],
      iconAnchor: [8, 8]
    })
  };

  facilities.forEach(facility => {
    const lat = parseFloat(facility.latitude);
    const lng = parseFloat(facility.longitude);
    
    // Skip if invalid coordinates
    if (isNaN(lat) || isNaN(lng)) {
      console.warn(`Invalid coordinates for facility: ${facility.name}`);
      return;
    }
    
    // Get the appropriate icon
    const icon = icons[facility.type as keyof typeof icons] || icons.hospital;
    
    // Create marker
    const marker = L.marker([lat, lng], {
      icon: icon,
      title: facility.name
    }).addTo(map);
    
    // Create popup content
    const popupContent = `
      <div style="max-width: 200px; padding: 5px;">
        <h3 style="margin: 0 0 5px; font-size: 16px;">${facility.name}</h3>
        <p style="margin: 0 0 5px; font-size: 12px; color: #666;">
          <strong>${facility.type.charAt(0).toUpperCase() + facility.type.slice(1)}</strong>
        </p>
        <p style="margin: 0 0 5px; font-size: 13px;">${facility.address}</p>
        <p style="margin: 0; font-size: 13px;">${facility.phone}</p>
      </div>
    `;
    
    // Add popup
    marker.bindPopup(popupContent);
    
    // Add click event
    marker.on('click', () => {
      // If callback provided, call it
      if (onFacilitySelect) {
        onFacilitySelect(facility);
      }
    });
    
    // Extend bounds
    markerBounds.extend([lat, lng]);
    markers.push(marker);
  });
  
  // Only adjust bounds if we have facilities
  if (markers.length > 0) {
    map.fitBounds(markerBounds, {
      padding: [50, 50]
    });
  }
  
  return markers;
}

// Calculate distance between two points using the Haversine formula
export function calculateDistance(
  point1: { lat: number; lng: number },
  point2: { lat: number; lng: number }
): number {
  const R = 6371; // Earth's radius in km
  
  // Convert latitude and longitude from degrees to radians
  const lat1Rad = degreesToRadians(point1.lat);
  const lng1Rad = degreesToRadians(point1.lng);
  const lat2Rad = degreesToRadians(point2.lat);
  const lng2Rad = degreesToRadians(point2.lng);
  
  // Haversine formula
  const dLat = lat2Rad - lat1Rad;
  const dLng = lng2Rad - lng1Rad;
  const a = 
    Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1Rad) * Math.cos(lat2Rad) * 
    Math.sin(dLng/2) * Math.sin(dLng/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  const distance = R * c; // Distance in km
  
  return distance;
}

function degreesToRadians(degrees: number): number {
  return degrees * (Math.PI / 180);
}
