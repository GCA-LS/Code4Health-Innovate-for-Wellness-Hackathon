// Simple natural language processing for the chatbot
interface Intent {
  keywords: string[];
  responses: string[];
  followUpQuestions?: string[];
}

// Define intents with keywords and possible responses
const intents: Record<string, Intent> = {
  greeting: {
    keywords: ['hello', 'hi', 'hey', 'greetings', 'good morning', 'good afternoon', 'good evening'],
    responses: [
      "Hello! How can I help you with healthcare resources today?",
      "Hi there! I can help you find facilities, book appointments, or answer health-related questions.",
      "Welcome! What kind of healthcare service are you looking for today?"
    ],
    followUpQuestions: [
      "Are you looking for a specific type of healthcare facility?",
      "Do you need help finding a hospital, clinic, or pharmacy?",
      "Would you like to book an appointment or set a reminder?"
    ]
  },
  findFacility: {
    keywords: ['find', 'search', 'locate', 'nearest', 'closest', 'nearby', 'facility', 'hospital', 'clinic', 'pharmacy', 'doctor', 'healthcare'],
    responses: [
      "I can help you find nearby healthcare facilities. What type are you looking for? Hospital, clinic, or pharmacy?",
      "To help you find a suitable healthcare facility, could you specify what type you need? Hospital, clinic, or pharmacy?",
      "I'll assist you in finding healthcare resources nearby. Are you looking for a hospital, clinic, or pharmacy?"
    ]
  },
  appointment: {
    keywords: ['appointment', 'schedule', 'book', 'visit', 'meet', 'doctor', 'checkup', 'check-up', 'examination'],
    responses: [
      "I can help you book an appointment. You can go to the Appointments page and click on 'New Appointment' to get started.",
      "To schedule an appointment, please navigate to the Appointments section and select a healthcare facility.",
      "Booking an appointment is easy! Just go to Appointments and choose the facility where you'd like to be seen."
    ]
  },
  reminder: {
    keywords: ['reminder', 'remind', 'alert', 'notification', 'forget', 'remember'],
    responses: [
      "I can help you set a reminder. Go to the Reminders page and click on 'New Reminder' to create one.",
      "Setting reminders is easy! Navigate to the Reminders section and create a new one with a specific date and time.",
      "You can create reminders for appointments or medications in the Reminders section."
    ]
  },
  accessibility: {
    keywords: ['accessibility', 'accessible', 'disability', 'disabled', 'vision', 'hearing', 'speech', 'voice', 'speak', 'listen'],
    responses: [
      "This app has several accessibility features. You can enable them by clicking the eye icon in the header for high contrast mode, larger text, and screen reader support.",
      "For accessibility options, click the eye icon in the top navigation. You can use voice input with the microphone button in this chat window.",
      "We have accessibility features available! Look for the eye icon to enable high contrast, larger text, or text-to-speech functionality."
    ]
  },
  services: {
    keywords: ['service', 'services', 'offer', 'provides', 'available', 'treatment', 'specialty', 'specialize'],
    responses: [
      "You can view the services offered by each healthcare facility on their details page. Just click on a facility to see what they provide.",
      "Each facility has a list of services they offer. You can find them by clicking on a specific facility and checking the Services tab.",
      "To see what services a healthcare facility offers, visit their page and look at the Services section."
    ]
  },
  hours: {
    keywords: ['hours', 'open', 'close', 'opening', 'closing', 'schedule', 'time', 'when', 'closed'],
    responses: [
      "You can find operating hours for facilities on their details page. Each listing includes the days and hours they're open.",
      "Facility operating hours are displayed on their individual pages. Just select a facility to view their schedule.",
      "To check when a facility is open, click on their listing and look for the opening hours section."
    ]
  },
  help: {
    keywords: ['help', 'assist', 'support', 'guide', 'how', 'explain', 'what', 'info'],
    responses: [
      "I can help you navigate the Health Resource Finder app. What would you like to know about? Finding facilities, booking appointments, or setting reminders?",
      "I'm here to assist you! You can ask me about finding healthcare facilities, managing appointments, or setting reminders.",
      "How can I help you today? I can provide information about healthcare facilities, assist with appointments, or guide you through using this app."
    ]
  },
  thanks: {
    keywords: ['thanks', 'thank you', 'appreciate', 'grateful', 'helpful'],
    responses: [
      "You're welcome! Is there anything else I can help you with?",
      "Happy to help! Let me know if you need assistance with anything else.",
      "My pleasure! Feel free to ask if you have any other questions."
    ]
  },
  goodbye: {
    keywords: ['bye', 'goodbye', 'see you', 'farewell', 'exit', 'close'],
    responses: [
      "Goodbye! Feel free to come back if you have more questions.",
      "Take care! I'm here if you need healthcare assistance in the future.",
      "Have a great day! Remember, I'm here to help whenever you need it."
    ]
  }
};

// Function to determine the intent of a user message
function determineIntent(message: string): string {
  const lowerMessage = message.toLowerCase();
  
  // Check each intent for matching keywords
  for (const [intentName, intent] of Object.entries(intents)) {
    for (const keyword of intent.keywords) {
      if (lowerMessage.includes(keyword)) {
        return intentName;
      }
    }
  }
  
  // Default to help if no intent is matched
  return 'help';
}

// Get a random response from an array
function getRandomResponse(responses: string[]): string {
  const index = Math.floor(Math.random() * responses.length);
  return responses[index];
}

// Main function to get a bot response based on user input
export async function getBotResponse(message: string): Promise<string> {
  // Determine the intent of the user's message
  const intent = determineIntent(message);
  
  // Get a random response for the determined intent
  const response = getRandomResponse(intents[intent].responses);
  
  // 30% chance to add a follow-up question if available
  const shouldAddFollowUp = Math.random() < 0.3;
  if (shouldAddFollowUp && intents[intent].followUpQuestions) {
    const followUp = getRandomResponse(intents[intent].followUpQuestions || []);
    return `${response} ${followUp}`;
  }
  
  return response;
}
