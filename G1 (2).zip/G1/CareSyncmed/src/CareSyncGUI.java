import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.*;

public class CareSyncGUI extends JFrame {
    static class Medication {
        String name, dosage, time;
        boolean taken;

        Medication(String name, String dosage, String time, boolean taken) {
            this.name = name;
            this.dosage = dosage;
            this.time = time;
            this.taken = taken;
        }

        public String toString() {
            return name + " - " + dosage + " at " + time + (taken ? " [Taken]" : " [Missed]");
        }
    }

    static class MedicalError {
        String type, description;

        MedicalError(String type, String description) {
            this.type = type;
            this.description = description;
        }

        public String toString() {
            return "Type: " + type + ", Description: " + description;
        }
    }

    static class User {
        String emailOrPhone, password, role, hospital;

        User(String emailOrPhone, String password, String role, String hospital) {
            this.emailOrPhone = emailOrPhone;
            this.password = password;
            this.role = role;
            this.hospital = hospital;
        }
    }

    static java.util.List<Medication> medications = new ArrayList<>();
    static java.util.List<MedicalError> errors = new ArrayList<>();
    static final String MEDICATION_FILE = "medications.txt";
    static final String ERRORS_FILE = "errors.txt";
    static final String USERS_FILE = "users.txt";

    JTextArea outputArea;
    String role;

    public CareSyncGUI(String role) {
        this.role = role;
        setTitle("CareSync - Medication Tracker");
        setSize(600, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        JPanel buttonPanel = new JPanel(new GridLayout(0, 1));
        addButtons(buttonPanel);

        outputArea = new JTextArea();
        outputArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(outputArea);

        add(buttonPanel, BorderLayout.WEST);
        add(scrollPane, BorderLayout.CENTER);

        loadMedications();
        loadErrors();
    }

    void addButtons(JPanel panel) {
        if (role.equals("patient")) {
            addButton(panel, "Mark Medication as Taken");
            addButton(panel, "View Medications");
            addButton(panel, "Generate Immune Risk Graph");
            addButton(panel, "Save and Exit");
        } else {
            String[] buttons = {
                "Add Medication", "View Medications", "Mark Medication as Taken",
                "Generate Immune Risk Graph", "Log Medical Error", "View Medical Errors",
                "View Patients", "Save and Exit"
            };
            for (String label : buttons) {
                addButton(panel, label);
            }
        }
    }

    void addButton(JPanel panel, String label) {
        JButton button = new JButton(label);
        panel.add(button);
        button.addActionListener(this::handleAction);
    }

    void handleAction(ActionEvent e) {
        String cmd = ((JButton) e.getSource()).getText();
        switch (cmd) {
            case "Add Medication" -> addMedication();
            case "View Medications" -> viewMedications();
            case "Mark Medication as Taken" -> markMedication();
            case "Generate Immune Risk Graph" -> showImmuneGraph();
            case "Log Medical Error" -> logError();
            case "View Medical Errors" -> viewErrors();
            case "View Patients" -> viewPatients();
            case "Save and Exit" -> {
                saveMedications();
                saveErrors();
                JOptionPane.showMessageDialog(this, "Data saved. Goodbye!");
                System.exit(0);
            }
        }
    }

    void viewPatients() {
        StringBuilder sb = new StringBuilder("Registered Patients:\n");
        File userFile = new File(USERS_FILE);
        if (userFile.exists()) {
            try (Scanner scanner = new Scanner(userFile)) {
                while (scanner.hasNextLine()) {
                    String[] parts = scanner.nextLine().split(";");
                    if (parts.length >= 4 && parts[2].equals("patient")) {
                        sb.append("Email/Phone: ").append(parts[0]).append(", Hospital: ").append(parts[3]).append("\n");
                    }
                }
            } catch (IOException ex) {
                outputArea.setText("Error reading users file.");
                return;
            }
        }
        outputArea.setText(sb.toString());
    }

    void addMedication() {
        String name = JOptionPane.showInputDialog(this, "Enter medication name:");
        if (name == null) return;
        String dosage = JOptionPane.showInputDialog(this, "Enter dosage:");
        String time = JOptionPane.showInputDialog(this, "Enter time:");
        medications.add(new Medication(name, dosage, time, false));
        outputArea.setText("Medication added.");
    }

    void viewMedications() {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < medications.size(); i++) {
            sb.append(i).append(": ").append(medications.get(i)).append("\n");
        }
        outputArea.setText(sb.toString());
    }

    void markMedication() {
        String input = JOptionPane.showInputDialog(this, "Enter medication index to mark as taken:");
        try {
            int index = Integer.parseInt(input);
            if (index >= 0 && index < medications.size()) {
                medications.get(index).taken = true;
                outputArea.setText("Medication marked as taken.");
            } else {
                outputArea.setText("Invalid index.");
            }
        } catch (NumberFormatException e) {
            outputArea.setText("Invalid input.");
        }
    }

    void showImmuneGraph() {
        long missed = medications.stream().filter(m -> !m.taken).count();
        int total = medications.size();
        if (total == 0) {
            outputArea.setText("No data to calculate risk.");
            return;
        }
        int risk = (int) ((missed * 100.0) / total);
        StringBuilder graph = new StringBuilder("Risk Level: ");
        for (int i = 0; i < risk / 10; i++) graph.append("#");
        graph.append(" ").append(risk).append("%");
        outputArea.setText(graph.toString());
    }

    void logError() {
        String type = JOptionPane.showInputDialog(this, "Enter error type:");
        if (type == null) return;
        String desc = JOptionPane.showInputDialog(this, "Enter error description:");
        errors.add(new MedicalError(type, desc));
        outputArea.setText("Error logged.");
    }

    void viewErrors() {
        StringBuilder sb = new StringBuilder();
        for (MedicalError error : errors) sb.append(error).append("\n");
        outputArea.setText(sb.toString());
    }

    void saveMedications() {
        try (PrintWriter writer = new PrintWriter(MEDICATION_FILE)) {
            for (Medication m : medications) {
                writer.println(m.name + ";" + m.dosage + ";" + m.time + ";" + m.taken);
            }
        } catch (IOException e) {
            outputArea.setText("Error saving medications.");
        }
    }

    void loadMedications() {
        File file = new File(MEDICATION_FILE);
        if (!file.exists()) return;
        try (Scanner fileScanner = new Scanner(file)) {
            while (fileScanner.hasNextLine()) {
                String[] parts = fileScanner.nextLine().split(";");
                if (parts.length == 4) {
                    medications.add(new Medication(parts[0], parts[1], parts[2], Boolean.parseBoolean(parts[3])));
                }
            }
        } catch (IOException e) {
            outputArea.setText("Error loading medications.");
        }
    }

    void saveErrors() {
        try (PrintWriter writer = new PrintWriter(ERRORS_FILE)) {
            for (MedicalError error : errors) {
                writer.println(error.type + ";" + error.description);
            }
        } catch (IOException e) {
            outputArea.setText("Error saving errors.");
        }
    }

    void loadErrors() {
        File file = new File(ERRORS_FILE);
        if (!file.exists()) return;
        try (Scanner fileScanner = new Scanner(file)) {
            while (fileScanner.hasNextLine()) {
                String[] parts = fileScanner.nextLine().split(";");
                if (parts.length == 2) {
                    errors.add(new MedicalError(parts[0], parts[1]));
                }
            }
        } catch (IOException e) {
            outputArea.setText("Error loading errors.");
        }
    }

    static String authenticateOrRegister() {
        File userFile = new File(USERS_FILE);
        Map<String, User> users = new HashMap<>();
        if (userFile.exists()) {
            try (Scanner fileScanner = new Scanner(userFile)) {
                while (fileScanner.hasNextLine()) {
                    String[] parts = fileScanner.nextLine().split(";");
                    if (parts.length >= 4) {
                        users.put(parts[0], new User(parts[0], parts[1], parts[2], parts[3]));
                    }
                }
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error reading users file.");
            }
        }

        String[] options = {"Login", "Register"};
        int choice = JOptionPane.showOptionDialog(null, "Login or Register", "User Access", JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
        if (choice == 0) {
            String username = JOptionPane.showInputDialog("Enter email/phone:");
            String password = JOptionPane.showInputDialog("Enter password:");
            User user = users.get(username);
            if (user != null && user.password.equals(password)) {
                return user.role;
            } else {
                JOptionPane.showMessageDialog(null, "Invalid credentials.");
                System.exit(0);
            }
        } else {
            String username = JOptionPane.showInputDialog("Enter email/phone:");
            if (users.containsKey(username)) {
                JOptionPane.showMessageDialog(null, "User already exists.");
                System.exit(0);
            }
            String password = JOptionPane.showInputDialog("Enter password:");
            String firstName = JOptionPane.showInputDialog("Enter first name:");
            String lastName = JOptionPane.showInputDialog("Enter last name:");
            String[] roles = {"patient", "doctor", "pharmacist", "clinic"};
            String role = (String) JOptionPane.showInputDialog(null, "Select role:", "User Role", JOptionPane.QUESTION_MESSAGE, null, roles, roles[0]);
            String hospital = JOptionPane.showInputDialog("Enter hospital/clinic name:");
            try (PrintWriter writer = new PrintWriter(new FileWriter(USERS_FILE, true))) {
                writer.println(username + ";" + password + ";" + role + ";" + hospital + ";" + firstName + ";" + lastName);
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error saving user.");
                System.exit(0);
            }
            return role;
        }
        return null;
    }

    public static void main(String[] args) {
        String role = authenticateOrRegister();
        if (role != null) {
            SwingUtilities.invokeLater(() -> new CareSyncGUI(role).setVisible(true));
        }
    }
}
