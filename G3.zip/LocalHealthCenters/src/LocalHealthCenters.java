import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.URI;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

public class LocalHealthCenters {

    static class HealthCentre {
        String name, country, address, services, hours, contact;

        HealthCentre(String name, String country, String address, String services, String hours, String contact) {
            this.name = name;
            this.country = country;
            this.address = address;
            this.services = services;
            this.hours = hours;
            this.contact = contact;
        }
    }

    private static final List<HealthCentre> database = new ArrayList<>();
    private static final Map<String, Map<String, String>> translations = new HashMap<>();
    private static HealthCentre selectedCentre = null;

    public static void main(String[] args) {
        loadData();
        loadTranslations();
        SwingUtilities.invokeLater(LocalHealthCenters::createAndShowGUI);
    }

    private static void createAndShowGUI() {
        JFrame frame = new JFrame("Health Resource Finder");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(900, 600);

        JTextField countryField = new JTextField();
        JTextField nameField = new JTextField();
        JComboBox<String> langBox = new JComboBox<>(translations.keySet().toArray(new String[0]));
        JTextArea resultArea = new JTextArea(8, 30);
        resultArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(resultArea);

        JComboBox<String> suggestBox = new JComboBox<>();
        suggestBox.setVisible(false);

        JButton searchBtn = new JButton("Search");
        JButton mapBtn = new JButton("Show on Map");
        mapBtn.setEnabled(false);

        JLabel countryList = new JLabel("Available countries: " + getCountryCounts());

        JPanel panel = new JPanel(new GridLayout(10, 2, 5, 5));
        panel.add(countryList); panel.add(new JLabel());
        panel.add(new JLabel("Country:")); panel.add(countryField);
        panel.add(new JLabel("Health Centre Name (optional):")); panel.add(nameField);
        panel.add(new JLabel("Language:")); panel.add(langBox);
        panel.add(searchBtn); panel.add(suggestBox);
        panel.add(mapBtn); panel.add(new JLabel());
        panel.add(new JLabel("Result:")); panel.add(scrollPane);

        frame.add(panel);
        frame.setVisible(true);

        searchBtn.addActionListener(e -> {
            String country = countryField.getText().trim();
            String name = nameField.getText().trim();
            String lang = langBox.getSelectedItem().toString();

            resultArea.setText("");
            suggestBox.removeAllItems();
            suggestBox.setVisible(false);
            mapBtn.setEnabled(false);
            selectedCentre = null;

            if (country.isEmpty()) {
                resultArea.setText("Please enter a country.");
                return;
            }

            List<HealthCentre> results = database.stream()
                    .filter(hc -> cleaned(hc.country).contains(cleaned(country)))
                    .collect(Collectors.toList());

            if (!name.isEmpty()) {
                results = results.stream()
                        .filter(hc -> cleaned(hc.name).contains(cleaned(name)))
                        .collect(Collectors.toList());
            }

            if (results.size() == 1) {
                selectedCentre = results.get(0);
                resultArea.setText(display(selectedCentre, lang));
                mapBtn.setEnabled(true);
            } else if (results.size() > 1 && name.isEmpty()) {
                results.forEach(hc -> suggestBox.addItem(hc.name));
                suggestBox.setVisible(true);
            } else {
                resultArea.setText("No matching health centre found.");
            }
        });

        suggestBox.addActionListener(e -> {
            if (suggestBox.getSelectedItem() == null) return;
            String name = suggestBox.getSelectedItem().toString();
            String country = countryField.getText().trim();
            String lang = langBox.getSelectedItem().toString();

            database.stream()
                    .filter(hc -> cleaned(hc.country).contains(cleaned(country)) && hc.name.equals(name))
                    .findFirst()
                    .ifPresent(hc -> {
                        selectedCentre = hc;
                        resultArea.setText(display(hc, lang));
                        mapBtn.setEnabled(true);
                    });
        });

        mapBtn.addActionListener(e -> {
            if (selectedCentre == null) return;
            try {
                String dest = URLEncoder.encode(selectedCentre.address + ", " + selectedCentre.country, StandardCharsets.UTF_8);
                String url = "https://www.google.com/maps/search/?api=1&query=" + dest;
                Desktop.getDesktop().browse(new URI(url));
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(null, "Could not open browser.");
            }
        });
    }

    private static String cleaned(String s) {
        return s.toLowerCase().replaceAll("[^a-z0-9]", "").trim();
    }

    private static String display(HealthCentre hc, String lang) {
        return getT("Name", lang) + ": " + hc.name + "\n" +
               getT("Country", lang) + ": " + hc.country + "\n" +
               getT("Address", lang) + ": " + hc.address + "\n" +
               getT("Services", lang) + ": " + hc.services + "\n" +
               getT("Opening Hours", lang) + ": " + hc.hours + "\n" +
               getT("Contact", lang) + ": " + hc.contact;
    }

    private static String getT(String key, String lang) {
        return translations.getOrDefault(lang, translations.get("English")).getOrDefault(key, key);
    }

    private static void loadData() {
        String[][] data = {
            // Lesotho
            {"Queen 'Mamohato Memorial Hospital", "Lesotho", "Maseru", "General, Emergency", "24/7", "+266 2222 0000"},
            {"Motebang Hospital", "Lesotho", "Leribe", "General", "08:00 - 16:00", "+266 2231 1122"},
            {"Tšepong Clinic", "Lesotho", "Maseru", "Outpatient", "08:00 - 17:00", "+266 2232 3344"},
            {"Mamohau Hospital", "Lesotho", "Maputsoe", "General", "08:00 - 16:00", "+266 2233 4455"},
            {"Ntsekhe Hospital", "Lesotho", "Mohale’s Hoek", "Emergency", "24/7", "+266 2234 5566"},
            {"Paray Hospital", "Lesotho", "Thaba-Tseka", "General", "08:00 - 16:00", "+266 2235 6677"},
            {"Seboche Mission Hospital", "Lesotho", "Butha-Buthe", "General", "08:00 - 17:00", "+266 2236 7788"},
            {"Mafeteng Government Hospital", "Lesotho", "Mafeteng", "General", "08:00 - 17:00", "+266 2237 8899"},

            // South Africa
            {"Chris Hani Baragwanath Hospital", "South Africa", "Johannesburg", "Specialist, Emergency", "24/7", "+27 11 933 8000"},
            {"Groote Schuur Hospital", "South Africa", "Cape Town", "General", "07:00 - 19:00", "+27 21 404 9111"},
            {"Charlotte Maxeke Hospital", "South Africa", "Johannesburg", "Specialist", "07:00 - 18:00", "+27 11 488 4911"},
            {"Steve Biko Academic Hospital", "South Africa", "Pretoria", "Specialist", "07:00 - 18:00", "+27 12 354 1000"},
            {"Tygerberg Hospital", "South Africa", "Cape Town", "General", "24/7", "+27 21 938 4911"},
            {"King Edward VIII Hospital", "South Africa", "Durban", "General", "08:00 - 16:00", "+27 31 360 3111"},
            {"Red Cross War Memorial Children's Hospital", "South Africa", "Cape Town", "Pediatrics", "08:00 - 17:00", "+27 21 658 5111"},
            {"Nelson Mandela Academic Hospital", "South Africa", "Mthatha", "General", "08:00 - 17:00", "+27 47 502 4000"},

            // USA
            {"Mayo Clinic", "USA", "Rochester, MN", "Specialist, Emergency", "24/7", "+1 507-284-2511"},
            {"Cleveland Clinic", "USA", "Cleveland, OH", "General, Specialist", "08:00 - 20:00", "+1 216-444-2200"},
            {"Johns Hopkins Hospital", "USA", "Baltimore, MD", "General, Emergency", "24/7", "+1 410-955-5000"},
            {"Massachusetts General Hospital", "USA", "Boston, MA", "General", "24/7", "+1 617-726-2000"},
            {"UCLA Medical Center", "USA", "Los Angeles, CA", "Specialist", "24/7", "+1 310-825-9111"},
            {"NewYork-Presbyterian Hospital", "USA", "New York, NY", "General", "24/7", "+1 212-305-2500"},
            {"Mount Sinai Hospital", "USA", "New York, NY", "Specialist", "08:00 - 18:00", "+1 212-241-6500"},
            {"Stanford Health Care", "USA", "Stanford, CA", "Specialist", "24/7", "+1 650-723-4000"},

            // UK
            {"St. Mary's Hospital", "UK", "London", "General", "08:00 - 18:00", "+44 20 7886 6666"},
            {"Addenbrooke's Hospital", "UK", "Cambridge", "Emergency, Specialist", "24/7", "+44 1223 245151"},
            {"Royal London Hospital", "UK", "London", "General", "24/7", "+44 20 7377 7000"},
            {"Oxford University Hospitals", "UK", "Oxford", "Specialist", "24/7", "+44 1865 741166"},
            {"Queen Elizabeth Hospital", "UK", "Birmingham", "General", "08:00 - 17:00", "+44 121 627 2000"},
            {"King’s College Hospital", "UK", "London", "Emergency", "24/7", "+44 20 3299 9000"},
            {"St Thomas’ Hospital", "UK", "London", "General", "24/7", "+44 20 7188 7188"},
            {"Manchester Royal Infirmary", "UK", "Manchester", "General", "08:00 - 18:00", "+44 161 276 1234"},

            // Nigeria
            {"University College Hospital", "Nigeria", "Ibadan", "General", "08:00 - 17:00", "+234 2 231 5831"},
            {"Lagos University Teaching Hospital", "Nigeria", "Lagos", "General", "08:00 - 16:00", "+234 1 471 5807"},
            {"National Hospital", "Nigeria", "Abuja", "Specialist", "24/7", "+234 9 234 5161"},
            {"Ahmadu Bello University Teaching Hospital", "Nigeria", "Zaria", "General", "08:00 - 17:00", "+234 802 312 2000"},
            {"University of Nigeria Teaching Hospital", "Nigeria", "Enugu", "General", "08:00 - 17:00", "+234 803 670 0000"},
            {"Obafemi Awolowo University Teaching Hospital", "Nigeria", "Ile-Ife", "General", "08:00 - 17:00", "+234 803 408 6020"},
            {"Federal Medical Centre", "Nigeria", "Owerri", "General", "08:00 - 17:00", "+234 803 334 4567"},
            {"Babcock University Teaching Hospital", "Nigeria", "Ilishan-Remo", "General", "08:00 - 17:00", "+234 802 338 8335"},

            // Kenya
            {"Kenyatta National Hospital", "Kenya", "Nairobi", "General", "24/7", "+254 20 2726300"},
            {"Moi Teaching and Referral Hospital", "Kenya", "Eldoret", "General", "24/7", "+254 53 206 0921"},
            {"Aga Khan University Hospital", "Kenya", "Nairobi", "Specialist", "24/7", "+254 20 3662000"},
            {"Nairobi Hospital", "Kenya", "Nairobi", "General", "24/7", "+254 20 2845000"},
            {"Karen Hospital", "Kenya", "Nairobi", "Specialist", "08:00 - 20:00", "+254 20 6613000"},
            {"Gertrude’s Children’s Hospital", "Kenya", "Nairobi", "Pediatrics", "08:00 - 18:00", "+254 20 3763474"},
            {"Mombasa Hospital", "Kenya", "Mombasa", "General", "08:00 - 17:00", "+254 41 222 2644"},
            {"Coast General Hospital", "Kenya", "Mombasa", "General", "08:00 - 17:00", "+254 41 222 3692"}
        };

        for (String[] hc : data) {
            database.add(new HealthCentre(hc[0], hc[1], hc[2], hc[3], hc[4], hc[5]));
        }
    }

    private static void loadTranslations() {
        translations.put("English", Map.of(
            "Name", "Name", "Country", "Country", "Address", "Address",
            "Services", "Services", "Opening Hours", "Opening Hours", "Contact", "Contact"
        ));
        translations.put("Sesotho", Map.of(
            "Name", "Lebitso", "Country", "Naha", "Address", "Aterese",
            "Services", "Litšebeletso", "Opening Hours", "Lihora tsa ho bula", "Contact", "Mokhoa oa puisano"
        ));
        translations.put("French", Map.of(
            "Name", "Nom", "Country", "Pays", "Address", "Adresse",
            "Services", "Services", "Opening Hours", "Heures d'ouverture", "Contact", "Contact"
        ));
        translations.put("Spanish", Map.of(
            "Name", "Nombre", "Country", "País", "Address", "Dirección",
            "Services", "Servicios", "Opening Hours", "Horario", "Contact", "Contacto"
        ));
        translations.put("Chinese", Map.of(
            "Name", "名称", "Country", "国家", "Address", "地址",
            "Services", "服务", "Opening Hours", "营业时间", "Contact", "联系方式"
        ));
        translations.put("Arabic", Map.of(
            "Name", "الاسم", "Country", "البلد", "Address", "العنوان",
            "Services", "الخدمات", "Opening Hours", "ساعات العمل", "Contact", "الاتصال"
        ));
        translations.put("German", Map.of(
            "Name", "Name", "Country", "Land", "Address", "Adresse",
            "Services", "Dienstleistungen", "Opening Hours", "Öffnungszeiten", "Contact", "Kontakt"
        ));
        translations.put("Swahili", Map.of(
            "Name", "Jina", "Country", "Nchi", "Address", "Anwani",
            "Services", "Huduma", "Opening Hours", "Saa za Kufunguliwa", "Contact", "Mawasiliano"
        ));
    }

    private static String getCountryCounts() {
        return database.stream()
                .collect(Collectors.groupingBy(hc -> hc.country, TreeMap::new, Collectors.counting()))
                .entrySet().stream()
                .map(e -> e.getKey() + " (" + e.getValue() + ")")
                .collect(Collectors.joining(", "));
    }
}
