package Locator;

import Locator.Hospital;

public class App2{ //Name of this file should match this class name

public static void main(String[] args) {
	Hospital h1=new Hospital("City hospital", "Maseru",true);
	     h1.displayInfo();
} 
}
   
		class Hospital {
			String name;
			String location;
			String insurance;
			boolean insuranceCovered;
		
			
		   public Hospital(String name, String location,
		boolean insuranceCovered) { 
			   this.name=name;
			   this.location=location;
			   this.insuranceCovered=insuranceCovered;
		   }
			
			   public void displayInfo() {
				System.out.println("Hospital:"+name+"|"
						+ "Location"+ location
		              +"|Insurance:" + (insuranceCovered?
		    "Covered" : "Not Covered" ));
			}
			  
	
	}
	
