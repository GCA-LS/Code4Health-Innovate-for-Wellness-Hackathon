import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class MediMap2 {

    public static void main(String[] args) {
        // Frame setup
        JFrame frame = new JFrame("Global Health & Wellness App");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);

        // Welcome label
        JLabel welcomeLabel = new JLabel("Welcome to the Global Health & Wellness App");
        welcomeLabel.setFont(new Font("Arial", Font.BOLD, 16));

        // Input field
        JTextField locationInput = new JTextField();
        locationInput.setToolTipText("Enter your location (e.g., Maseru)");

        // Locate button
        JButton locateButton = new JButton("Show Nearby Health Centers");

        // Output area
        JTextArea outputArea = new JTextArea();
        outputArea.setEditable(false);
        outputArea.setLineWrap(true);
        outputArea.setWrapStyleWord(true);
        JScrollPane scrollPane = new JScrollPane(outputArea);

        // Action listener for the button
        locateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String location = locationInput.getText().trim().toLowerCase();
                if (location.isEmpty()) {
                    outputArea.setText("Please enter a location.");
                } else {
                    outputArea.setText(getNearbyHealthCenters(location));
                }
            }
        });

        // Layout setup
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        JPanel topPanel = new JPanel(new GridLayout(3, 1, 5, 5));
        topPanel.add(welcomeLabel);
        topPanel.add(locationInput);
        topPanel.add(locateButton);
        panel.add(topPanel, BorderLayout.NORTH);
        panel.add(scrollPane, BorderLayout.CENTER);

        frame.setContentPane(panel);
        frame.setVisible(true);
    }

    // Simulated search
    private static String getNearbyHealthCenters(String location) {
        StringBuilder result = new StringBuilder("Nearby Health Centers in " + capitalize(location) + ":\n\n");

        switch (location) {
            case "maseru":
                result.append("1. Queen Elizabeth II Hospital\n")
                      .append("2. Maseru Private Hospital\n")
                      .append("3. Maseru Clinic\n")
                      .append("4. Pioneer Health Center\n")
                      .append("5. MediClinic Pharmacy\n");
                break;
            case "leribe":
                result.append("1. Motebang Hospital\n")
                      .append("2. Leribe Health Center\n")
                      .append("3. Leribe Private Clinic\n");
                break;
            case "mafia":
                result.append("1. Mafia Town Hospital\n")
                      .append("2. District Medical Clinic\n");
                break;
            default:
                result.append("No data found for this location.\nTry: Maseru, Leribe, or Mafia.");
                break;
        }

        return result.toString();
    }

    private static String capitalize(String str) {
        if (str.isEmpty()) return str;
        return str.substring(0, 1).toUpperCase() + str.substring(1);
    }
}