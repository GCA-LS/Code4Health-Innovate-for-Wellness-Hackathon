package MentalHealthAppConsole.java;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MentalHealthAppConsole {

    private static List<String> moodLog = new ArrayList<>();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Welcome to the Mental Health Support App");
        boolean running = true;

        while (running) {
            System.out.println("\nChoose an option:");
            System.out.println("1. Submit Mood");
            System.out.println("2. View Mood Log");
            System.out.println("3. Show Quote of the Day");
            System.out.println("4. Start Breathing Exercise");
            System.out.println("5. Exit");
            System.out.print("Your choice: ");
            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    submitMood();
                    break;
                case "2":
                    viewMoodLog();
                    break;
                case "3":
                    System.out.println("\n" + getMotivationalQuote());
                    break;
                case "4":
                    startBreathingExercise();
                    break;
                case "5":
                    running = false;
                    System.out.println("Goodbye! Take care.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void submitMood() {
        System.out.println("\nHow are you feeling today?");
        System.out.println("Options: Happy, Sad, Stressed, Calm, Anxious, Excited");
        System.out.print("Enter your mood: ");
        String mood = scanner.nextLine();

        if (!mood.isEmpty()) {
            String entry = LocalDate.now() + ": " + mood;
            moodLog.add(entry);
            System.out.println("Mood recorded successfully.");
        } else {
            System.out.println("Please enter a valid mood.");
        }
    }

    private static void viewMoodLog() {
        System.out.println("\nMood Log:");
        if (moodLog.isEmpty()) {
            System.out.println("No entries yet.");
        } else {
            for (String entry : moodLog) {
                System.out.println(entry);
            }
        }
    }

    private static void startBreathingExercise() {
        System.out.println("\nBreathing Exercise:");
        System.out.println("Inhale... (4 seconds)");
        sleep(4000);
        System.out.println("Hold... (4 seconds)");
        sleep(4000);
        System.out.println("Exhale... (4 seconds)");
        sleep(4000);
        System.out.println("Great job!");
    }

    private static String getMotivationalQuote() {
        String[] quotes = {
            "Keep going. Everything you need will come to you at the perfect time.",
            "You are stronger than you think.",
            "Take a deep breath. You're doing great.",
            "Small steps every day lead to big changes.",
            "It's okay to not be okay."
        };
        int index = (int) (Math.random() * quotes.length);
        return "Quote of the Day: " + quotes[index];
    }

    private static void sleep(int milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}