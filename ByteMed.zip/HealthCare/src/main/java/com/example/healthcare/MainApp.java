package com.example.healthcare;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class MainApp extends Application {

    private Stage primaryStage;  // Store main stage reference

    @Override
    public void start(Stage stage) {
        this.primaryStage = stage;

        DashboardUI dashboard = new DashboardUI(this);
        Scene scene = new Scene(dashboard.getView(), 300, 500);

        primaryStage.setTitle("Healthcare Locator Dashboard");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch();
    }

    public void showAdminDashboard() {
        AdminDashboardUI adminDashboard = new AdminDashboardUI(this);
        Scene adminScene = new Scene(adminDashboard.getView(), 800, 600);
        primaryStage.setScene(adminScene);
        primaryStage.setTitle("Admin Dashboard");
        primaryStage.show();
    }

    public void showManageFacilities() {
        System.out.println("Manage Facilities clicked");
        // TODO: Replace with your real Manage Facilities UI scene
    }

    public void showReports() {
        System.out.println("View Reports clicked");
        // TODO: Replace with your real Reports UI scene
    }

    public void showUserManagement() {
        System.out.println("Manage Users clicked");
        // TODO: Replace with your real User Management UI scene
    }

    public void showSettings() {
        System.out.println("Settings clicked");
        // TODO: Replace with your real Settings UI scene
    }

    public void showLogin() {
        System.out.println("Logout clicked - Show login screen");
        // TODO: Replace with your real login UI scene
    }

    public void showUserDashboard() {
        System.out.println("User Dashboard");
        // TODO: Implement if needed
    }
}
