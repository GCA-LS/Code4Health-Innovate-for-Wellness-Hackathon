package com.example.healthcare;

import javafx.animation.PauseTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.util.Duration;
import org.kordamp.ikonli.javafx.FontIcon;

public class LoginUI {

    private VBox root;
    private MainApp mainApp;

    public LoginUI(MainApp mainApp) {
        this.mainApp = mainApp;
        createUI();
    }

    private void createUI() {
        root = new VBox(25);
        root.setPadding(new Insets(40, 60, 40, 60));
        root.setAlignment(Pos.CENTER);
        root.setStyle("-fx-background-color: linear-gradient(to right, #2980b9, #6dd5fa);");

        Label titleLabel = new Label("Welcome Back!");
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 36));
        titleLabel.setTextFill(Color.WHITE);
        titleLabel.setEffect(new DropShadow(5, Color.rgb(0, 0, 0, 0.3)));

        // Email with icon
        HBox emailBox = createInputField("fas-envelope", "Email");
        TextField emailField = (TextField) emailBox.getChildren().get(1);

        // Password with icon
        HBox passwordBox = createInputField("fas-lock", "Password");
        PasswordField passwordField = (PasswordField) passwordBox.getChildren().get(1);

        Button btnLogin = new Button("Login");
        btnLogin.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-background-radius: 15;");
        btnLogin.setPrefWidth(320);
        btnLogin.setFont(Font.font("Arial", FontWeight.SEMI_BOLD, 18));
        addHoverEffect(btnLogin, "#27ae60", "#2ecc71");

        Hyperlink linkRegister = new Hyperlink("Create new account");
        linkRegister.setTextFill(Color.WHITE);
        linkRegister.setFont(Font.font("Arial", 14));
        linkRegister.setBorder(Border.EMPTY);
        linkRegister.setPadding(new Insets(5, 0, 5, 0));
        linkRegister.setOnMouseEntered(e -> linkRegister.setTextFill(Color.LIGHTBLUE));
        linkRegister.setOnMouseExited(e -> linkRegister.setTextFill(Color.WHITE));
        linkRegister.setOnAction(e -> System.out.println("Show Register Screen (not implemented)"));

        Label lblMessage = new Label();
        lblMessage.setTextFill(Color.YELLOW);
        lblMessage.setFont(Font.font("Arial", 14));
        lblMessage.setWrapText(true);
        lblMessage.setMaxWidth(320);
        lblMessage.setAlignment(Pos.CENTER);

        btnLogin.setOnAction(e -> {
            String email = emailField.getText().trim();
            String password = passwordField.getText();

            if (email.isEmpty() || password.isEmpty()) {
                lblMessage.setText("Please enter both email and password");
                return;
            }

            if (isAdmin(email, password)) {
                lblMessage.setText("Admin login successful. Redirecting...");
                PauseTransition pause = new PauseTransition(Duration.seconds(1.5));
                pause.setOnFinished(ev -> mainApp.showAdminDashboard());
                pause.play();
            } else if (isUserValid(email, password)) {
                lblMessage.setText("Login successful. Redirecting...");
                PauseTransition pause = new PauseTransition(Duration.seconds(1.5));
                pause.setOnFinished(ev -> mainApp.showUserDashboard());
                pause.play();
            } else {
                lblMessage.setText("Invalid email or password");
            }
        });

        root.getChildren().addAll(
                titleLabel,
                emailBox,
                passwordBox,
                btnLogin,
                linkRegister,
                lblMessage
        );
    }

    private HBox createInputField(String iconLiteral, String promptText) {
        HBox box = new HBox(12);
        box.setAlignment(Pos.CENTER_LEFT);
        box.setMaxWidth(320);

        FontIcon icon = new FontIcon(iconLiteral);
        icon.setIconSize(22);
        icon.setIconColor(Color.WHITE);
        icon.setEffect(new DropShadow(3, Color.rgb(0, 0, 0, 0.25)));

        TextField inputField;

        if ("Password".equalsIgnoreCase(promptText)) {
            inputField = new PasswordField();
        } else {
            inputField = new TextField();
        }

        inputField.setPromptText(promptText);
        inputField.setPrefWidth(260);
        inputField.setStyle(
                "-fx-background-radius: 10;" +
                        "-fx-background-color: rgba(255,255,255,0.9);" +
                        "-fx-padding: 8 12 8 12;" +
                        "-fx-border-color: transparent;" +
                        "-fx-effect: dropshadow(gaussian, rgba(0,0,0,0.1), 4, 0, 0, 1);"
        );

        box.getChildren().addAll(icon, inputField);
        return box;
    }

    private void addHoverEffect(Button button, String normalColor, String hoverColor) {
        button.setOnMouseEntered(e -> button.setStyle("-fx-background-color: " + hoverColor + "; -fx-text-fill: white; -fx-background-radius: 15;"));
        button.setOnMouseExited(e -> button.setStyle("-fx-background-color: " + normalColor + "; -fx-text-fill: white; -fx-background-radius: 15;"));
    }

    private boolean isAdmin(String email, String password) {
        return email.equalsIgnoreCase("admin@example.com") && password.equals("admin123");
    }

    private boolean isUserValid(String email, String password) {
        // Replace with your real validation logic
        return email.equalsIgnoreCase("user@example.com") && password.equals("password");
    }

    public VBox getView() {
        return root;
    }
}
