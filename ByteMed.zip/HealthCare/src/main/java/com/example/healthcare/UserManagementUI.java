package com.example.healthcare;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class UserManagementUI {

    private BorderPane root;
    private MainApp app;

    public UserManagementUI(MainApp app) {
        this.app = app;
        createUI();
    }

    private void createUI() {
        root = new BorderPane();
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: linear-gradient(to bottom right, #1abc9c, #16a085);");

        Label title = new Label("User Management");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        title.setStyle("-fx-text-fill: white;");
        root.setTop(title);
        BorderPane.setAlignment(title, Pos.CENTER);

        TableView<User> userTable = new TableView<>();
        TableColumn<User, String> usernameCol = new TableColumn<>("Username");
        usernameCol.setCellValueFactory(new PropertyValueFactory<>("username"));

        TableColumn<User, String> roleCol = new TableColumn<>("Role");
        roleCol.setCellValueFactory(new PropertyValueFactory<>("role"));

        userTable.getColumns().addAll(usernameCol, roleCol);
        userTable.setPrefHeight(250);

        TextField txtUsername = new TextField();
        txtUsername.setPromptText("Username");

        TextField txtRole = new TextField();
        txtRole.setPromptText("Role");

        Button btnAdd = new Button("Add User");
        btnAdd.setOnAction(e -> {
            // Placeholder logic for adding user
            String username = txtUsername.getText();
            String role = txtRole.getText();
            userTable.getItems().add(new User(username, role));
            txtUsername.clear();
            txtRole.clear();
        });

        HBox formBox = new HBox(10, txtUsername, txtRole, btnAdd);
        formBox.setAlignment(Pos.CENTER);
        formBox.setPadding(new Insets(10));

        VBox centerBox = new VBox(15, userTable, formBox);
        centerBox.setAlignment(Pos.CENTER);

        root.setCenter(centerBox);

        Button btnBack = new Button("Back");
        btnBack.setOnAction(e -> app.showAdminDashboard());

        HBox bottomBox = new HBox(btnBack);
        bottomBox.setAlignment(Pos.CENTER_LEFT);
        bottomBox.setPadding(new Insets(10));

        root.setBottom(bottomBox);
    }

    public BorderPane getView() {
        return root;
    }

    // Simple User model class for the table
    public static class User {
        private String username;
        private String role;

        public User(String username, String role) {
            this.username = username;
            this.role = role;
        }

        public String getUsername() {
            return username;
        }

        public String getRole() {
            return role;
        }
    }
}

