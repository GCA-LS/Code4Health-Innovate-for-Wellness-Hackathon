package com.example.healthcare;

import javafx.animation.FadeTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.util.Duration;

public class AdminDashboardUI {
    private BorderPane root;
    private MainApp app;

    public AdminDashboardUI(MainApp app) {
        this.app = app;
        createUI();
    }

    private void createUI() {
        root = new BorderPane();
        root.setPadding(new Insets(30));
        root.setStyle("-fx-background-color: linear-gradient(to right, #34495e, #2c3e50);");

        // Header
        Label label = new Label("Admin Dashboard - Lesotho Healthcare Locator");
        label.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        label.setTextFill(Color.WHITE);
        label.setEffect(new DropShadow(4, Color.BLACK));
        BorderPane.setAlignment(label, Pos.CENTER);
        root.setTop(label);

        // Dashboard Buttons
        Button btnManageFacilities = createDashboardButton("Manage Facilities");
        btnManageFacilities.setOnAction(e -> app.showManageFacilities());

        Button btnViewReports = createDashboardButton("View Facility Reports");
        btnViewReports.setOnAction(e -> app.showReports());

        Button btnManageUsers = createDashboardButton("Manage Users");
        btnManageUsers.setOnAction(e -> app.showUserManagement());

        Button btnSettings = createDashboardButton("Settings");
        btnSettings.setOnAction(e -> app.showSettings());

        VBox centerBox = new VBox(20, btnManageFacilities, btnViewReports, btnManageUsers, btnSettings);
        centerBox.setAlignment(Pos.CENTER);

        FadeTransition ft = new FadeTransition(Duration.seconds(1.2), centerBox);
        ft.setFromValue(0);
        ft.setToValue(1);
        ft.play();

        root.setCenter(centerBox);

        // Logout Button
        Button btnLogout = new Button("Logout");
        btnLogout.setStyle("-fx-background-color: #e74c3c; -fx-text-fill: white; -fx-background-radius: 12;");
        btnLogout.setFont(Font.font("Arial", FontWeight.BOLD, 16));
        btnLogout.setOnAction(e -> app.showLogin());

        HBox bottomBox = new HBox(btnLogout);
        bottomBox.setAlignment(Pos.CENTER_RIGHT);
        bottomBox.setPadding(new Insets(10));

        // Footer text
        Label footerLabel = new Label("© 2025 Lesotho Healthcare Locator. All rights reserved.");
        footerLabel.setFont(Font.font("Arial", 12));
        footerLabel.setTextFill(Color.GRAY);
        footerLabel.setPadding(new Insets(10));

        VBox bottomContainer = new VBox(bottomBox, footerLabel);
        root.setBottom(bottomContainer);
    }

    private Button createDashboardButton(String text) {
        Button button = new Button(text);
        button.setPrefWidth(250);
        button.setFont(Font.font("Arial", FontWeight.SEMI_BOLD, 18));
        button.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white; -fx-background-radius: 15;");
        button.setOnMouseEntered(e -> button.setStyle("-fx-background-color: #3498db; -fx-text-fill: white; -fx-background-radius: 15;"));
        button.setOnMouseExited(e -> button.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white; -fx-background-radius: 15;"));
        return button;
    }

    public BorderPane getView() {
        return root;
    }
}
