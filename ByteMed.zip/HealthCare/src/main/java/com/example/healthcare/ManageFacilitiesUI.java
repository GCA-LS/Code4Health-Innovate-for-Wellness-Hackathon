package com.example.healthcare;


import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.layout.BorderPane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class ManageFacilitiesUI {
    private BorderPane root;
    private MainApp app;

    public ManageFacilitiesUI(MainApp app) {
        this.app = app;
        createUI();
    }

    private void createUI() {
        root = new BorderPane();
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: #ecf0f1;");

        Label label = new Label("Manage Healthcare Facilities");
        label.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        root.setTop(label);
    }

    public BorderPane getView() {
        return root;
    }
}

