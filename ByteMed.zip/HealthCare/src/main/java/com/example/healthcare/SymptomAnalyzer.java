package com.example.healthcare;

import java.util.*;
import java.io.FileWriter;
import java.io.IOException;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;

public class SymptomAnalyzer {

    private static final Map<List<String>, String> symptomToDiseaseMap = new HashMap<>();

    static {
        symptomToDiseaseMap.put(Arrays.asList("fever", "cough", "fatigue"), "Flu");
        symptomToDiseaseMap.put(Arrays.asList("fever", "rash", "joint pain"), "Dengue Fever");
        symptomToDiseaseMap.put(Arrays.asList("headache", "nausea", "sensitivity to light"), "Migraine");
        symptomToDiseaseMap.put(Arrays.asList("chest pain", "shortness of breath", "dizziness"), "Heart Attack");
        symptomToDiseaseMap.put(Arrays.asList("sore throat", "cough", "runny nose"), "Common Cold");
        symptomToDiseaseMap.put(Arrays.asList("vomiting", "diarrhea", "stomach pain"), "Food Poisoning");
        symptomToDiseaseMap.put(Arrays.asList("fever", "night sweats", "weight loss"), "Tuberculosis");
        symptomToDiseaseMap.put(Arrays.asList("itching", "sneezing", "watery eyes"), "Allergy");
        symptomToDiseaseMap.put(Arrays.asList("frequent urination", "increased thirst", "fatigue"), "Diabetes");
        symptomToDiseaseMap.put(Arrays.asList("weight loss", "coughing blood", "fever"), "Tuberculosis");
    }

    public static String analyze(String inputSymptoms) {
        if (inputSymptoms == null || inputSymptoms.isBlank()) {
            return "No symptoms entered.";
        }

        String s = inputSymptoms.toLowerCase();
        Set<String> inputSet = new HashSet<>(Arrays.asList(s.split("\\s*,\\s*|\\s+and\\s+|\\s+")));

        for (Map.Entry<List<String>, String> entry : symptomToDiseaseMap.entrySet()) {
            List<String> keySymptoms = entry.getKey();
            if (inputSet.containsAll(keySymptoms)) {
                return entry.getValue();
            }
        }

        return "Symptoms not recognized or insufficient for diagnosis. Please consult a doctor.";
    }

    private void showSymptomAnalyzer(Stage primaryStage) {
        Label titleLabel = new Label("🩺 Symptom Analyzer");
        titleLabel.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: white;");

        Label instructionLabel = new Label("Select or enter your symptoms:");
        instructionLabel.setStyle("-fx-text-fill: white;");

        // Symptom suggestion dropdown
        ComboBox<String> symptomComboBox = new ComboBox<>();
        symptomComboBox.setEditable(true);
        symptomComboBox.getItems().addAll(
                "fever", "cough", "fatigue", "headache", "nausea",
                "chest pain", "sore throat", "vomiting", "diarrhea",
                "rash", "joint pain", "sneezing", "shortness of breath"
        );
        symptomComboBox.setPromptText("Type or select symptom");

        TextField additionalSymptomsField = new TextField();
        additionalSymptomsField.setPromptText("Add more symptoms, separated by commas");

        Button analyzeButton = new Button("Analyze");
        Label resultLabel = new Label();
        resultLabel.setStyle("-fx-text-fill: white;");

        Button saveButton = new Button("Save Result");
        saveButton.setDisable(true); // Only enable after analysis

        analyzeButton.setOnAction(e -> {
            String input = symptomComboBox.getValue();
            String additional = additionalSymptomsField.getText();
            String allSymptoms = (input != null ? input : "") + (additional.isEmpty() ? "" : ", " + additional);
            String result = SymptomAnalyzer.analyze(allSymptoms);
            resultLabel.setText("Diagnosis: " + result);
            saveButton.setDisable(false);
        });

        saveButton.setOnAction(e -> {
            String diagnosis = resultLabel.getText();
            // Save to file (simple example)
            try (FileWriter writer = new FileWriter("diagnosis_results.txt", true)) {
                writer.write(diagnosis + "\n");
                resultLabel.setText(diagnosis + " (saved)");
            } catch (IOException ex) {
                resultLabel.setText("Error saving result.");
            }
        });

        Button backButton = new Button("← Back");
        backButton.setOnAction(e -> {
            // You'll need to implement or inject showMainApp
            // For now, just close the current stage
            primaryStage.close();
        });

        VBox layout = new VBox(12);
        layout.setPadding(new Insets(25));
        layout.getChildren().addAll(
                titleLabel,
                instructionLabel,
                symptomComboBox,
                additionalSymptomsField,
                analyzeButton,
                resultLabel,
                saveButton,
                backButton
        );

        layout.setAlignment(Pos.CENTER);

        // Gradient background
        StackPane root = new StackPane();
        root.getChildren().add(layout);
        root.setStyle(
                "-fx-background-color: linear-gradient(to bottom right, #2193b0, #6dd5ed);"
        );

        Scene scene = new Scene(root, 500, 400);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Symptom Analyzer");
    }
}