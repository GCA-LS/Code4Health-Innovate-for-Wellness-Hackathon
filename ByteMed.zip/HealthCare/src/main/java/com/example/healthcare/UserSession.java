package com.example.healthcare;

import javax.security.auth.Subject;

public class UserSession {

    private static UserSession instance;  // singleton instance
    private Subject currentUser;
    private String currentUsername;

    // private constructor to prevent instantiation
    private UserSession() {}

    // singleton accessor
    public static UserSession getInstance() {
        if (instance == null) {
            instance = new UserSession();
        }
        return instance;
    }

    // get current logged-in user (Subject)
    public Subject getCurrentUser() {
        return currentUser;
    }

    // set current logged-in user
    public void setCurrentUser(Subject user) {
        this.currentUser = user;
    }

    // clear session
    public void clearSession() {
        this.currentUser = null;
        this.currentUsername = null;
    }

    // check if a user is logged in
    public boolean isLoggedIn() {
        return currentUser != null;
    }

    public String getCurrentUsername() {
        return currentUsername;
    }

    public void setCurrentUsername(String username) {
        this.currentUsername = username;
    }
}
