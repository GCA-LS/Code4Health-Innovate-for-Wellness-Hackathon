package com.example.healthcare;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class RegisterUI {

    private VBox root;
    private MainApp mainApp;

    public RegisterUI(MainApp mainApp) {
        this.mainApp = mainApp;
        createUI();
    }

    private void createUI() {
        root = new VBox(20);
        root.setPadding(new Insets(40, 60, 40, 60));
        root.setAlignment(Pos.CENTER);
        root.setStyle("-fx-background-color: linear-gradient(to right, #ff512f, #dd2476);");

        Label titleLabel = new Label("Create an Account");
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 36));
        titleLabel.setTextFill(Color.WHITE);

        TextField txtEmail = new TextField();
        txtEmail.setPromptText("Email");
        txtEmail.setPrefWidth(320);

        PasswordField txtPassword = new PasswordField();
        txtPassword.setPromptText("Password");
        txtPassword.setPrefWidth(320);

        PasswordField txtConfirmPassword = new PasswordField();
        txtConfirmPassword.setPromptText("Confirm Password");
        txtConfirmPassword.setPrefWidth(320);

        Label lblMessage = new Label();
        lblMessage.setTextFill(Color.YELLOW);
        lblMessage.setFont(Font.font("Arial", 14));

        Button btnRegister = new Button("Register");
        btnRegister.setPrefWidth(320);
        btnRegister.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-background-radius: 15;");
        btnRegister.setFont(Font.font("Arial", FontWeight.SEMI_BOLD, 18));
        btnRegister.setOnAction(e -> {
            String email = txtEmail.getText().trim();
            String pass = txtPassword.getText();
            String confirmPass = txtConfirmPassword.getText();

            if (email.isEmpty() || pass.isEmpty() || confirmPass.isEmpty()) {
                lblMessage.setText("Please fill in all fields");
                return;
            }
            if (!pass.equals(confirmPass)) {
                lblMessage.setText("Passwords do not match");
                return;
            }

            // TODO: Add actual registration logic (DB etc)
            lblMessage.setText("Registration successful! Please login.");
        });

        Hyperlink linkLogin = new Hyperlink("Already have an account? Login");
        linkLogin.setTextFill(Color.WHITE);
        linkLogin.setOnAction(e -> mainApp.showLogin());

        root.getChildren().addAll(titleLabel, txtEmail, txtPassword, txtConfirmPassword, btnRegister, lblMessage, linkLogin);
    }

    public VBox getView() {
        return root;
    }
}
