package com.example.healthcare;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class ReportsUI {
    private BorderPane root;
    private MainApp app;

    public ReportsUI(MainApp app) {
        this.app = app;
        createUI();
    }

    private void createUI() {
        root = new BorderPane();
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: linear-gradient(to right, #bdc3c7, #2c3e50);");

        Label header = new Label("Facility Reports");
        header.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        header.setTextFill(Color.WHITE);

        TableView<Report> reportTable = new TableView<>();
        reportTable.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);

        TableColumn<Report, String> facilityCol = new TableColumn<>("Facility");
        facilityCol.setCellValueFactory(new PropertyValueFactory<>("facility"));

        TableColumn<Report, String> reportCol = new TableColumn<>("Report Summary");
        reportCol.setCellValueFactory(new PropertyValueFactory<>("summary"));

        TableColumn<Report, String> dateCol = new TableColumn<>("Date");
        dateCol.setCellValueFactory(new PropertyValueFactory<>("date"));

        reportTable.getColumns().addAll(facilityCol, reportCol, dateCol);

        // Sample data (replace with real data source)
        reportTable.getItems().addAll(
                new Report("Queen II Hospital", "Needs more beds", "2025-05-10"),
                new Report("Maseru Clinic", "Shortage of staff", "2025-05-11")
        );

        VBox centerBox = new VBox(15, header, reportTable);
        centerBox.setAlignment(Pos.TOP_CENTER);
        centerBox.setPadding(new Insets(10));

        root.setCenter(centerBox);

        Button btnBack = new Button("Back");
        btnBack.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white;");
        btnBack.setOnAction(e -> app.showAdminDashboard());

        HBox bottomBox = new HBox(btnBack);
        bottomBox.setAlignment(Pos.CENTER_RIGHT);
        bottomBox.setPadding(new Insets(10));

        root.setBottom(bottomBox);
    }

    public BorderPane getView() {
        return root;
    }

    public static class Report {
        private String facility;
        private String summary;
        private String date;

        public Report(String facility, String summary, String date) {
            this.facility = facility;
            this.summary = summary;
            this.date = date;
        }

        public String getFacility() {
            return facility;
        }

        public String getSummary() {
            return summary;
        }

        public String getDate() {
            return date;
        }
    }
}
