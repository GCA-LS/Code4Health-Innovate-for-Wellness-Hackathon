package com.example.healthcare;

import javafx.animation.FadeTransition;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.util.Duration;

import java.util.*;

public class DashboardUI {

    private VBox root;
    private MainApp app;

    // UI Components
    private TextArea symptomInput;
    private Button analyzeBtn;
    private Label suspectedDiseasesLabel;
    private HBox serviceButtonsBox;
    private VBox facilityListBox;

    // Mock user location
    private final double userLat = -29.315; // Maseru latitude approx
    private final double userLon = 27.485;  // Maseru longitude approx

    // Mock data for facilities
    private List<com.example.healthcare.Facility> hospitals;
    private List<com.example.healthcare.Facility> clinics;
    private List<com.example.healthcare.Facility> pharmacies;

    // Current suspected diseases from symptom analysis
    private List<String> suspectedDiseases = new ArrayList<>();

    public DashboardUI(MainApp app) {
        this.app = app;
        initMockFacilities();
        createUI();
    }

    private void createUI() {
        root = new VBox(15);
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: linear-gradient(to bottom, #a2d9ff, #1f8eed);");

        Label title = new Label("Lesotho Healthcare Locator");
        title.setFont(Font.font("Arial", FontWeight.BOLD, 28));
        title.setTextFill(Color.WHITE);

        Label instruction = new Label("Enter your symptoms (e.g. fever, headache):");
        instruction.setFont(Font.font(16));
        instruction.setTextFill(Color.WHITE);

        symptomInput = new TextArea();
        symptomInput.setPromptText("Describe your symptoms here...");
        symptomInput.setPrefRowCount(3);

        analyzeBtn = new Button("Analyze Symptoms");
        analyzeBtn.setStyle("-fx-background-color: #2980b9; -fx-text-fill: white; -fx-font-weight: bold;");
        analyzeBtn.setOnAction(e -> analyzeSymptoms());

        suspectedDiseasesLabel = new Label("");
        suspectedDiseasesLabel.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        suspectedDiseasesLabel.setTextFill(Color.YELLOW);

        // Service buttons
        Button btnHospitals = createServiceButton("Hospitals");
        btnHospitals.setOnAction(e -> showFacilities("Hospital"));

        Button btnClinics = createServiceButton("Clinics");
        btnClinics.setOnAction(e -> showFacilities("Clinic"));

        Button btnPharmacies = createServiceButton("Pharmacies");
        btnPharmacies.setOnAction(e -> showFacilities("Pharmacy"));

        serviceButtonsBox = new HBox(15, btnHospitals, btnClinics, btnPharmacies);
        serviceButtonsBox.setAlignment(Pos.CENTER);
        serviceButtonsBox.setVisible(false); // Hidden until analysis done

        facilityListBox = new VBox(10);
        facilityListBox.setPadding(new Insets(10));
        facilityListBox.setStyle("-fx-background-color: rgba(255,255,255,0.8); -fx-background-radius: 10;");
        facilityListBox.setVisible(false);

        root.getChildren().addAll(title, instruction, symptomInput, analyzeBtn, suspectedDiseasesLabel, serviceButtonsBox, facilityListBox);
    }

    private Button createServiceButton(String text) {
        Button btn = new Button(text);
        btn.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-weight: bold; -fx-background-radius: 15;");
        btn.setPrefWidth(120);
        btn.setFont(Font.font(14));
        btn.setOnMouseEntered(e -> btn.setStyle("-fx-background-color: #2ecc71; -fx-text-fill: white; -fx-font-weight: bold; -fx-background-radius: 15;"));
        btn.setOnMouseExited(e -> btn.setStyle("-fx-background-color: #27ae60; -fx-text-fill: white; -fx-font-weight: bold; -fx-background-radius: 15;"));
        return btn;
    }

    private void analyzeSymptoms() {
        String symptomsText = symptomInput.getText().toLowerCase().trim();
        suspectedDiseases.clear();

        if(symptomsText.isEmpty()) {
            showAlert("Please enter your symptoms before analysis.");
            return;
        }

        // Simple mock logic for symptom analysis:
        if(symptomsText.contains("fever") && symptomsText.contains("headache")) {
            suspectedDiseases.add("Malaria");
            suspectedDiseases.add("Dengue Fever");
        } else if(symptomsText.contains("cough") && symptomsText.contains("fever")) {
            suspectedDiseases.add("Flu");
            suspectedDiseases.add("COVID-19");
        } else if(symptomsText.contains("stomach") && symptomsText.contains("pain")) {
            suspectedDiseases.add("Gastritis");
            suspectedDiseases.add("Food Poisoning");
        } else {
            suspectedDiseases.add("Common Cold");
        }

        StringBuilder sb = new StringBuilder("Suspected Diseases:\n");
        suspectedDiseases.forEach(d -> sb.append("- ").append(d).append("\n"));

        suspectedDiseasesLabel.setText(sb.toString());
        serviceButtonsBox.setVisible(true);
        facilityListBox.setVisible(false);
    }

    private void showFacilities(String serviceType) {
        if(suspectedDiseases.isEmpty()) {
            showAlert("Please analyze symptoms first.");
            return;
        }

        facilityListBox.getChildren().clear();
        facilityListBox.setVisible(true);

        Label header = new Label("Nearby " + serviceType + " offering services for:");
        header.setFont(Font.font("Arial", FontWeight.BOLD, 18));
        facilityListBox.getChildren().add(header);

        suspectedDiseases.forEach(disease -> {
            Label diseaseLabel = new Label("- " + disease);
            diseaseLabel.setFont(Font.font(14));
            diseaseLabel.setTextFill(Color.DARKBLUE);
            facilityListBox.getChildren().add(diseaseLabel);
        });

        List<com.example.healthcare.Facility> listToShow;
        switch (serviceType) {
            case "Hospital": listToShow = hospitals; break;
            case "Clinic": listToShow = clinics; break;
            case "Pharmacy": listToShow = pharmacies; break;
            default: listToShow = new ArrayList<>();
        }

        facilityListBox.getChildren().add(new Separator());

        for (com.example.healthcare.Facility f : listToShow) {
            if(f.getServices().stream().anyMatch(s -> suspectedDiseases.contains(s))) {
                double dist = calculateDistance(userLat, userLon, f.getLatitude(), f.getLongitude());
                Label facilityLabel = new Label(
                        f.getName() + " (" + String.format("%.1f", dist) + " km) \n" +
                                "Hours: " + f.getOperatingHours() + "\n" +
                                "Services: " + String.join(", ", f.getServices())
                );
                facilityLabel.setPadding(new Insets(8));
                facilityLabel.setStyle("-fx-background-color: #ecf0f1; -fx-background-radius: 8;");
                facilityListBox.getChildren().add(facilityLabel);
            }
        }
    }

    // Haversine formula to calculate distance in km between two lat/lon points
    private double calculateDistance(double lat1, double lon1, double lat2, double lon2) {
        final int R = 6371; // Earth radius km
        double dLat = Math.toRadians(lat2 - lat1);
        double dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                        Math.sin(dLon/2) * Math.sin(dLon/2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return R * c;
    }

    private void showAlert(String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Input Required");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public VBox getView() {
        return root;
    }

    private void initMockFacilities() {
        hospitals = new ArrayList<>();
        clinics = new ArrayList<>();
        pharmacies = new ArrayList<>();

        hospitals.add(new com.example.healthcare.Facility("Maseru Central Hospital", -29.313, 27.486,
                "24/7", Arrays.asList("Malaria", "Flu", "COVID-19", "Dengue Fever")));

        hospitals.add(new com.example.healthcare.Facility("Queen Mamohato Memorial Hospital", -29.315, 27.483,
                "24/7", Arrays.asList("Malaria", "Gastritis", "Food Poisoning")));

        clinics.add(new com.example.healthcare.Facility("Maseru Clinic A", -29.312, 27.480,
                "8am - 6pm", Arrays.asList("Common Cold", "Flu", "COVID-19")));

        clinics.add(new com.example.healthcare.Facility("Mafeteng Clinic", -29.418, 27.683,
                "7am - 5pm", Arrays.asList("Malaria", "Gastritis")));

        pharmacies.add(new com.example.healthcare.Facility("Maseru Pharmacy 1", -29.314, 27.482,
                "8am - 8pm", Arrays.asList("Malaria", "Flu", "Common Cold")));

        pharmacies.add(new com.example.healthcare.Facility("Lesotho Pharmacy", -29.317, 27.490,
                "9am - 7pm", Arrays.asList("Gastritis", "Food Poisoning", "COVID-19")));
    }
}
