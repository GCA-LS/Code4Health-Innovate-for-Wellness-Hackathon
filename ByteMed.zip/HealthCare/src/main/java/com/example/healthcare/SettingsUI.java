package com.example.healthcare;


import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.effect.DropShadow;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;

public class SettingsUI {
    private BorderPane root;
    private MainApp app;

    public SettingsUI(MainApp app) {
        this.app = app;
        createUI();
    }

    private void createUI() {
        root = new BorderPane();
        root.setPadding(new Insets(20));
        root.setStyle("-fx-background-color: linear-gradient(to right, #6a11cb, #2575fc);");

        Label titleLabel = new Label("Application Settings");
        titleLabel.setFont(Font.font("Arial", FontWeight.BOLD, 24));
        titleLabel.setTextFill(Color.WHITE);
        titleLabel.setEffect(new DropShadow(3, Color.BLACK));
        BorderPane.setAlignment(titleLabel, Pos.CENTER);
        root.setTop(titleLabel);

        // Settings Fields
        TextField emailField = new TextField();
        emailField.setPromptText("Admin contact email");

        CheckBox notificationsCheck = new CheckBox("Enable system notifications");
        notificationsCheck.setTextFill(Color.WHITE);

        CheckBox darkModeCheck = new CheckBox("Enable dark mode");
        darkModeCheck.setTextFill(Color.WHITE);

        VBox settingsBox = new VBox(15,
                new Label("Contact Email:"), emailField,
                notificationsCheck, darkModeCheck);
        settingsBox.setPadding(new Insets(20));
        settingsBox.setAlignment(Pos.CENTER_LEFT);

        // Save Button
        Button saveButton = new Button("Save Settings");
        saveButton.setStyle("-fx-background-color: #2ecc71; -fx-text-fill: white; -fx-background-radius: 10;");
        saveButton.setFont(Font.font("Arial", FontWeight.BOLD, 14));

        VBox centerBox = new VBox(20, settingsBox, saveButton);
        centerBox.setAlignment(Pos.CENTER);
        root.setCenter(centerBox);

        // Back Button
        Button backButton = new Button("Back to Dashboard");
        backButton.setStyle("-fx-background-color: #e67e22; -fx-text-fill: white; -fx-background-radius: 10;");
        backButton.setOnAction(e -> app.showAdminDashboard());

        HBox bottomBox = new HBox(backButton);
        bottomBox.setPadding(new Insets(10));
        bottomBox.setAlignment(Pos.CENTER_LEFT);
        root.setBottom(bottomBox);
    }

    public BorderPane getView() {
        return root;
    }
}

