package com.example.healthcare;

import java.util.List;

public class Facility {
    private String name;
    private double latitude;
    private double longitude;
    private String operatingHours;
    private List<String> services;

    public Facility(String name, double latitude, double longitude, String operatingHours, List<String> services) {
        this.name = name;
        this.latitude = latitude;
        this.longitude = longitude;
        this.operatingHours = operatingHours;
        this.services = services;
    }

    public String getName() {
        return name;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public String getOperatingHours() {
        return operatingHours;
    }

    public List<String> getServices() {
        return services;
    }
}
