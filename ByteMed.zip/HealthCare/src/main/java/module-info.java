module com.example.healthcare {
    requires javafx.fxml;
    requires de.jensd.fx.glyphs.fontawesome;
    requires org.kordamp.ikonli.fontawesome5;
    requires org.kordamp.ikonli.javafx;
    requires javafx.controls;


    opens com.example.healthcare to javafx.fxml;
    exports com.example.healthcare;
}